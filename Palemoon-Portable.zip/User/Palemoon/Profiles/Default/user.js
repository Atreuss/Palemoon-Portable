user_pref("browser.cache.disk.parent_directory", "C:\\Users\\PC\\Desktop\\����\\User\\Palemoon\\Profiles\\Default");
user_pref("browser.download.lastDir", "C:\\Users\\PC\\Desktop\\����\\Downloads");
user_pref("browser.shell.checkDefaultBrowser", false);
