﻿var Cc=Components.classes, Ci=Components.interfaces;
var proc=Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
var file=Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsILocalFile);
var cok=Cc["@mozilla.org/cookiemanager;1"].getService(Ci.nsICookieManager);
var prf=Cc["@mozilla.org/preferences-service;1"].getService(Ci.nsIPrefBranch);
var str=Cc["@mozilla.org/supports-string;1"].createInstance(Ci.nsISupportsString);
var alt=Cc["@mozilla.org/embedcomp/prompt-service;1"].getService(Ci.nsIPromptService);

//=========================================================================================================

var faucetOn = new Array();
var dirData = 'Coinpot';
var prob = 1;
var n = '\n'; 
var pp = 0;

faucetOn['log'] = 1440;
faucetOn['freedogcoin']=60;
faucetOn['bonusbitcoin']=15;
faucetOn['bitfun']=5;
faucetOn['moonbtc']=5;
faucetOn['moondoge']=5;
faucetOn['moondash']=5;
faucetOn['moonbch']=5;
faucetOn['moonltc']=5;

//=========================================================================================================================


var Tabs = {
	_browser: function () {
		var wm = Components.classes["@mozilla.org/appshell/window-mediator;1"]
			.getService(Components.interfaces.nsIWindowMediator);
		return wm.getMostRecentWindow("navigator:browser").gBrowser;
	}(),
	go: function (tabIndex) {
		this._browser.selectedTab = this._browser.tabContainer.childNodes[tabIndex - 1];
	}
};

var loadFile = function (fileName) {
   var fileDescriptor = imns.FIO.openNode(fileName);
   var text = imns.FIO.readTextFile(fileDescriptor);
   return {
       text: text,
       strings: text.replace(/ /gi, "").split("\r\n")
    };
};

var appendToFile = function (fileName, text) {
   var fileDescriptor = imns.FIO.openNode(fileName);
   imns.FIO.appendTextFile(fileDescriptor, text);
}

//=========================================================================================================================
//=========================================================================================================================

var n = '\n';

function log(feler){
   var timer=getDate();
   txt=feler+'    '+timer; 
   iimPlayCode('SET !EXTRACT '+txt.replace(/ /gi,"<SP>") + ' \nSAVEAS TYPE=EXTRACT  FOLDER=C:\\' + dirData + '\\ FILE=log.txt');}

 function getDate(){var d=new Date(); return d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();}  
   
function weitrandom(){	
    var randomNumber = Math.floor(Math.random()*240 + 120); 
    iimDisplay('esperando por ' + randomNumber + ' segundos');
	iimPlayCode('WAIT SECONDS='+randomNumber);	
	} 
	
function milisec() {
    return new Date().getTime()
}

function closeAllOthers() {
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'TAB CLOSEALLOTHERS' + n;
    iimPlay(code, 60)
}
function getTimerSite() {
    var t = new Array();
    var str = '';
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'SET !DATASOURCE C:\\' + dirData + '\\timer2.csv' + n;
    code += 'SET !DATASOURCE_LINE 1' + n;
    code += 'SET !EXTRACT NULL ' + n;
    code += 'SET !VAR1 {{!COL1}}' + n;
    code += 'ADD !EXTRACT {{!VAR1}}' + n;
    iimPlay(code, 60);
    str = iimGetLastExtract();
    return str.split('|')
}

function updateTimer(t, i, min) {
    var str = '';
    var nowtime = milisec();
    msec = min * 60 * 1000;
    t[i] = nowtime + msec;
    nextsbor[i] = t[i];
    str = t.join('|');
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'SET !EXTRACT NULL' + n;
    code += 'ADD !EXTRACT ' + str + n;
    code += 'FILEDELETE NAME=C:\\' + dirData + '\\timer2.csv ' + n;
    code += 'SAVEAS TYPE=EXTRACT FOLDER=C:\\' + dirData + '\\ FILE=timer2.csv ' + n;
    iimPlay(code, 60)
}

function updateWaitTimer2() {
    var waitSecond = 999999;
    var t = nextsbor;
    var nowMilisec = milisec();
    var strUpFile = '';
    var strUpFile_light = '';
    timeToCountDown = '';
    var header = '&quot;<link href=\'bootstrap/css/bootstrap.min.css\' rel=\'stylesheet\' media=\'screen\'><link href=\'bootstrap/css/bootstrap-responsive.min.css\' rel=\'stylesheet\' media=\'screen\'><link href=\'vendors/easypiechart/jquery.easy-pie-chart.css\' rel=\'stylesheet\' media=\'screen\'><link href=\'assets/styles.css\' rel=\'stylesheet\' media=\'screen\'>';
    var table = '';
    var i = 0;
    table += '<div class=\'block\'><div class=\'navbar navbar-inner block-header\'><div class=\'muted pull-left\'>Seja Bem Vindo</div></div><div class=\'block-content collapse in\'><div class=\'span12\'><table class=\'table table-condensed\'><thead><tr><th></th><th>Nome do Site</th><th>Tempo Restante</th><th>Tempo da Faucet</th></tr></thead><tbody>';
    for (var key in faucetOn) {
        i++;
        if (faucetOn[key] > 0) {
            var countdownSec = parseInt((t[i] - nowMilisec) / 1000);
            if (countdownSec < 3) {
                countdownSec = 3
            }
            if (countdownSec < waitSecond) {
                nextSite = key;
                waitSecond = countdownSec
            }
            table += '<tr><td>' + i + '</td><td>' + key + '</td><td class=\'ttimer\'>' + countdownSec + '</td><td><span class=\'badge badge-info\'>' + faucetOn[key] + '</span></td></tr>'
        } else {
            table += '<tr><td>' + i + '</td><td>' + key + '</td><td>OFF</td><td></td></tr>'
        }
    }
    table += '</tbody></table></div></div></div>';
    var footer = '<script src=\'vendors/jquery-1.9.1.min.js\'></script><script src=\'bootstrap/js/bootstrap.min.js\'></script><script src=\'vendors/easypiechart/jquery.easy-pie-chart.js\'></script><script src=\'js/fn.js\'></script><script>$(timerTable());</script>';
    var dopdata = '<span class=\'badge badge-warning \'>Next: ' + nextSite + '</span><span class=\'badge badge-success ttimer\'> ' + waitSecond + '</span><span class=\'badge badge-info pull-right\'><i class=\'icon-tag\'></i>PAz a Todos</span> ';
    strUpFile += header + dopdata + table + footer + '&quot;';
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'FILEDELETE NAME=C:\\' + dirData + '\\site_table.html ' + n;
    code += 'SET !EXTRACT NULL' + n;
    code += 'ADD !EXTRACT {{STRFILE}}' + n;
    code += 'SAVEAS TYPE=EXTRACT FOLDER=C:\\' + dirData + ' FILE=site_table.html ' + n;
    code += 'TAB T=1' + n;
    code += 'URL GOTO=file:///C:/' + dirData + '/wait.html' + n;
    code += 'WAIT SECONDS=' + waitSecond + n;
    iimSet("STRFILE", strUpFile);
    iimPlay(code, 60)
}

function getFaucetIndex(){
    var t = new Array();
    var i =0;
    for (var key in faucetOn) {
        i++;
        t[i]= key;
    }
    return t
}


//========================================== EDIÃƒÆ’Ã¢â‚¬Â¡AO DAS FAUCETS ================================================

//==================moondash==============================

function bonusbitcoin(pp){

	if(pp>prob) return;
	
	var code='';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'URL GOTO=http://bonusbitcoin.co/faucet' + n;
	code += 'WAIT SECONDS=2' + n;
	code += 'URL GOTO=javascript:window.scrollBy(0,1075)' + n;
	code += 'WAIT SECONDS=2' + n;
	iimPlay(code, 60);
 
	var file = 'bonusbitcoin.png'
	SaveCapthaSolve(file);
	var str = GetRucaptcha(file);
	var cText = str['c_text'];
	var captha = cText.replace(/\s/g, '<SP>');
	iimDisplay(captha);
	if (captha == '') {return}
	if (captha == 'ERROR') {return}
	if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}

	var code = '';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ID:FaucetForm ATTR=ID:adcopy_response CONTENT=' + captha + n;
	code += 'WAIT SECONDS=2' + n;
	code += 'TAG POS=1 TYPE=BUTTON FORM=ID:FaucetForm ATTR=TXT:Claim<SP>now!' + n;
	code += 'WAIT SECONDS=15' + n;  
	iimPlay(code, 60);

  	iimPlay('CODE:SET !TIMEOUT_STEP 0\nTAG POS=1 TYPE=DIV ATTR=TXT:Faucet<SP>claim<SP>failed:<SP>The<SP>captcha<SP>is<SP>not* EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') { 
	bonusbitcoin(pp + 1);return;} 
		
	iimPlay("CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=H4 ATTR=TXT:Faucet<SP>claim<SP>successful EXTRACT=TXT"); 
	win=iimGetLastExtract();
	if(win == '#EANF#') {return;}
}

//============================================================================================================================================

function bitfun(pp){
	
	if(pp>prob) return;
	
	var code='';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'URL GOTO=http://bitfun.co/games' + n;
	code += 'WAIT SECONDS=2' + n;
	code += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:Claim<SP>now!<SP>Please<SP>wait' + n;
	code += 'WAIT SECONDS=2' + n;
	iimPlay(code, 60);

	var file = 'bitfun.png'
	SaveCapthaSolve(file);
	var str = GetRucaptcha(file);
	var cText = str['c_text'];
	var captha = cText.replace(/\s/g, '<SP>');
	iimDisplay(captha);
	if (captha == '') {return}
	if (captha == 'ERROR') {return}
	if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}
 
	var code = '';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ID:ClaimForm ATTR=ID:adcopy_response CONTENT=' + captha + n;
	code += 'WAIT SECONDS=3' + n;
	code += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:Claim' + n;
	code += 'WAIT SECONDS=10' + n;
	iimPlay(code, 60);

	iimPlay('CODE:SET !TIMEOUT_STEP 1\nTAG POS=1 TYPE=DIV ATTR=CLASS:modal-body&&DATA-BIND:html:<SP>bodyHtml EXTRACT=TXT');
        err = iimGetLastExtract();
            if (err != '' && err != '#EANF#') { 
    bitfun(pp + 1);return;}

    iimPlay("CODE:SET !TIMEOUT 1\nTAG POS=2 TYPE=H4 ATTR=CLASS:modal-title EXTRACT=TXT"); 
        win=iimGetLastExtract();
    if(win == '#EANF#') {return;}
}

function moonbtc(pp){
	if(pp>prob) return;

	var code='';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'URL GOTO=http://moonbit.co.in' + n;
	code += 'WAIT SECONDS=2' + n;
	code += 'TAG POS=1 TYPE=INPUT:BUTTON FORM=ID:* ATTR=ID:SubmitButton' + n;
	code += 'WAIT SECONDS=2' + n;
	iimPlay(code, 60);

	var file = 'moonbtc.png'
	SaveCapthaSolve(file);
	var str = GetRucaptcha(file);
	var cText = str['c_text'];
	var captha = cText.replace(/\s/g, '<SP>');
	iimDisplay(captha);
	if (captha == '') {return}
	if (captha == 'ERROR') {return}
	if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}
	
	var code = '';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ID:dd2eGG26 ATTR=ID:adcopy_response CONTENT=' + captha + n;
	code += 'WAIT SECONDS=3' + n;
	code += 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ID:* ATTR=ID:*' + n;
	code += 'WAIT SECONDS=10' + n;
	iimPlay(code, 60);
  
	iimPlay("CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=DIV ATTR=CLASS:failure-message&&ID:BodyPlaceholder_FailedClaimPanel EXTRACT=TXT"); 
	err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') { 
	moonbtc(pp + 1);return;}

	iimPlay("CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=P ATTR=TXT:*<SP>satoshi<SP>has<SP>been<SP>added<SP>to<SP>your<SP>CoinP* EXTRACT=TXT"); 
	win=iimGetLastExtract();
	if(win == '#EANF#') {return;}
}

function moondoge(pp){
	if(pp>prob) return;

	var code='';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'URL GOTO=http://moondoge.co.in' + n;
	code += 'WAIT SECONDS=2' + n;
	code += 'TAG POS=1 TYPE=INPUT:BUTTON FORM=ID:* ATTR=ID:SubmitButton' + n;
	code += 'WAIT SECONDS=2' + n;
	iimPlay(code, 60);

	var file = 'moondoge.png'
	SaveCapthaSolve(file);
	var str = GetRucaptcha(file);
	var cText = str['c_text'];
	var captha = cText.replace(/\s/g, '<SP>');
	iimDisplay(captha);
	if (captha == '') {return}
	if (captha == 'ERROR') {return}
	if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}
	
	var code = '';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ID:MainForm ATTR=ID:adcopy_response CONTENT=' + captha + n;
	code += 'WAIT SECONDS=3' + n;
	code += 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ID:MainForm ATTR=ID:*' + n;
	code += 'WAIT SECONDS=10' + n;
	iimPlay(code, 60);
  
	iimPlay("CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=DIV ATTR=CLASS:failure-message&&ID:BodyPlaceholder_FailedClaimPanel EXTRACT=TXT"); 
	err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') { 
	moondoge(pp + 1);return;}

	iimPlay("CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=P ATTR=TXT:*<SP>dogecoin<SP>has<SP>been<SP>added<SP>to<SP>your<SP>CoinP* EXTRACT=TXT"); 
	win=iimGetLastExtract();
	if(win == '#EANF#') {return;}
}

function moondash(pp){
	if(pp>prob) return;

	var code='';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'URL GOTO=http://moondash.co.in/faucet' + n;
	code += 'WAIT SECONDS=5' + n;
	iimPlay(code, 60);

	iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=IFRAME ATTR=FRAMEBORDER:* EXTRACT=HTM'); 
	err = iimGetLastExtract();
    if (err != '#EANF#') {iimPlay('CODE:SET !TIMEOUT 5\nTAG POS=1 TYPE=A ATTR=TXT:close');}

    var code='';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:claim<SP>now<SP>please<SP>wait' + n;
	code += 'WAIT SECONDS=2' + n;
	iimPlay(code, 60);

	var file = 'moondash.png'
	SaveCapthaSolve(file);
	var str = GetRucaptcha(file);
	var cText = str['c_text'];
	var captha = cText.replace(/\s/g, '<SP>');
	iimDisplay(captha);
	if (captha == '') {return}
	if (captha == 'ERROR') {return}
	if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}
	
	var code = '';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ID:ClaimForm ATTR=ID:adcopy_response CONTENT=' + captha + n;
	code += 'WAIT SECONDS=3' + n;
	code += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:Claim' + n;
	code += 'WAIT SECONDS=5' + n;
	iimPlay(code, 60);
  
	iimPlay("CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=DIV ATTR=DATA-BIND:html:<SP>bodyHtml&&CLASS:modal-body EXTRACT=TXT"); 
	err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') { 
	moondash(pp + 1);return;}

	iimPlay("CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=P ATTR=TXT:*<SP>has<SP>been<SP>credited<SP>to<SP>your<SP>CoinP* EXTRACT=TXT"); 
	win=iimGetLastExtract();
	if(win == '#EANF#') {return;}
}

function moonbch(pp){
	if(pp>prob) return;

	var code='';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'URL GOTO=http://moonbitcoin.cash/faucet' + n;
	code += 'WAIT SECONDS=5' + n;
	iimPlay(code, 60);

	iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=IFRAME ATTR=FRAMEBORDER:* EXTRACT=HTM'); 
	err = iimGetLastExtract();
    if (err != '#EANF#') {iimPlay('CODE:SET !TIMEOUT 5\nTAG POS=1 TYPE=A ATTR=TXT:close');}

    var code='';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:claim<SP>now<SP>please<SP>wait' + n;
	code += 'WAIT SECONDS=2' + n;
	iimPlay(code, 60);

	var file = 'moonbch.png'
	SaveCapthaSolve(file);
	var str = GetRucaptcha(file);
	var cText = str['c_text'];
	var captha = cText.replace(/\s/g, '<SP>');
	iimDisplay(captha);
	if (captha == '') {return}
	if (captha == 'ERROR') {return}
	if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}
	
	var code = '';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ID:ClaimForm ATTR=ID:adcopy_response CONTENT=' + captha + n;
	code += 'WAIT SECONDS=3' + n;
	code += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:Claim' + n;
	code += 'WAIT SECONDS=5' + n;
	iimPlay(code, 60);
  
	iimPlay("CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=DIV ATTR=DATA-BIND:html:<SP>bodyHtml&&CLASS:modal-body EXTRACT=TXT"); 
	err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') { 
	moonbch(pp + 1);return;}

	iimPlay("CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=P ATTR=TXT:*<SP>has<SP>been<SP>credited<SP>to<SP>your<SP>CoinP* EXTRACT=TXT"); 
	win=iimGetLastExtract();
	if(win == '#EANF#') {return;}
}

function moonltc(pp){
	if(pp>prob) return;

	var code='';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'URL GOTO=http://moonliteco.in' + n;
	code += 'WAIT SECONDS=2' + n;
	code += 'TAG POS=1 TYPE=INPUT:BUTTON FORM=ID:* ATTR=ID:SubmitButton' + n;
	code += 'WAIT SECONDS=2' + n;
	iimPlay(code, 60);

	var file = 'moonltc.png'
	SaveCapthaSolve(file);
	var str = GetRucaptcha(file);
	var cText = str['c_text'];
	var captha = cText.replace(/\s/g, '<SP>');
	iimDisplay(captha);
	if (captha == '') {return}
	if (captha == 'ERROR') {return}
	if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}
	
	var code = '';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ID:MainForm ATTR=ID:adcopy_response CONTENT=' + captha + n;
	code += 'WAIT SECONDS=3' + n;
	code += 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ID:MainForm ATTR=ID:*' + n;
	code += 'WAIT SECONDS=10' + n;
	iimPlay(code, 60);
  
	iimPlay("CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=DIV ATTR=ID:BodyPlaceholder_FailedClaimPanel EXTRACT=TXT"); 
	err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') { 
	moonltc(pp + 1);return;}

	iimPlay("CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=P ATTR=TXT:*<SP>has<SP>been<SP>added<SP>to<SP>your<SP>Coin* EXTRACT=TXT"); 
	win=iimGetLastExtract();
	if(win == '#EANF#') {return;}
}

function freedogcoin(pp){
	if(pp>prob) return;

    var code='';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'URL GOTO=https://freedoge.co.in/?op=home' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'URL GOTO=javascript:window.scrollBy(0,1050)' + n;
    code += 'TAG POS=1 TYPE=SELECT ATTR=ID:free_play_captcha_types CONTENT=%solvemedia' + n;
    iimPlay(code, 60); 
  
    var file = 'freedogcoin.png'
	SaveCapthaSolve(file);
	var str = GetRucaptcha(file);
	var cText = str['c_text'];
	var captha = cText.replace(/\s/g, '<SP>');
	iimDisplay(captha);
	if (captha == '') {return}
	if (captha == 'ERROR') {return}
	if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}

	var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:adcopy_response CONTENT=' + captha + n;
    code += 'WAIT SECONDS=0.5' + n;
    code += 'TAG POS=1 TYPE=INPUT:SUBMIT ATTR=ID:free_play_form_button' + n;
    code += 'WAIT SECONDS=2' + n;
    iimPlay(code, 60);

    iimPlay('CODE:SET !TIMEOUT_STEP 1\nTAG POS=1 TYPE=P ATTR=ID:free_play_error EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') { 
    freedogcoin(pp + 1);return;} 
		
	iimPlay("CODE:SET !TIMEOUT 1\nTAG POS=1 TYPE=SPAN ATTR=ID:winnings EXTRACT=TXT"); 
	win=iimGetLastExtract();
	if(win == '#EANF#') {return;}
}

//========================================== EDIÃƒÆ’Ã¢â‚¬Â¡AO DAS FAUCETS ================================================

//========================================== GET-SAVE-REPORT-CAPTCHA ===============================================

function SaveCapthaSolve(file_name) {
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'SET !ENCRYPTION NO' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'ONDOWNLOAD FOLDER=C:\\' + dirData + '\\ FILE=' + file_name + ' WAIT=YES' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=IMG ATTR=ID:adcopy-puzzle-image-image CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    iimPlay(code, 60)
}

function GetRucaptcha(file_name) {
	var result = new Array();
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB OPEN' + n;
    code += 'TAB T=2' + n;
    code += 'URL GOTO=file:///C:/' + dirData + '/xevil.html' + n;
    code += 'TAG POS=1 TYPE=INPUT:FILE ATTR=TYPE:file&&NAME:file&&SIZE:20 CONTENT=C:\\' + dirData + '\\' + file_name + n;
    code += 'TAG POS=1 TYPE=INPUT:SUBMIT ATTR=TYPE:submit&&VALUE:recognize' + n;
    code += 'WAIT SECONDS=2' + n;
    code += 'TAG POS=1 TYPE=BODY ATTR=TXT:* EXTRACT=TXT' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAB CLOSE' + n;
    iimPlay(code, 120);
    var str = iimGetLastExtract();
    var capthId = str.replace('OK|', '');
    switch (capthId) {
        case'ERROR_NO_SLOT_AVAILABLE':
            var code = '';
            code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
            code += 'TAB T=1' + n;
            code += 'WAIT SECONDS=10' + n;
            return GetRucaptcha(file_name);
            break;
        default:
            result['c_text'] = GetRucaptchaTEXT(capthId, file_name, pp);
            result['c_id'] = capthId
    }
    return result
}

function GetRucaptchaTEXT(capthId, file_name, pp) {
    if(pp > prob) {
    iimDisplay('Captcha Errado - Tentando Novamente');}
    else{
    var result = 'ERROR';
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB OPEN' + n;
    code += 'TAB T=2' + n;
    code += 'URL GOTO=http://127.0.0.5:80/res.php?action=get&id=' + capthId + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=BODY ATTR=TXT:* EXTRACT=TXT' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAB CLOSE' + n;
    iimPlay(code, 60);
    var str = iimGetLastExtract();
    var capth = str.replace('OK|', '');
    switch (capth) {
        case'CAPCHA_NOT_READY':
            var code = '';
            code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
            code += 'TAB T=1' + n;
            code += 'WAIT SECONDS=10' + n;
            iimPlay(code, 60);
            result = GetRucaptchaTEXT(capthId, file_name, (pp + 1));
            break;
        case'ERROR_KEY_DOES_NOT_EXIST':
            return result = 'ERROR';
            break;
        case'ERROR_WRONG_ID_FORMAT':
            return result = 'ERROR';
            break;
        case'ERROR_WRONG_CAPTCHA_ID':
            return result = 'ERROR';
            break;
        case'ERROR_CAPTCHA_UNSOLVABLE':
            return result = 'ERROR_CAPTCHA_UNSOLVABLE';
            break;
        default:
            var result = capth
    }
    return result}
}


//========================================== GET-SAVE-REPORT-CAPTCHA ===============================================

function runFaucet(facetName){

    switch (facetName) {
		case 'freedogcoin':
    freedogcoin();
    break;
    	case 'moonbtc':
    moonbtc();
    break;
		case 'moondash':
    moondash();
    break;
		case 'moondoge':
    moondoge();
    break;
		case 'moonbch':
    moonbch();
    break;
		case 'bitfun':
    bitfun();
    break;
		case 'moonltc':
    moonltc();
    break;
		case 'bonusbitcoin':
    bonusbitcoin();
    break;
		default:
            break
    }
}

var col = 40;
var nextsbor = new Array();

nextsbor = getTimerSite();
while (100 > 0) {

    var msec = milisec();
    var i = 0;

    for (var key in faucetOn) {
        i++;
        if (nextsbor[i]< msec && faucetOn[key] > 0){

            runFaucet(key);
            updateTimer(nextsbor, i, faucetOn[key]);
        }
    }

  	closeAllOthers();
  	updateWaitTimer2();       
}

function weit(s) {iimPlayCode("WAIT SECONDS=" + s);}
