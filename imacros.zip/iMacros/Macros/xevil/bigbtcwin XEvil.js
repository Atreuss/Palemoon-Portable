var n = '\n';
var pp = 0;
var prob = 5;
var dirData = 'bigbtc';
var btc = '158fRAFW2c6TpHHY9123BFPZEdqWL19aTm'; //CARTEIRA DE BITCOIN

for (i = 0; i < 250; i++) {
    bigbtc();
    iimPlayCode('WAIT SECONDS=310');
}

function login(){
    iimPlayCode('SET !TIMEOUT_PAGE 30'
    //+n+ 'URL GOTO=http://bigbtc.win/faucet'
    +n+ 'TAB T=1'
    +n+ 'WAIT SECONDS=7'
    +n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:/faucet ATTR=NAME:address CONTENT=' + btc + ''
    +n+ 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ACTION:/faucet ATTR=*'
    +n+ 'TAB T=1'    
    +n+ 'TAB CLOSEALLOTHERS'
    +n+ 'WAIT SECONDS=5');
}

function bonus() {

    var code='';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_TAG 60 \n';
    code += 'TAB T=1' + n;
    code += 'TAB CLOSEALLOTHERS' + n;    
    code += 'URL GOTO=http://bigbtc.win/bonus' + n;
    code += 'URL GOTO=javascript:window.scrollBy(0,860)' + n;
    code += 'TAB CLOSEALLOTHERS' + n;
    code += 'WAIT SECONDS=5' + n;
    code += 'TAG POS=1 TYPE=BUTTON FORM=ACTION:* ATTR=ID:clickhere' + n;
    code += 'WAIT SECONDS=5' + n;
    //code += 'TAB CLOSEALLOTHERS' + n;
    code += 'EVENT TYPE=CLICK SELECTOR="#skip_bu2tton>IMG" BUTTON=0'+ n;
    code += 'WAIT SECONDS=2.5' + n;
    //code += 'TAB T=1' + n;
    code += 'TAB CLOSEALLOTHERS' + n;

    iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=IMG ATTR=ID:bee EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') 
    {claimbee();return;}
    //code += 'TAB T=1' + n;
    code += 'TAB CLOSEALLOTHERS' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=A ATTR=TXT:BACK<SP>TO<SP>FAUCET' + n;
    iimPlay(code, 60);

    bigbtc();
}
    function claimbee(){
    code += 'EVENT TYPE=CLICK SELECTOR="#skip_bu2tton>IMG" BUTTON=0'+ n;
    code += 'WAIT SECONDS=1' + n;
}

function bigbtc(pp) {
    var file ='bigbtc.png';
    
  /*  var code='';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
   //code += 'TAB T=1' + n;
    code += 'TAB CLOSEALLOTHERS' + n;
    code += 'URL GOTO=http://bigbtc.win/faucet' + n;
    code += 'TAB T=1'
    code += 'WAIT SECONDS=7'

    iimPlay('CODE:SET !TIMEOUT_STEP 1\nTAG POS=1 TYPE=H2 ATTR=TXT:LOGIN EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') {login();return;}*/

    iimPlay(code, 60);
    code += 'URL GOTO=javascript:window.scrollBy(0,860)' + n;
    code += 'TAG POS=1 TYPE=A ATTR=TXT:CLAIM<SP>*<SP>SATOSHI<SP>BONUS<SP>NOW! EXTRACT=TXT' + n;
    iimPlay(code, 60);

    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') {bonus(pp + 1);return;}

    SaveCapthaSolve(file);
    var str = GetRucaptcha(file);
    var cText = str['c_text'];
    var captha = cText.replace(/\s/g, '<SP>');
    iimDisplay(captha);
    if (captha == '') {return}
    if (captha == 'ERROR') {return}
    if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}

    var code='';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:/* ATTR=ID:adcopy_response CONTENT=' + captha + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:PLAY' + n;
    code += 'TAB CLOSEALLOTHERS' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'FILEDELETE NAME=C:\\' + dirData + '\\' + file + n;
    iimPlay(code, 60);

    SaveCapthaSolve2(file);
    var str = GetRucaptcha(file);
    var cText = str['c_text'];
    var captha = cText.replace(/\s/g, '<SP>');
    iimDisplay(captha);
    if (captha == '') {return}
    if (captha == 'ERROR') {return}
    if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}

    var code='';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:/* ATTR=NAME:captcha_code CONTENT=' + captha + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ACTION:/* ATTR=ID:claimbtn' + n;
    code += 'TAB CLOSEALLOTHERS' + n;
    code += 'FILEDELETE NAME=C:\\' + dirData + '\\' + file + n;
    code += 'TAB CLOSEALLOTHERS' + n;
    iimPlay(code, 60);

    iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=DIV ATTR=CLASS:alert<SP>alert-error EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') {bigbtc(pp + 1);return;}

    iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=P ATTR=CLASS:alert<SP>alert-success<SP>pulse EXTRACT=TXT');
    win=iimGetLastExtract();
    if(win == '#EANF#') {return;}
}

function SaveCapthaSolve(file) {
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'SET !ENCRYPTION NO' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'ONDOWNLOAD FOLDER=C:\\' + dirData + '\\ FILE=' + file + ' WAIT=YES' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=IMG ATTR=ID:adcopy-puzzle-image-image CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    iimPlay(code, 60)
}

function SaveCapthaSolve2(file) {
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'SET !ENCRYPTION NO' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'ONDOWNLOAD FOLDER=C:\\' + dirData + '\\ FILE=' + file + ' WAIT=YES' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=IMG ATTR=SRC:http://bigbtc.win/securimage/* CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    iimPlay(code, 60)
}

function GetRucaptcha(file) {
    var result = new Array();
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB OPEN' + n;
    code += 'TAB T=2' + n;
    code += 'URL GOTO=http://dindinnanet.com.br/saldo/content/dindin.html' + n;
    code += 'TAG POS=1 TYPE=INPUT:FILE FORM=ACTION:* ATTR=NAME:file CONTENT=C:\\' + dirData + '\\' + file + n;
    code += 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ACTION:* ATTR=*' + n;
    code += 'WAIT SECONDS=0.1' + n;
    code += 'TAG POS=1 TYPE=BODY ATTR=TXT:* EXTRACT=TXT' + n;
    code += 'WAIT SECONDS=0.1' + n;
    code += 'TAB CLOSE' + n;
    iimPlay(code, 120);
    var str = iimGetLastExtract();
    var capthId = str.replace('OK|', '');
    switch (capthId) {
        case'ERROR_NO_SLOT_AVAILABLE':
            var code = '';
            code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
            code += 'TAB T=1' + n;
            code += 'WAIT SECONDS=10' + n;
            return GetRucaptcha(file);
            break;
        default:
            result['c_text'] = GetRucaptchaTEXT(capthId, file, pp);
            result['c_id'] = capthId
    }
    return result
}

function GetRucaptchaTEXT(capthId, file, pp) {
    if(pp > prob) {
    iimDisplay('Captcha Errado - Tentando Novamente');}
    else{
    var result = 'ERROR';
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB OPEN' + n;
    code += 'TAB T=2' + n;
    code += 'URL GOTO=http://23.249.176.210/res.php?action=get&id=' + capthId + n;
    code += 'WAIT SECONDS=0.1' + n;
    code += 'TAG POS=1 TYPE=BODY ATTR=TXT:* EXTRACT=TXT' + n;
    code += 'WAIT SECONDS=0.1' + n;
    code += 'TAB CLOSE' + n;
    iimPlay(code, 60);
    var str = iimGetLastExtract();
    var capth = str.replace('OK|', '');
    switch (capth) {
        case'CAPCHA_NOT_READY':
            var code = '';
            code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
            code += 'TAB T=1' + n;
            code += 'WAIT SECONDS=10' + n;
            iimPlay(code, 60);
            result = GetRucaptchaTEXT(capthId, file, (pp + 1));
            break;
        case'ERROR_KEY_DOES_NOT_EXIST':
            return result = 'ERROR';
            break;
        case'ERROR_WRONG_ID_FORMAT':
            return result = 'ERROR';
            break;
        case'ERROR_WRONG_CAPTCHA_ID':
            return result = 'ERROR';
            break;
        case'ERROR_CAPTCHA_UNSOLVABLE':
            return result = 'ERROR_CAPTCHA_UNSOLVABLE';
            break;
        default:
            var result = capth
    }
    return result}
}