var Nagibaka = {
 
 
	/**
	 *  Solve Google reCaptcha v.2 with rucaptcha.com service
	 *
	 *  @author: Nagibaka<nagibaka.ru>
	 *  @date: 18.01.2017
	 *  @version : 1.0
	 *  
	 *  @param {String} ruCaptchaKey [API key from rucaptcha.com]
	 *  @return {JSON} [Object with info about success or errors]
	 */
	fuckReCaptcha2: function () {
	
		iimPlayCode('SET !EXTRACT_TEST_POPUP NO');
		iimPlayCode('SET !ERRORIGNORE YES');
		iimPlayCode('SET !TIMEOUT_STEP 0');		
 
		var out = {
			isSolved: false,
			hasError: false,
			errorText: "no text"
		};
 
		var reqCount = 0;
 
 
		function checkSolution (gkey) {
 
			if (reqCount > 14) {  // 14 * 5 = 70 second timeout
 
				out = {
					isSolved: false,
					hasError: true,
					errorText: "Rucaptcha timeout error."
				};
 
				return;
 
			}
 
			iimPlayCode('WAIT SECONDS=5');	
 
			var XMLHttpRequestT = Components.Constructor("@mozilla.org/xmlextras/xmlhttprequest;1");
			var xhr = new XMLHttpRequestT();
			var url = "http://23.249.176.210/res.php?action=get&id=" + gkey + "&json=1"
			xhr.open('GET', url, false);
			xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
			xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
 
			xhr.timeout = 60000;
			
			
			// processing results
			try {
 
				xhr.send();
 
				if (xhr.status != 200) {
					out = {
						isSolved: false,
						hasError: true,
						errorText: xhr.statusText
					};		
				} else {					
					var res = JSON.parse(xhr.responseText);
					if (res.status == 1) {
						window.document.querySelector('.g-recaptcha-response').style = "";
						window.document.querySelector('.g-recaptcha-response').textContent = res.request;					
						out = {
							isSolved: true,
							hasError: false,
							errorText: "Success!"
						};
						
					} else {
						reqCount++;
						checkSolution (gkey)
					}	
				}			
 
			} catch (e) {				
				out = {
					isSolved: false,
					hasError: true,
					errorText: e.name
				};
				
			}
 
 
		}
 
 
		
		if (window.document.querySelector('.g-recaptcha') == null) {
			return {
				isSolved: false,
				hasError: true,
				errorText: "Recaptcha not found on page."
			};
		}
 
		var dataSiteKey = window.document.querySelector('.g-recaptcha').getAttribute('data-sitekey');
		var domen = window.location.host;
	
		var params = "method=userrecaptcha&googlekey=" + dataSiteKey + "&pageurl=" + domen + "&json=true&header_acao=1";
 
		var XMLHttpRequest = Components.Constructor("@mozilla.org/xmlextras/xmlhttprequest;1");
		var xhr = new XMLHttpRequest();
		xhr.open('POST', "http://23.249.176.210/in.php", false);
		xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
		xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
		xhr.timeout = 60000;
 
		try {
 
			xhr.send(params);
 
			if (xhr.status != 200) {
				out = {
					isSolved: false,
					hasError: true,
					errorText: xhr.statusText
				};		
			} else {				
				var res = JSON.parse(xhr.responseText);
				if (res.status == 1) {
					checkSolution(res.request);
				} else {
					out = {
						isSolved: false,
						hasError: true,
						errorText: xhr.statusText
					};
				}		
			}			
 
		} catch (e) {			
			out = {
				isSolved: false,
				hasError: true,
				errorText: e.name
			};
			
		}
 
		return out;
 
	}
 
};
 
 
 
// Пример использования на сайте https://www.google.com/recaptcha/api2/demo
iimPlayCode('SET !TIMEOUT 30\r\nURL GOTO=https://www.google.com/recaptcha/api2/demo');
 
var result = Nagibaka.fuckReCaptcha2();	
window.console.log(result);
 
// Check if captcha solved
if (result.isSolved) {
	window.document.querySelector('#recaptcha-demo-submit').click();
} else {
	window.console.log(result.errorText)
}