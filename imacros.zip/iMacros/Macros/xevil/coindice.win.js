var pp = 0;
var prob = 10;
var dirData = 'teste';
var n = '\n';

teste();

function teste(pp) {
	var file ='teste.png';

	var code='';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'URL GOTO=http://coindice.win/faucet/bitcoin'+ n;
	code += 'WAIT SECONDS=1' + n;
	iimPlay(code, 60);

	SaveCapthaSolve(file);
	var str = GetRucaptcha(file);
	var cText = str['c_text'];
	var captha = cText.replace(/\s/g, '<SP>');
	iimDisplay(captha);
	if (captha == '') {return}
	if (captha == 'ERROR') {return}
	if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}

	var code='';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:* ATTR=ID:adcopy_response CONTENT=' + captha + n;
	code += 'WAIT SECONDS=1' + n;
	code += 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ACTION:* ATTR=*' + n;
	code += 'FILEDELETE NAME=C:\\' + dirData + '\\' + file + n;
	iimPlay(code, 60);
}

function SaveCapthaSolve(file_name) {
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'SET !ENCRYPTION NO' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'ONDOWNLOAD FOLDER=C:\\' + dirData + '\\ FILE=' + file_name + ' WAIT=YES' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=IMG ATTR=ID:adcopy-puzzle-image-image CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    iimPlay(code, 60)
}

function GetRucaptcha(file_name) {
	var result = new Array();
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB OPEN' + n;
    code += 'TAB T=2' + n;
    code += 'URL GOTO=file:///C:/' + dirData + '/xevil.html' + n;
    code += 'TAG POS=1 TYPE=INPUT:FILE ATTR=TYPE:file&&NAME:file&&SIZE:20 CONTENT=C:\\' + dirData + '\\' + file_name + n;
    code += 'TAG POS=1 TYPE=INPUT:SUBMIT ATTR=TYPE:submit&&VALUE:recognize' + n;
    code += 'WAIT SECONDS=2' + n;
    code += 'TAG POS=1 TYPE=BODY ATTR=TXT:* EXTRACT=TXT' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAB CLOSE' + n;
    iimPlay(code, 120);
    var str = iimGetLastExtract();
    var capthId = str.replace('OK|', '');
    switch (capthId) {
        case'ERROR_NO_SLOT_AVAILABLE':
            var code = '';
            code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
            code += 'TAB T=1' + n;
            code += 'WAIT SECONDS=10' + n;
            return GetRucaptcha(file_name);
            break;
        default:
            result['c_text'] = GetRucaptchaTEXT(capthId, file_name, pp);
            result['c_id'] = capthId
    }
    return result
}

function GetRucaptchaTEXT(capthId, file_name, pp) {
    if(pp > prob) {
    iimDisplay('Captcha Errado - Tentando Novamente');}
    else{
    var result = 'ERROR';
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB OPEN' + n;
    code += 'TAB T=2' + n;
    code += 'URL GOTO=http://23.249.176.210/res.php?action=get&id=' + capthId + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=BODY ATTR=TXT:* EXTRACT=TXT' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAB CLOSE' + n;
    iimPlay(code, 60);
    var str = iimGetLastExtract();
    var capth = str.replace('OK|', '');
    switch (capth) {
        case'CAPCHA_NOT_READY':
            var code = '';
            code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
            code += 'TAB T=1' + n;
            code += 'WAIT SECONDS=10' + n;
            iimPlay(code, 60);
            result = GetRucaptchaTEXT(capthId, file_name, (pp + 1));
            break;
        case'ERROR_KEY_DOES_NOT_EXIST':
            return result = 'ERROR';
            break;
        case'ERROR_WRONG_ID_FORMAT':
            return result = 'ERROR';
            break;
        case'ERROR_WRONG_CAPTCHA_ID':
            return result = 'ERROR';
            break;
        case'ERROR_CAPTCHA_UNSOLVABLE':
            return result = 'ERROR_CAPTCHA_UNSOLVABLE';
            break;
        default:
            var result = capth
    }
    return result}
}