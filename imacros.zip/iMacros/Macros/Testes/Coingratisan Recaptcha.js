var apiKey_ruCaptcha = 'apiKey_ruCaptcha';
var loop = 2
var n = '\n';
var url = []; 

if(1>0){url[0]='btc';}
if(1>0){url[1]='ltc';}
if(1>0){url[2]='doge';}

for (a = 0; a < loop; a++){
	for(var b=0; b<url.length; b++){
		    macro = 'CODE:\n'
			  + 'SET !EXTRACT_TEST_POPUP NO\n'
		      + 'SET !ERRORIGNORE YES\n'
		      + 'SET !ERRORCONTINUE YES\n'
		      + 'SET !TIMEOUT_STEP 0\n'
		      + 'TAB T=1\n'
		      + 'URL GOTO=http://www.coingratisan.xyz/new/claim/'+url[b]+'\n'
		      + 'WAIT SECONDS=1\n'
		  	iimPlay(macro);
	  	if (!window.content.document.getElementById('btnsubmit')) {
			iimDisplay('Cloudflare protection foi detectado...');
			iimPlayCode('WAIT SECONDS=20');
			continue;
		}

		var data_sitekey = window.content.document.getElementsByClassName('g-recaptcha')[0].getAttribute('data-sitekey');
		answer = solveReCaptcha_ruCaptcha(data_sitekey, 'https://www.coingratisan.xyz/', 0);
		if (!answer['status']) {}

		var x = window.document.getElementById("g-recaptcha-response");
		x.style.display = "";	

		iimPlayCode('SET !ERRORIGNORE YES'
		+n+ 'SET !TIMEOUT_STEP 10'
		+n+ 'WAIT SECONDS=1'
		+n+ 'TAG POS=1 TYPE=TEXTAREA FORM=ID:* ATTR=ID:g-recaptcha-response CONTENT=\"' + answer['hash'] + '\"'
		+n+ 'WAIT SECONDS=1'
		+n+ 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:NoFormName ATTR=ID:btnsubmit');

		iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=2 TYPE=DIV ATTR=TXT:Captcha<SP>is<SP>Wrong! EXTRACT=TXT');
		err = iimGetLastExtract();
		if (err != '' && err != '#EANF#') {reportCaptcha(answer['server'], apiKey_ruCaptcha, answer['taskId']);}
	
		if (!window.content.document.getElementById('invisibleCaptchaShortlink')) {
			iimDisplay('Cloudflare protection foi detectado...');
			iimPlayCode('WAIT SECONDS=20');
			continue;
		}

	    if (window.location.host != "kokemoon.com"){break;}
		var data_sitekey = '6LdTSEQUAAAAAAX30_-bQ6f7BEaJ4EuZl6w2pbxP';
		answer = solveReCaptcha_ruCaptcha(data_sitekey, 'http://kokemoon.com/', 0);
		if (!answer['status']) {}

		var x = window.document.getElementById("g-recaptcha-response");
		x.style.display = "";

		iimPlayCode('SET !ERRORIGNORE YES'
		+n+ 'SET !TIMEOUT_STEP 10'
		+n+ 'WAIT SECONDS=1'
		+n+ 'TAG POS=1 TYPE=TEXTAREA FORM=ID:* ATTR=ID:g-recaptcha-response CONTENT=\"' + answer['hash'] + '\"'
		+n+ 'WAIT SECONDS=1'
		+n+ 'TAG POS=1 TYPE=BUTTON FORM=ID:link-view ATTR=ID:invisibleCaptchaShortlink'
		+n+ 'WAIT SECONDS=1');

		iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=2 TYPE=DIV ATTR=TXT:Captcha<SP>is<SP>Wrong! EXTRACT=TXT');
		err = iimGetLastExtract();
		if (err != '' && err != '#EANF#') {reportCaptcha(answer['server'], apiKey_ruCaptcha, answer['taskId']);}

		if (!window.content.document.getElementById('timer')) {
			iimDisplay('Cloudflare protection foi detectado...');
			iimPlayCode('WAIT SECONDS=20');
			continue;
		}
	}
}

function solveReCaptcha_ruCaptcha(data_sitekey, pageurl, invisble) {
	var serverURL = 'http://discount.rucaptcha.com/';
	while (true) {
		iimPlayCode('SET !TIMEOUT_PAGE 60\nTAB OPEN\nTAB T=2\nURL GOTO=' + serverURL + 'in.php?key=' + apiKey_ruCaptcha + '&method=userrecaptcha&googlekey=' + data_sitekey + '&pageurl=' + pageurl + '&invisible=' + invisble + '&json=1&soft_id=2004');
		var answer = JSON.parse(window.content.document.getElementsByTagName('pre')[0].firstChild.data);
		if (!answer['status']) {
			if (answer['request'] === 'ERROR_NO_SLOT_AVAILABLE') {
                iimDisplay('[ ' + serverURL + ' ]: Error! Tentando resolver de novo...');
                serverURL = 'http://rucaptcha.com/'; // => Nós mudamos o servidor para a prioridade, por causa da fila lotada no servidor com desconto
                iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
				continue;
			}
			iimDisplay('[ ' + serverURL + ' ]: Error! Tentando resolver de novo...');
            iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
			return { 'status' : 0, 'taskId' : 0, 'hash' : answer['request'], 'server' : serverURL }; // => { status : 0, taskId : 0, hash : ERROR_CODE, server : SERVER_URL }
		}
		var taskId = answer['request'];
		break;
	}

	iimPlayCode('WAIT SECONDS=10');

	var numberOfIterations = 1;
	while (numberOfIterations <= 30) {
		iimPlayCode('SET !TIMEOUT_PAGE 60\nURL GOTO=' + serverURL + 'res.php?key=' + apiKey_ruCaptcha + '&action=get&id=' + taskId + '&json=1');
		answer = JSON.parse(window.content.document.getElementsByTagName('pre')[0].firstChild.data);
		if (answer['status']) {
			iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
			break;
		} else {
			if (answer['request'] !== 'CAPCHA_NOT_READY') {
				iimDisplay('[ ' + serverURL + ' ]: Erro! Tentando resolver de novo...');
				iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
				return { 'status' : 0, 'taskId' : taskId, 'hash' : answer['request'], 'server' : serverURL }; // => { status : 0, taskId : 0, hash : ERROR_CODE, server : SERVER_URL }
			}

			if (numberOfIterations == 30) {
				iimDisplay('[ ' + serverURL + ' ]: O tempo de resposta expirou! Tentando novamente...');
				iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
				return { 'status' : 0, 'taskId' : taskId, 'hash' : answer['request'], 'server' : serverURL }; // => { status : 0, taskId : 0, hash : 'CAPCHA_NOT_READY', server : SERVER_URL }
			}

			iimDisplay('N° de Tentativas : ' + numberOfIterations);
			iimPlayCode('WAIT SECONDS=5'); // => 10 + 30 * 5 = 160 Segundos.
			numberOfIterations++;
		}
	}
	return { 'status' : answer['status'], 'taskId' : taskId, 'hash' : answer['request'], 'server' : serverURL };
}

function reportCaptcha(serverURL, apiKey, taskId) {
	
	iimPlayCode('SET !ERRORIGNORE YES'
	+n+ 'SET !TIMEOUT_PAGE 30'
	+n+ 'TAB OPEN'
	+n+ 'TAB T=2'
	+n+ 'URL GOTO=' + serverURL + 'res.php?key=' + apiKey + '&action=reportbad&id=' + taskId
	+n+ 'PAUSE'
	+n+ 'TAB CLOSE');
}