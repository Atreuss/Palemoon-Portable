


var x = window.content.document.getElementsByClassName('a')[0].removeAttribute("disabled")
x.style.display = "";

//a class="btn btn-success btn-lg get-link disabled" href="javascript: void(0)"


