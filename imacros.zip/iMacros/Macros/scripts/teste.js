/***

Biturl = btc
Dogeurl = doge
Liteurl = ltc
Poturl = ppc
Blackurl = blk
Primeurl = xpm
Ethereum = eth
BitCore = btx
Dash = dash
Monero = xmr
Peercoin = ppc
Bitcoin Cash = bch
Zcash = zec
Ethereum Classic = etc
Groestlurl = grs
Verge = xvg
Ubiq = ubq
Pivx = pivx
Stratis url = strat

Na Linha 30 troque para sua coin desejada Ex: var coin = 'doge';

***/


var loop = 999999999999
var url = [];
var coin = 'doge';
var dirData = 'teste';
var n = '\n';
var keyApi = new Array(); keyApi['9kw'] = '5TKEIXHBMYFITV5VEG';

if(1>0){url[0]=coin;}

for (a = 0; a < loop; a++){
	for(var b=0; b<url.length; b++){
	    macro = 'CODE:\n'
		  + 'SET !EXTRACT_TEST_POPUP NO\n'
	      + 'SET !ERRORIGNORE YES\n'
	      + 'SET !ERRORCONTINUE YES\n'
	      + 'SET !TIMEOUT_STEP 0\n'
	      + 'TAB T=1\n'
	      + 'URL GOTO=https://allcoins.pw/faucet.php?coin='+url[b]+'\n'
	      + 'WAIT SECONDS=1\n'
	  	iimPlay(macro);

	  	var file ='allcoins.png';
	  	SaveCaptha(file);
    	GetCaptcha(keyApi['9kw'], file);

    	var Claim = ''; 
            Claim += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
                Claim +='TAB T=1' + n;
                        Claim += 'TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:NoFormName ATTR=ID:adcopy_response CONTENT=' + result + n;
                Claim += 'WAIT SECONDS=2' + n;
            Claim += 'TAG POS=1 TYPE=BUTTON FORM=NAME:NoFormName ATTR=TXT:Captcha<SP>is<SP>resolved<SP>!' + n;
        Claim += 'WAIT SECONDS=2' + n;
    	iimPlay(Claim, 60);

    	function SaveCaptha(file_name) {
    
		    var code = '';
		            code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
		                code += 'TAB T=1' + n;
		                    //code += 'SET !ENCRYPTION NO' + n;
		                        code += 'WAIT SECONDS=0.1' + n;
		                    code += 'ONDOWNLOAD FOLDER=C:\\' + dirData + '\\ FILE=' + file_name + ' WAIT=YES' + n;
		                code += 'WAIT SECONDS=0.1' + n;
		            code += 'TAG POS=1 TYPE=IMG ATTR=ID:adcopy-puzzle-image-image CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
		        code += 'WAIT SECONDS=1' + n;
		    iimPlay(code, 60)
		}
	}
}