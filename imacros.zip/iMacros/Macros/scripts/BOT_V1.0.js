/**
 *  @description freebitco.in / freedoge.co.in / freenem.com
 *  @author Group Din Din na Net - http://dindinnanet.com.br
 *
 * [ Instruções ]:
 * ⑴ Baixar o Mozilla Firefox, iMacros v8.9.7 e Configurar de acordo com as Instruções README.md: http://dindinnanet.com.br/url-do-script
 * 	⑵ Entre nos sites para os quais você vai usar o Script
 * 	⑶ Registre-se e adicione fundos à sua conta de serviço de reconhecimento captcha usando qualquer método de pagamento de sua preferência
 * 	⑷ Atenção, não esqueça de fazer as seguintes ações:
 * 		▻ Criar pasta C: \ IWANTMONEY
 * 		▻ Coloque sua APIKEY do ruCaptcha.com / 2Captcha.com em vez de ** (linha №26) -> Ex: const apiKey ='9727fef187729a506869b64a70580515';
 * 		▻ Ativar torneiras que você precisa e funções adicionais para eles (Linhas №31 - 44)
 * ▻ Para usar o freenem.com você precisará instalar qualquer extensão para bloquear anúncios. Eu sugiro Visitar o Nosso Site para ver o Tutorial
 * Link para download: http://dindinnanet.com.br/2018/02/27/tutorial/
 *
 * Entre em contato Conosco:
 * ⑴ E-mail: contato@dindinnanet.com.br
 * ⑵ Website: http://dindinnanet.com.br
 * ⑶ Telegram: t.me/grupoDinDinnaNet
 */
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// [ Configurações №1 ]: Configurações personalizadas
const captchaPath      = 'C:\\DINDIN\\';         // Caminho de download de captchas de texto (não se esqueça de usar barras duplas invertidas)
const logPath 	       = 'C:\\DINDIN\\log.txt';  // Nome de arquivo completo do log (não se esqueça de usar barras invertidas duplas)
const mail             = 'gugatrb19@gmail.com';                  // Seu e-mail, para o qual as informações serão enviadas, sobre falhas no trabalho

const apiKey_ruCaptcha = '9727fef187729a506869b64a70580515'; // Sua API KEY de ruCaptcha.com (https://rucaptcha.com/enterpage) / 2Captcha.com
const apiKey_XCaptcha  = 'c5827df8b82d7411bbe09d87690223ad'; // Sua API KEY do X-Captcha.ru


// [ Configurações №2 ]: Faucet https://freebitco.in/
const freeBITCOIN                     = 'ON';  // [ON / OFF] - Usar bot em https://freebitco.in/
const freeBITCOIN_RewardPoints        = 'ON';  // [ON / OFF] - plicar automaticamente pontos de recompensa em https://freebitco.in/
const freeBITCOIN_RandomTimer         = 'OFF';  // [ON / OFF] - Atraso aleatório de 30 segundos a 2 minutos antes do próximo lançamento em https://freebitco.in/

const reCAPTCHA_freeBITCOIN_ruCaptcha = 'ON';  // [ON / OFF] - Reconhecimento do reCAPTCHA v2 em https://freebitco.in/ via ruCaptcha.com / 2Captcha.com
const reCAPTCHA_freeBITCOIN_XCaptcha  = 'OFF';  // [ON / OFF] - Reconhecimento do reCAPTCHA v2 em https://freebitco.in/ via X-Captcha.ru

// [ Configurações №3 ]: Faucet https://freedoge.co.in/
const freeDOGECOIN                     = 'OFF';  // [ON / OFF] - Usar bot em https://freedoge.co.in/
const freeDOGECOIN_RandomTimer         = 'OFF';  // [ON / OFF] - Atraso aleatório de 30 segundos a 2 minutos antes do próximo lançamento em https://freedoge.co.in/

const reCAPTCHA_freeDOGECOIN_ruCaptcha = 'OFF';  // [ON / OFF] - Reconhecimento do reCAPTCHA v2 em https://freedoge.co.in/ via ruCaptcha.com / 2Captcha.com
const reCAPTCHA_freeDOGECOIN_XCaptcha  = 'OFF';  // [ON / OFF] - Reconhecimento do reCAPTCHA v2 em https://freedoge.co.in/ via X-Captcha.ru

// [ Configurações №4 ]: Faucet https://freenem.com/
const freeNEM	                  = 'ON';            // [ON / OFF] - Usar bot em https://freenem.com/
const freeNEM_Login               = 'gugatrb19@gmail.com';  // Login (obrigatório, porque a sessão é válida por apenas 3 horas)
const freeNEM_Password            = 'ggtrb123';  // Senha (pelo mesmo motivo)
const freeNEM_RandomTimer         = 'OFF';	          // [ON / OFF] - Atraso aleatório de 30 segundos a 2 minutos antes do próximo lançamento em https://freenem.com/

const reCAPTCHA_freeNEM_ruCaptcha = 'OFF';            // [ON / OFF] - Reconhecimento do reCAPTCHA v2 em https://freenem.com/ via ruCaptcha.com / 2Captcha.com
const reCAPTCHA_freeNEM_XCaptcha  = 'ON';            // [ON / OFF] - Reconhecimento do reCAPTCHA v2 em https://freenem.com/ via X-Captcha.ru
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 *  @description Resolvendo o reCAPTCHA v2 via https://ruCaptcha.com (http://discount.ruCaptcha.com) / http://2Captcha.com (http://discount.2Captcha.com)
 *  @author Group Din Din na Net - http://dindinnanet.com.br
 *
 *  @function solveReCaptcha_ruCaptcha
 *  @param { String } data_sitekey Site key
 *  @param { String } URL de pageurl da página na qual o reCAPTCHA v2 é reconhecido
 *  @param { Number } Parâmetro de solicitação invisível necessário para resolver o reCAPTCHA V2 invisível
 *  @returns { JSON } Um objeto que contém informações sobre uma solicitação bem-sucedida / malsucedida para o servidor - https://ruCaptcha.com (http://discount.ruCaptcha.com) / http://2Captcha.com (http: //discount.2Captcha. com)
 */
function solveReCaptcha_ruCaptcha(data_sitekey, pageurl, invisble) {
	var serverURL = 'http://discount.rucaptcha.com/';
	while (true) {
		iimPlayCode('SET !TIMEOUT_PAGE 60\nTAB OPEN\nTAB T=2\nURL GOTO=' + serverURL + 'in.php?key=' + apiKey_ruCaptcha + '&method=userrecaptcha&googlekey=' + data_sitekey + '&pageurl=' + pageurl + '&invisible=' + invisble + '&json=1&soft_id=2004');
		var answer = JSON.parse(window.content.document.getElementsByTagName('pre')[0].firstChild.data);
		if (!answer['status']) {
			if (answer['request'] === 'ERROR_NO_SLOT_AVAILABLE') {
                iimDisplay('[ ' + serverURL + ' ]: Error! Tentando resolver de novo...');
                log(pageurl, 'Error ' + serverURL + ' (' + answer['request'] + '). Alterando o servidor para a prioridade e tente novamente...');
                serverURL = 'http://rucaptcha.com/'; // => Nós mudamos o servidor para a prioridade, por causa da fila lotada no servidor com desconto
                iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
				continue;
			}
			iimDisplay('[ ' + serverURL + ' ]: Error! Tentando resolver de novo...');
            log(pageurl, 'Error ' + serverURL + ' (' + answer['request'] + '). Tentando mais uma vez resolver o captcha...');
            iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
			return { 'status' : 0, 'taskId' : 0, 'hash' : answer['request'], 'server' : serverURL }; // => { status : 0, taskId : 0, hash : ERROR_CODE, server : SERVER_URL }
		}
		var taskId = answer['request'];
		break;
	}

	iimPlayCode('WAIT SECONDS=10');

	var numberOfIterations = 1;
	while (numberOfIterations <= 30) {
		iimPlayCode('SET !TIMEOUT_PAGE 60\nURL GOTO=' + serverURL + 'res.php?key=' + apiKey_ruCaptcha + '&action=get&id=' + taskId + '&json=1');
		answer = JSON.parse(window.content.document.getElementsByTagName('pre')[0].firstChild.data);
		if (answer['status']) {
			iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
			break;
		} else {
			if (answer['request'] !== 'CAPCHA_NOT_READY') {
				iimDisplay('[ ' + serverURL + ' ]: Erro! Tentando resolver de novo...');
				log(pageurl, 'Error ' + serverURL + ' (' + answer['request'] + '). Tentando mais uma vez resolver o captcha...');
				iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
				return { 'status' : 0, 'taskId' : taskId, 'hash' : answer['request'], 'server' : serverURL }; // => { status : 0, taskId : 0, hash : ERROR_CODE, server : SERVER_URL }
			}

			if (numberOfIterations == 30) {
				iimDisplay('[ ' + serverURL + ' ]: O tempo de resposta expirou! Tentando novamente...');
				log(pageurl, 'O tempo de resposta expirou! Tente mais...');
				iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
				return { 'status' : 0, 'taskId' : taskId, 'hash' : answer['request'], 'server' : serverURL }; // => { status : 0, taskId : 0, hash : 'CAPCHA_NOT_READY', server : SERVER_URL }
			}

			iimDisplay('N° de Tentativas : ' + numberOfIterations);
			iimPlayCode('WAIT SECONDS=5'); // => 10 + 30 * 5 = 160 Segundos.
			numberOfIterations++;
		}
	}
	return { 'status' : answer['status'], 'taskId' : taskId, 'hash' : answer['request'], 'server' : serverURL };
}

/**
 *  @description Resolvendo captchas reCAPTCHA v2 via http://X-Captcha.ru/
 *  @author Group Din Din na Net - http://dindinnanet.com.br
 *
 *	@function solveReCaptcha_XCaptcha
 *  @param { String } data_sitekey Chave do site
 *  @param { String } pageurl URL a página na qual o reconhecimento ocorre reCAPTCHA v2
 *  @returns { JSON } Um objeto que contém informações sobre bem-sucedida / um pedido mal-sucedido para o servidor - http://x-captcha2.ru
 */
function solveReCaptcha_XCaptcha(data_sitekey, pageurl) {
    while (true) {
        iimPlayCode('SET !TIMEOUT_PAGE 60\nTAB OPEN\nTAB T=2\nURL GOTO=http://x-captcha2.ru/in.php?key=' + apiKey_XCaptcha + '&method=userrecaptcha&googlekey=' + data_sitekey + '&pageurl=' + pageurl + '&json=1');
        var answer = JSON.parse(window.content.document.getElementsByTagName('pre')[0].firstChild.data);
        if (!answer['request'].includes('OK')) {
            if ((answer['request'] === 'ERROR_NOT_SLOT_ZERO') || (answer['request'] === 'ERROR_NOT_SLOT_BUSY') || (answer['request'] === 'ERROR_PAUSE_SERVICE')) {
                iimDisplay('[ http://x-captcha2.ru/ ]: Erro! Tentando resolver de novo...');
                log(pageurl, 'Erro http://x-captcha2.ru/ (' + answer['request'] + '). Tentando novamente...');
                iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
				continue;
            }
            iimDisplay('[ http://x-captcha2.ru/ ] : Erro! Tentando resolver de novo...');
            log(pageurl, 'Erro http://x-captcha2.ru/ (' + answer['request'] + '). Tentando novamente...');
            iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
            return { 'status' : 0, 'taskId' : 0, 'hash' : answer['request'], 'server' : 'http://x-captcha2.ru/' }; // => { status : 0, taskId : 0, hash : ERROR_CODE, server : 'http://x-captcha2.ru/' }
        }
        var taskId = answer['request'].split('|')[1];
        break;
    }

	iimPlayCode('WAIT SECONDS=10');

	var numberOfIterations = 1;
	while (numberOfIterations <= 16) {
        iimPlayCode('SET !TIMEOUT_PAGE 60\nURL GOTO=http://x-captcha2.ru/res.php?key=' + apiKey_XCaptcha + '&id=' + taskId + '&json=1');
		answer = JSON.parse(window.content.document.getElementsByTagName('pre')[0].firstChild.data);
        if (answer['request'].includes('OK')) {
			iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
			break;
		}
		else {
			if (answer['request'] !== 'CAPCHA_NOT_READY') {
				iimDisplay('[ http://x-captcha2.ru/ ] : Erro! Tentando resolver de novo...');
                log(pageurl, 'Erro http://x-captcha2.ru/ (' + answer['request'] + '). Tentando mais uma vez resolver o captcha...');
                iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
				return { 'status' : 0, 'taskId' : taskId, 'hash' : answer['request'], 'server' : 'http://x-captcha2.ru/' }; // => { status : 0, taskId : identificator, hash : ERROR_CODE, server : 'http://x-captcha2.ru/' }
            }
            
            if (numberOfIterations == 16) {
                iimDisplay('[ http://x-captcha2.ru/ ]: O tempo de resposta expirou! Tentando novamente...');
				log(pageurl, 'O tempo de resposta expirou! Tentando novamente...');
				iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
				return { 'status' : 0, 'taskId' : taskId, 'hash' : answer['request'], 'server' : 'http://x-captcha2.ru/' }; // => { status : 0, taskId : 0, hash : 'CAPCHA_NOT_READY', server : 'http://x-captcha2.ru/' }
            }

			iimDisplay('N° de Tentativas: ' + numberOfIterations);
			iimPlayCode('WAIT SECONDS=5'); // => 10 + 16 * 5 = 90 Segundos.
			numberOfIterations++;
        }
	}
	return { 'status' : answer['status'], 'taskId' : taskId, 'hash' : answer['request'].split('|')[1], 'server' : 'http://x-captcha2.ru/' };
}

/**
 *  @description Resolvendo captchas de texto via https://ruCaptcha.com / http://2Captcha.com
 *  @author Group Din Din na Net - http://dindinnanet.com.br
 *
 *  @function solveTextCaptcha_ruCaptcha
 *  @param {String} URL de pageurl da página em que o captcha de texto é reconhecido
 * 	@param {String} captchaName O nome da imagem com captcha
 * 	@param {Number} minLen Número mínimo de caracteres na resposta
 * 	@param {Number} maxLen Número máximo de caracteres na resposta
 * 	@param {String} regsense Sensibilidade ao case - nem pergunte o que esta pohaaa - esta no site do 2captcha e rucaptcha
 * 	@returns {JSON} Um objeto que contém informações sobre uma solicitação bem-sucedida / mal-sucedida para o servidor - http://ruCaptcha.com / http://2Captcha.com
 */
function solveTextCaptcha_ruCaptcha(pageurl, captchaName, minLen, maxLen, regsense) {
	iimPlayCode('SET !ERRORIGNORE YES'
			+n+ 'SET !TIMEOUT_PAGE 60'
			+n+ 'SET !TIMEOUT_STEP 10'
			+n+ 'TAB OPEN'
			+n+ 'TAB T=2'
			+n+ 'URL GOTO=http://imacros2.rucaptcha.com/new/'
			+n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:getcapcha.php ATTR=NAME:key CONTENT=' + apiKey_ruCaptcha
			+n+ 'TAG POS=1 TYPE=INPUT:FILE FORM=ACTION:getcapcha.php ATTR=NAME:file CONTENT=' + captchaPath + captchaName
			+n+ 'TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ACTION:getcapcha.php ATTR=NAME:get_id CONTENT=YES'
			+n+ 'TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ACTION:getcapcha.php ATTR=NAME:regsense CONTENT=' + regsense
			+n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:getcapcha.php ATTR=NAME:min_len CONTENT=' + minLen
			+n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:getcapcha.php ATTR=NAME:max_len CONTENT=' + maxLen
			+n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:getcapcha.php ATTR=NAME:language CONTENT=2'
			+n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:getcapcha.php ATTR=NAME:numeric CONTENT=2'
			+n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:getcapcha.php ATTR=NAME:soft_id CONTENT=2004'
			+n+ 'SET !TIMEOUT_PAGE 100'
			+n+ 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ACTION:getcapcha.php ATTR=*');
	var result = window.content.document.querySelector("body").innerHTML;
	iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE');

	if (result.includes('OK'))
		return { 'status' : 1, 'taskId' : result.split('|')[1], 'hash' : result.split('|')[2], 'server' : 'http://rucaptcha.com/' };
	iimDisplay('[ http://rucaptcha.com/ ] : Erro! Tentando resolver de novo...');
	log(pageurl, 'Erro http://rucaptcha.com/ (' + result + '). Tentando mais uma vez resolver o captcha...');
	return { 'status' : 0, 'taskId' : 0, 'hash' : result, 'server' : 'http://rucaptcha.com/' }; // => { status : 0, taskId : 0, hash : ERROR_CODE, server : 'http://rucaptcha.com/' }
}

/**
 *  @description Enviando relatórios para respostas erradas de http://discount.rucaptcha.com / https://rucaptcha.com
 *  @author Group Din Din na Net - http://dindinnanet.com.br
 *
 *  @function reportCaptcha
 *  @param {String} URL serverURL do servidor de reconhecimento captcha
 *  @param {String} ID de tarefa do captcha resolvido incorretamente
 */
function reportCaptcha(serverURL, apiKey, taskId) {
	iimPlayCode('SET !ERRORIGNORE YES'
			+n+ 'SET !TIMEOUT_PAGE 30'
			+n+ 'TAB OPEN'
			+n+ 'TAB T=2'
			+n+ 'URL GOTO=' + serverURL + 'res.php?key=' + apiKey + '&action=reportbad&id=' + taskId
			+n+ 'TAB CLOSE');
}

/**
 *  @description Aguardando até o próximo encontro
 *  @author Group Din Din na Net - http://dindinnanet.com.br
 *
 *  @function timeTillNextRoll
 *  @param {String} URL do pageurl da página em que o timer foi detectado (para log.txt)
 * 	@param {String} pageurl_RandomTimer Atraso aleatório
 * 	@param {Number} segundos Tempo até o próximo lançamento em segundos
 */
function timeTillNextRoll(pageurl, pageurl_RandomTimer, seconds) {
	if (pageurl_RandomTimer === 'ON')
		seconds += Math.floor(Math.random () * 90 + 20);
	seconds += 10;	// => espera padrão

	iimDisplay('Time till next roll: ' + seconds + ' secs.'
		   +n+'dindinnanet.com.br'
		   +n+ 'Ganhos para esta sessão:'
		   +n+ '[ freebitco.in ]'
		   +n+ '\t# ' + Winnings_freeBITCOIN.toFixed(8) + ' BTC'
		   +n+ '\t# ' + Rewards_freeBITCOIN + ' Reward Points'
		   +n+ '\t# ' + Tickets_freeBITCOIN + ' Lottery Tickets'
		   +n+ '[ freedoge.co.in ]'
		   +n+ '\t# ' + Winnings_freeDOGECOIN.toFixed(8) + ' DOGE'
		   +n+ '[ freenem.com ]'
		   +n+ '\t# ' + Winnings_freeNEM.toFixed(8) + ' NEM');
	log(pageurl, 'Esperando ' + seconds + ' até o próximo roll...');
	iimPlayCode('WAIT SECONDS=' + seconds);
}

/**
 * 	@description Gerando um nome aleatório para o arquivo de texto com captcha de texto
 * 	@author Group Din Din na Net - http://dindinnanet.com.br
 *
 * 	@função timeTillNextRoll
 * 	@returns {String} O nome da imagem com captcha
 */
function makeUniqueName() {
    var text = 'FreeCrypto_';
    var possible = 'abcdefghijklmnopqrstuvwxyz0123456789';

    for(let i = 0; i <= 10; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    return text + '.jpg';
}

/**
 *  @description Logging
 * 	@author Group Din Din na Net - http://dindinnanet.com.br
 *
 *  @function log
 *  @param {String} URL do pageurl da página
 *  @param {String} message Novo registro
 */
function log(pageurl, message) {
	var text = '[ ' + new window.Date().toLocaleDateString() + ' ' + new window.Date().toLocaleTimeString() + ' ]: (' + pageurl + ') - ' + message + '\r\n';
	var fileDescriptor = imns.FIO.openNode(logPath);
	imns.FIO.appendTextFile(fileDescriptor, text);
}

/**
 *  @description Gerando um nome aleatório para um arquivo de texto com um captcha
 * 	@author Group Din Din na Net - http://dindinnanet.com.br
 *
 *	@function sendEmail
 *  @param { String } message Mensagem informativa que irá para o Email
 */
function sendEmail(message) {
	iimPlayCode('SET !ERRORIGNORE YES'
			+n+ 'SET !TIMEOUT_PAGE 60'
			+n+ 'SET !TIMEOUT_STEP 1'
			+n+ 'TAB OPEN'
			+n+ 'TAB T=2'
			+n+ 'URL GOTO=http://multicaptchabot.siteme.org/contacts.php'
			+n+ 'TAG POS=1 TYPE=INPUT:EMAIL FORM=ID:feedback-form ATTR=ID:email CONTENT=\"' + mail + '\"'
			+n+ 'TAG POS=1 TYPE=TEXTAREA FORM=ID:feedback-form ATTR=ID:message CONTENT=\"' + message + '\"'
			+n+ 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ID:feedback-form ATTR=*'
			+n+ 'TAB CLOSE');
}

/**
 *  @description Informing about the unsuccessful captcha solution
 *	@author Group Din Din na Net - http://dindinnanet.com.br
 *
 *  @function notificationsBadCaptcha
 *  @param {String} URL do pageurl da página
 */
function notificationsBadCaptcha(pageurl) {
	iimDisplay('Bot didn\'Decida o captcha 5 vezes seguidas. Volte um pouco mais tarde...');
	log(pageurl, 'Bot não decidiu captcha 5 vezes seguidas. Vamos voltar daqui a pouco...');
	sendEmail('( ' + pageurl + ' ) - Bot não decidiu captcha 5 vezes seguidas. Vamos voltar daqui a pouco...');
}

/**
 *  @description Informando o preenchimento incompleto dos dados iniciais
 *  @author Group Din Din na Net - http://dindinnanet.com.br
 *
 *  @função checkForInattention
 *  @returns {Boolean} Um sinalizador indicando o preenchimento incorreto dos dados iniciais
 */
function checkForInattention() {
    if ((freeBITCOIN === 'OFF') && (freeDOGECOIN === 'OFF') && (freeNEM === 'OFF')) {
        alert('Antes de iniciar o Script \"BOT_V1.0.js\" você deve condifgurar para ser usado corretamente. Seja cuidadoso!\n\nLinha - 32: const freeBITCOIN      = \'OFF\';\nLinha - 40: const freeDOGECOIN = \'OFF\';\nLinha - 47: const freeNEM             = \'OFF\';');
        return true;
    }

    if ((apiKey_ruCaptcha === '******************************') && (apiKey_XCaptcha === '******************************')) {
        alert('Antes de lançar o bot em um arquivo de texto \"BOT_V1.0.js\" precisa inserir API KEY serviço de reconhecimento(em vez de asteriscos), através de qual solução de captcha o bot Resolvera. Tenha cuidado!\n\nLinha - 27: const apiKey_ruCaptcha = \'******************************\';\nLinha - 28: const apiKey_XCaptcha  = \'******************************\';');
        return true;
    }

    // https://freebitco.in/ - - - - - >
    if ((freeBITCOIN === 'ON') && (reCAPTCHA_freeBITCOIN_ruCaptcha === 'OFF') && (reCAPTCHA_freeBITCOIN_XCaptcha === 'OFF')) {
        alert('Você ativou o bot para https://freebitco.in/, mas esqueceu de escolher o serviço para resolver o reCAPTCHA v2. Tenha cuidado!\n\nLinha - 36: const reCAPTCHA_freeBITCOIN_ruCaptcha = \'OFF\';\nLinha - 37: const reCAPTCHA_freeBITCOIN_XCaptcha  = \'OFF\';');
        return true;
    }

    if ((freeBITCOIN === 'ON') && (reCAPTCHA_freeBITCOIN_ruCaptcha === 'ON') && (apiKey_ruCaptcha === '******************************')) {
        alert('Você ativou o bot para https://freebitco.in/ e escolheu o serviço ruCaptcha.com, através do qual a Resolução será tomada reCAPTCHA v2, mas esqueceu de colocar a API KEY. Seja cuidadoso!\n\nLinha - 27: const apiKey_ruCaptcha = \'******************************\';');
        return true;
    }

    if ((freeBITCOIN === 'ON') && (reCAPTCHA_freeBITCOIN_XCaptcha === 'ON') && (apiKey_XCaptcha === '******************************')) {
        alert('Você ativou o bot para https://freebitco.in/ e escolheu o serviço X-Captcha.ru, através do qual a Resolução será tomada reCAPTCHA v2, mas esqueceu de colocar a API KEY. Seja cuidadoso!\n\nLinha - 28: const apiKey_XCaptcha = \'******************************\';');
        return true;
    }

    if ((freeBITCOIN === 'ON') && (apiKey_ruCaptcha === '******************************')) {
        alert('Você ativou o bot para https://freebitco.in/, mas esqueceu de inserir a API KEY do ruCaptcha.com, Seja cuidadoso!!\n\nLinha - 27: const apiKey_ruCaptcha = \'******************************\';');
        return true;
    }

    // https://freedoge.co.in/ - - - - - >
    if ((freeDOGECOIN === 'ON') && (reCAPTCHA_freeDOGECOIN_ruCaptcha === 'OFF') && (reCAPTCHA_freeDOGECOIN_XCaptcha === 'OFF')) {
        alert('Você ativou o bot para https://freedoge.co.in/, mas esqueci de escolher o serviço através do qual a solução irá ocorrer reCAPTCHA v2. Tenha cuidado!\n\nLinha - 43: const reCAPTCHA_freeDOGECOIN_ruCaptcha = \'OFF\';\nLinha - 44: const reCAPTCHA_freeDOGECOIN_XCaptcha  = \'OFF\';');
        return true;
    }

    if ((freeDOGECOIN === 'ON') && (reCAPTCHA_freeDOGECOIN_ruCaptcha === 'ON') && (apiKey_ruCaptcha === '******************************')) {
        alert('Você ativou o bot para https://freedoge.co.in/ e escolheu o serviço ruCaptcha.com, através do qual a Resolução será tomada reCAPTCHA v2, mas esqueceu de colocar a API KEY. Seja cuidadoso!\n\nLinha - 27: const apiKey_ruCaptcha = \'******************************\';');
        return true;
    }

    if ((freeDOGECOIN === 'ON') && (reCAPTCHA_freeDOGECOIN_XCaptcha === 'ON') && (apiKey_XCaptcha === '******************************')) {
        alert('Você ativou o bot para https://freedoge.co.in/ e escolheu o serviço X-Captcha.ru, através do qual a Resolução será tomada reCAPTCHA v2, mas esqueceu de colocar a API KEY. Seja cuidadoso!\n\nLinha - 28: const apiKey_XCaptcha = \'******************************\';');
        return true;
    }
    
    // https://freenem.com/ - - - - - >
    if ((freeNEM === 'ON') && (reCAPTCHA_freeNEM_ruCaptcha === 'OFF') && (reCAPTCHA_freeNEM_XCaptcha === 'OFF')) {
        alert('Você ativou o bot para https://frenem.com/, mas esqueceu de escolher o serviço através do qual a solução irá resolver reCAPTCHA v2. Tenha cuidado!\n\nLinha - 52: const reCAPTCHA_freeNEM_ruCaptcha = \'OFF\';\nLinha - 53: const reCAPTCHA_freeNEM_XCaptcha  = \'OFF\';');
        return true;
    }

    if ((freeNEM === 'ON') && (reCAPTCHA_freeNEM_ruCaptcha === 'ON') && (apiKey_ruCaptcha === '******************************')) {
        alert('Você ativou o bot para проекте https://frenem.com/ e escolheu o serviço ruCaptcha.com, através do qual uma decisão será tomada reCAPTCHA v2, mas esqueceu de colocar na API KEY. Tenha cuidado!\n\nLinha - 27: const apiKey_ruCaptcha = \'******************************\';');
        return true;
    }

    if ((freeNEM === 'ON') && (reCAPTCHA_freeNEM_XCaptcha === 'ON') && (apiKey_XCaptcha === '******************************')) {
        alert('Você ativou o bot para https://frenem.com/ e escolheu o serviço X-Captcha.ru, através do qual uma decisão será tomada reCAPTCHA v2, mas esqueceu de colocar na API KEY. Tenha cuidado!\n\nLinha - 28: const apiKey_XCaptcha = \'******************************\';');
        return true;
	}
	
	if ((freeNEM === 'ON') && ((freeNEM_Login === '*************') || (freeNEM_Password === '*************'))) {
		alert('Você ativou o bot para https://freenem.com/, Mas esqueci de especificar seu login e senha. Tenha cuidado!\n\nLinha - 48: const freeNEM_Login        = \'*************\';\n\nLinha - 49: const freeNEM_Password = \'*************\';');
		return true;
	}

    return false;
}
//---------------------------------------------------------------------------------------------------------------------------------------------------
const n = '\n';
var Winnings_freeBITCOIN = 0, Rewards_freeBITCOIN = 0, Tickets_freeBITCOIN = 0, Winnings_freeDOGECOIN = 0, Winnings_freeNEM = 0;

while (true) {
    if (checkForInattention())
        break;

	try {
		while (true) {
			// https://freebitco.in/ - - - - - >
			if (freeBITCOIN === 'ON') {
				freeBitcoinBody : {
					do {
						iimDisplay('Conectando ao https://freebitco.in/...');
						log('freebitco.in', 'Conectando...');
						iimPlayCode('SET !TIMEOUT_PAGE 30'
								+n+ 'TAB CLOSEALLOTHERS'
								+n+ 'TAB T=1'
								+n+ 'TAB CLOSE'
								+n+ 'URL GOTO=https://freebitco.in/?op=home'
								+n+ 'WAIT SECONDS=8');
						if (!window.content.document.getElementById('free_play_form_button')) {
							iimDisplay('Cloudflare protection foi detectado...');
							log('freebitco.in', 'Cloudflare Protection detectado...');
							iimPlayCode('WAIT SECONDS=20');
							continue;
						}
						break;
					} while (!window.content.document.getElementById('free_play_form_button'));

					if (/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)) {
						let timer = Number(/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)[1]) * 60 + Number(/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)[2]);
						timeTillNextRoll('freebitco.in', freeBITCOIN_RandomTimer, timer);
					}

					let solvingCaptchaCycles = 1, answer = null;
					freeBitcoinLabel:
					while (solvingCaptchaCycles <= 5) {
					    do {
							iimDisplay('Atualizando Página...');
							log('freebitco.in', 'Atualizando a página...');
							iimPlayCode('SET !TIMEOUT_PAGE 60'
									+n+ 'TAB CLOSEALLOTHERS'
									+n+ 'TAB T=1'
									+n+ 'TAB CLOSE'
									+n+ 'URL GOTO=https://freebitco.in/?op=home'
									+n+ 'WAIT SECONDS=8');
							if (!window.content.document.getElementById('free_play_form_button')) {
								iimDisplay('Cloudflare protection foi detectado...');
								log('freebitco.in', 'Cloudflare Protection detectado...');
								iimPlayCode('WAIT SECONDS=20');
								continue;
							}
							break;
						} while (!window.content.document.getElementById('free_play_form_button'));

                        if (/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)) {
                            iimDisplay('Houve uma exceção...');
                            log('freebitco.in', 'Houve uma exceção...');
                            break;
                        }
	
						if (freeBITCOIN_RewardPoints === 'ON') {
							let accountRewardPoints = Number(window.content.document.getElementsByClassName('user_reward_points')[0].innerHTML.replace(',', ''));
							if (!window.content.document.getElementById('bonus_container_free_points')) {
								if (accountRewardPoints < 12) { }
								else if ((accountRewardPoints >= 12 ) && (accountRewardPoints < 120)) {
									iimDisplay('Ativando 1 REWARD POINTS / ROLL...');
									log('freebitco.in', 'Ativando \'1 REWARD POINTS / ROLL\'');
									iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=BUTTON ATTR=ONCLICK:RedeemRPProduct(\'free_points_1\')\nWAIT SECONDS=1');
									accountRewardPoints -= 12;
								}
								else if ((accountRewardPoints >= 120) && (accountRewardPoints < 600)) {
									iimDisplay('Ativando 10 REWARD POINTS / ROLL...');
									log('freebitco.in', 'Ativando \'10 REWARD POINTS / ROLL\'');
									iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=BUTTON ATTR=ONCLICK:RedeemRPProduct(\'free_points_10\')\nWAIT SECONDS=1');
									accountRewardPoints -= 120;
								}
								else if ((accountRewardPoints >= 600) && (accountRewardPoints < 1200)) {
									iimDisplay('Ativando 50 REWARD POINTS / ROLL...');
									log('freebitco.in', 'Ativando \'50 REWARD POINTS / ROLL\'');
									iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=BUTTON ATTR=ONCLICK:RedeemRPProduct(\'free_points_50\')\nWAIT SECONDS=1');
									accountRewardPoints -= 600;
								}
								else {
									iimDisplay('Ativando 100 REWARD POINTS / ROLL...');
									log('freebitco.in', 'Ativando \'100 REWARD POINTS / ROLL\'');
									iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=BUTTON ATTR=ONCLICK:RedeemRPProduct(\'free_points_100\')\nWAIT SECONDS=1');
									accountRewardPoints -= 1200;
								}
							}
	
							if (!window.content.document.getElementById('bonus_container_fp_bonus')) {
								if (accountRewardPoints < 2800) { }
								else if ((accountRewardPoints >= 2800) && (accountRewardPoints < 4400)) {
									iimDisplay('Ativando 500% FREE BTC BONUS...');
									log('freebitco.in', 'Ativando \'500% FREE BTC BONUS\'');
									iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=BUTTON ATTR=ONCLICK:RedeemRPProduct(\'fp_bonus_500\')\nWAIT SECONDS=1');
								}
								else
								{
									iimDisplay('Ativando 1000% FREE BTC BONUS...');
									log('freebitco.in', 'Ativando \'1000% FREE BTC BONUS\'');
									iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=BUTTON ATTR=ONCLICK:RedeemRPProduct(\'fp_bonus_1000\')\nWAIT SECONDS=1');
								}
							}
						}

						if (window.content.document.getElementsByClassName('cc_banner cc_container cc_container--open').length)
							iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 1\nTAG POS=1 TYPE=A ATTR=TXT:Got<SP>it!');

						iimDisplay('Determinando tipo de captcha...');
						log('freebitco.in', 'Determinar o tipo de captcha na página...');
						window.scrollBy(0, 20000);

						if (window.content.document.getElementById('switch_captchas_button')) {
							iimDisplay('\'SWITCH CAPTCHA BUTTON\' é detectado. Escolhendo o dobro captchas.net. Resolvendo...');
							log('freebitco.in', 'Captchas.net duplo é detectado. Vamos tentar resolvê-lo...');

							let str = (window.content.document.getElementById("switch_captchas_button").onclick + ' ').split('\'')[1].split('\'')[0];
							if (str === 'double_captchas')
								iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nEVENT TYPE=CLICK SELECTOR=\'#switch_captchas_button\' BUTTON=0\nWAIT SECONDS=2.5');
				
							let captchasNet = window.content.document.getElementsByClassName('captchasnet_captcha_content');
							for (let i = 1; i <= captchasNet.length; i++) {
								let regsense = (i == 1) ? 'NO' : 'YES';
								let captchaName = makeUniqueName();
								iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nONDOWNLOAD FOLDER=' + captchaPath + ' FILE=' + captchaName + ' WAIT=YES\nTAG POS=' + i + ' TYPE=DIV ATTR=CLASS:captchasnet_captcha_content CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT');
								
								answer = solveTextCaptcha_ruCaptcha('freebitco.in', captchaName, 6, 6, regsense);
								if (!answer['status']) {
									if (solvingCaptchaCycles == 5) {
										notificationsBadCaptcha('freebitco.in');
										break freeBitcoinBody;
									}
									solvingCaptchaCycles++;
									continue freeBitcoinLabel;
								}

								iimPlayCode('SET !ERRORIGNORE YES'
										+n+ 'SET !TIMEOUT_STEP 10'
                                        +n+ 'WAIT SECONDS=2.5'
										+n+ 'TAG POS=' + i + ' TYPE=INPUT:TEXT ATTR=CLASS:captchasnet_captcha_input_box CONTENT=\"' + answer['hash'] + '\"'
										+n+ 'FILEDELETE NAME=' + captchaPath + captchaName);
							}
						} else {
							if (window.content.document.getElementById('g-recaptcha-response')) {
								iimDisplay('reCAPTCHA v2 foi detectado. Resolvendo...');
								log('freebitco.in', 'reCAPTCHA v2 foi detectado. Resolvendo...');

								window.content.document.getElementById('g-recaptcha-response').style.display = '';
								iimPlayCode('SET !ERRORIGNORE YES'
										+n+ 'SET !TIMEOUT_STEP 10'
										+n+ 'FRAME F=1'
										+n+ 'TAG POS=1 TYPE=DIV ATTR=ROLE:presentation&&CLASS:recaptcha-checkbox-checkmark&&TXT:'
										+n+ 'WAIT SECONDS=8');

								if (!window.content.document.getElementById('g-recaptcha-response').value.length) {
									let data_sitekey = window.content.document.getElementsByClassName('g-recaptcha')[0].getAttribute('data-sitekey');
                                    answer = (reCAPTCHA_freeBITCOIN_ruCaptcha === 'ON') ? solveReCaptcha_ruCaptcha(data_sitekey, 'https://freebitco.in/', 0) : solveReCaptcha_XCaptcha(data_sitekey, 'https://freebitco.in/');
                                    if (!answer['status']) {
                                        if (solvingCaptchaCycles == 5) {
                                            notificationsBadCaptcha('freebitco.in');
                                            break;
                                        }
                                        solvingCaptchaCycles++;
                                        continue;
                                    }
									iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nWAIT SECONDS=2.5\nTAG POS=1 TYPE=TEXTAREA FORM=ID:* ATTR=ID:g-recaptcha-response CONTENT=\"' + answer['hash'] + '\"');
								}
							} else if (window.content.document.getElementsByClassName('captchasnet_captcha_content').length) {
								iimDisplay('Captchas.net / Freebitco.in captcha personalizado é detectado. Resolvendo...');
								log('freebitco.in', 'Captchas.net foi detectado. Vamos tentar resolvê-lo...');
								
								let captchasNet = window.content.document.getElementsByClassName('captchasnet_captcha_content');
								for (let i = 1; i <= captchasNet.length; i++) {
									let regsense = (i == 1) ? 'NO' : 'YES';
									let captchaName = makeUniqueName();
									iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nONDOWNLOAD FOLDER=' + captchaPath + ' FILE=' + captchaName + ' WAIT=YES\nTAG POS=' + i + ' TYPE=DIV ATTR=CLASS:captchasnet_captcha_content CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT');
									
									answer = solveTextCaptcha_ruCaptcha('freebitco.in', captchaName, 6, 6, regsense);
									if (!answer['status']) {
										if (solvingCaptchaCycles == 5) {
											notificationsBadCaptcha('freebitco.in');
											break freeBitcoinBody;
										}
										solvingCaptchaCycles++;
										continue freeBitcoinLabel;
									}

									iimPlayCode('SET !ERRORIGNORE YES'
											+n+ 'SET !TIMEOUT_STEP 10'
											+n+ 'WAIT SECONDS=2.5'
											+n+ 'TAG POS=' + i + ' TYPE=INPUT:TEXT ATTR=CLASS:captchasnet_captcha_input_box CONTENT=\"' + answer['hash'] + '\"'
											+n+ 'FILEDELETE NAME=' + captchaPath + captchaName);
								}
							} else if (window.content.document.getElementById('adcopy-puzzle-image')) {
								iimDisplay('Solvemedia é detectado. Resolvendo...');
								log('freebitco.in', 'Solvemedia é detectado. Resolvendo...');

								let solveMedia = window.content.document.getElementById('adcopy-puzzle-image');
								let captchaName = makeUniqueName();
								iimPlayCode('SET !ERRORIGNORE YES'
										+n+ 'SET !TIMEOUT_STEP 10'
										+n+ 'TAG POS=1 TYPE=IMG ATTR=SRC:https://api-secure.solvemedia.com/media/reload-whV2.gif'
										+n+ 'WAIT SECONDS=10'
										+n+ 'ONDOWNLOAD FOLDER=' + captchaPath + ' FILE=' + captchaName + ' WAIT=YES'
										+n+ 'TAG POS=1 TYPE=DIV ATTR=ID:adcopy-puzzle-image CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT');
								
								answer = solveTextCaptcha_ruCaptcha('freebitco.in', captchaName, 0, 0, 'NO');
								if (!answer['status']) {
									if (solvingCaptchaCycles == 5) {
										notificationsBadCaptcha('freebitco.in');
										break;
									}
									solvingCaptchaCycles++;
									continue;
								}

                                iimPlayCode('SET !ERRORIGNORE YES'
                                        +n+ 'SET !TIMEOUT_PAGE 30'
										+n+ 'SET !TIMEOUT_STEP 10'
										+n+ 'WAIT SECONDS=2.5'
										+n+ 'TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:adcopy_response CONTENT=\"' + answer['hash']  + '\"'
										+n+ 'FILEDELETE NAME=' + captchaPath + captchaName);
							}
						}

						iimDisplay('Clamando satoshis...');
						log('freebitco.in', 'Colete Satoshis...');
						iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=INPUT:SUBMIT ATTR=ID:free_play_form_button\nWAIT SECONDS=8');

						if (Number(window.content.document.getElementById('winnings').innerHTML) > 0) {
							iimDisplay('Clamado com Successo!');
							log('freebitco.in', 'Clamado com Successo: ' + Number(window.content.document.getElementById('winnings').innerHTML) + ' BTC; ' + Number(window.content.document.getElementById('fp_reward_points_won').innerHTML) + ' Reward Points; ' + Number(window.content.document.getElementById('fp_lottery_tickets_won').innerHTML) + ' Lottery Tickets');
							Winnings_freeBITCOIN += Number(window.content.document.getElementById('winnings').innerHTML);
							Rewards_freeBITCOIN  += Number(window.content.document.getElementById('fp_reward_points_won').innerHTML);
							Tickets_freeBITCOIN  += Number(window.content.document.getElementById('fp_lottery_tickets_won').innerHTML);
							break;
						} else {
							if ((window.content.document.getElementById('free_play_error').style.display !== 'none') && (window.content.document.getElementById('free_play_error').innerText.includes('verify'))) {
								iimDisplay('A verificação de email é detectada...');
                                log('freebitco.in', 'Você deve confirmar o email para continuar coletando!');
                                sendEmail('( freebitco.in ) - Você deve confirmar o email para continuar coletando!');
								break;
							} else if ((window.content.document.getElementById('free_play_error').style.display !== 'none') && (window.content.document.getElementById('free_play_error').innerText.includes('blocked'))) {
								iimDisplay('Conta do https://freebitco.in/ foi banido...');
                                log('freebitco.in', 'Conta banida!');
                                sendEmail('( freebitco.in ) - Conta banida!');
								break;
							} else {
								iimDisplay('Captcha foi resolvido incorretamente. Enviando um relatório e tentando resolver o captcha novamente...');
								log('freebitco.in', 'Kapcha não foi resolvido corretamente. Enviando uma reclamação e tentando resolvê-la novamente...');
                                if (answer['server'].includes('rucaptcha.com')) {
                                    reportCaptcha(answer['server'], apiKey_ruCaptcha, answer['taskId']);
                                } else {
                                    reportCaptcha(answer['server'], apiKey_XCaptcha, answer['taskId']);
                                }
								
								if (solvingCaptchaCycles == 5) {
									notificationsBadCaptcha('freebitco.in');
									break;
								}
								solvingCaptchaCycles++;
								continue;
							}
						}
					}
				}
			}

			// https://freedoge.co.in/ - - - - - >
			if (freeDOGECOIN === 'ON') {
                do {
                    iimDisplay('Conectando-se https://freedoge.co.in/...');
                    log('freedoge.co.in', 'Conexão ao freedoge...');
                    iimPlayCode('SET !TIMEOUT_PAGE 30'
                            +n+ 'TAB CLOSEALLOTHERS'
                            +n+ 'TAB T=1'
                            +n+ 'TAB CLOSE'
                            +n+ 'URL GOTO=https://freedoge.co.in/'
                            +n+ 'WAIT SECONDS=8');

                    if (!window.content.document.getElementById('free_play_form_button')) {
                        iimDisplay('A proteção Cloudflare foi detectada...');
                        log('freedoge.co.in', 'Proteção contra cloudflare detectada...');
                        iimPlayCode('WAIT SECONDS=20');
                        continue;
                    }
                    break;
                } while (!window.content.document.getElementById('free_play_form_button'));

                if (/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)) {
                    let timer = Number(/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)[1]) * 60 + Number(/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)[2]);
                    timeTillNextRoll('freedoge.co.in', freeDOGECOIN_RandomTimer, timer);
                }
                
                let solvingCaptchaCycles = 1, answer = null;
                while (solvingCaptchaCycles <= 5) {
					do {
						iimDisplay('Atualizando a página...');
						log('freedoge.co.in', 'Atualizando a página...');
						iimPlayCode('SET !TIMEOUT_PAGE 60'
								+n+ 'TAB CLOSEALLOTHERS'
								+n+ 'TAB T=1'
								+n+ 'TAB CLOSE'
								+n+ 'URL GOTO=https://freedoge.co.in/'
								+n+ 'WAIT SECONDS=8');
						if (!window.content.document.getElementById('free_play_form_button')) {
							iimDisplay('A proteção Cloudflare foi detectada...');
							log('freedoge.co.in', 'Proteção contra cloudflare detectada...');
							iimPlayCode('WAIT SECONDS=20');
							continue;
						}
						break;
					} while (!window.content.document.getElementById('free_play_form_button'));

                    if (/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)) {
                        iimDisplay('Houve uma exceção...');
                        log('freedoge.co.in', 'Houve uma exceção...');
                        break;
					}
					
					if (window.content.document.getElementById('free_play_captcha_types').value === 'solvemedia') {
						iimDisplay('Selecionando reCAPTCHA v2...');
						log('freedoge.co.in', 'ReCAPTCHA v2 Selecionado...');
						iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=SELECT ATTR=ID:free_play_captcha_types CONTENT=%recaptcha_v2\nWAIT SECONDS=2');
					}
	
					if (window.content.document.getElementsByClassName('cc_banner cc_container cc_container--open').length)
						iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 1\nTAG POS=1 TYPE=A ATTR=TXT:Got<SP>it!');

                    iimDisplay('O reCAPTCHA v2 é detectado. Resolvendo...');
					log('freedoge.co.in', 'O reCAPTCHA v2 é detectado. Vamos tentar resolvê-lo...');
                    window.scrollBy(0, 20000);
                        
					window.content.document.getElementById('g-recaptcha-response').style.display = '';
					iimPlayCode('SET !ERRORIGNORE YES'
							+n+ 'SET !TIMEOUT_STEP 10'
							+n+ 'FRAME F=1'
							+n+ 'TAG POS=1 TYPE=DIV ATTR=ROLE:presentation&&CLASS:recaptcha-checkbox-checkmark&&TXT:'
							+n+ 'WAIT SECONDS=8');

					if (!window.content.document.getElementById('g-recaptcha-response').value.length) {
						let data_sitekey = window.content.document.getElementsByClassName('g-recaptcha')[0].getAttribute('data-sitekey');
                        answer = (reCAPTCHA_freeDOGECOIN_ruCaptcha === 'ON') ? solveReCaptcha_ruCaptcha(data_sitekey, 'https://freedoge.co.in/', 0) : solveReCaptcha_XCaptcha(data_sitekey, 'https://freedoge.co.in/');
                        if (!answer['status']) {
                            if (solvingCaptchaCycles == 5) {
                                notificationsBadCaptcha('freedoge.co.in');
                                break;
                            }
                            solvingCaptchaCycles++;
                            continue;
                        }
						iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nWAIT SECONDS=2.5\nTAG POS=1 TYPE=TEXTAREA FORM=ID:* ATTR=ID:g-recaptcha-response CONTENT=\"' + answer['hash'] + '\"');
					}

					iimDisplay('Clamando dogetoshis...');
					log('freedoge.co.in', 'Dogitoshi Clamado...');
					iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=INPUT:SUBMIT ATTR=ID:free_play_form_button\nWAIT SECONDS=8');

					if (Number(window.content.document.getElementById('winnings').innerHTML) > 0) {
						iimDisplay('Reivindicado com sucesso!');
						log('freedoge.co.in', 'Reivindicado com sucesso! Coletado: ' + Number(window.content.document.getElementById('winnings').innerHTML) + ' DOGE ');
						Winnings_freeDOGECOIN += Number(window.content.document.getElementById('winnings').innerHTML);
						break;
					} else {
						iimDisplay('Reivindicação sem sucesso!');
						if ((window.content.document.getElementById('free_play_error').style.display !== 'none') && (window.content.document.getElementById('free_play_error').innerText.includes('verify'))) {
							iimDisplay('A verificação de email é detectada...');
                            log('freedoge.co.in', 'Você deve confirmar o email para continuar coletando!');
                            sendEmail('( freedoge.co.in ) - Você deve confirmar o email para continuar coletando!');
							break;
						} else if ((window.content.document.getElementById('free_play_error').style.display !== 'none') && (window.content.document.getElementById('free_play_error').innerText.includes('blocked'))) {
							iimDisplay('Conta do https://freedoge.co.in/ foi banido...');
                            log('freedoge.co.in', 'Conta banida!');
                            sendEmail('( freedoge.co.in ) - Conta banida!');
							break;
						} else {
							iimDisplay('Captcha foi resolvido incorretamente. Enviando um relatório e tentando resolver o captcha novamente...');
							log('freedoge.co.in', 'Kapcha não foi resolvido corretamente. Enviando uma reclamação e tentando resolvê-la novamente...');
                            if (answer['server'].includes('rucaptcha.com')) {
                                reportCaptcha(answer['server'], apiKey_ruCaptcha, answer['taskId']);
                            } else {
                                reportCaptcha(answer['server'], apiKey_XCaptcha, answer['taskId']);
                            }
							
							if (solvingCaptchaCycles == 5) {
								notificationsBadCaptcha('freedoge.co.in');
								break;
							}
							solvingCaptchaCycles++;
							continue;
						}
					}
				}
			}

			// https://freenem.com/ - - - - - >
			if (freeNEM === 'ON') {
				freeNemBody : {
					let authorizationCycles = 1;
					while (authorizationCycles <= 5) {
						iimDisplay('Conectando-se https://freenem.com/...');
						log('freenem.com', 'Conectando-se https://freenem.com/...');
						iimPlayCode('SET !TIMEOUT_PAGE 60'
								+n+ 'TAB T=1'
								+n+ 'TAB CLOSEALLOTHERS'
								+n+ 'URL GOTO=https://freenem.com/free'
								+n+ 'WAIT SECONDS=8');

						if (!window.content.document.getElementsByClassName('main-button-2 roll-button').length) {
							iimDisplay('Logando no https://freenem.com/...');
							log('freenem.com', 'Autorizado no https://freenem.com/...');
							iimPlayCode('SET !ERRORIGNORE YES'
									+n+ 'SET !TIMEOUT_PAGE 30'
									+n+ 'SET !TIMEOUT_STEP 10'
									+n+ 'TAG POS=1 TYPE=INPUT:EMAIL ATTR=NAME:email CONTENT=' + freeNEM_Login
									+n+ 'SET !ENCRYPTION NO'
									+n+ 'TAG POS=1 TYPE=INPUT:PASSWORD ATTR=NAME:password CONTENT=' + freeNEM_Password
									+n+ 'TAG POS=1 TYPE=BUTTON ATTR=TXT:LOGIN!'
									+n+ 'WAIT SECONDS=8');
							
							if (!window.content.document.getElementsByClassName('main-button-2 roll-button').length) {
								let data_sitekey = window.content.document.getElementsByTagName('iframe')[0].src.split('?k=')[1].split('&co=')[0];                                
                                let answer = (reCAPTCHA_freeNEM_ruCaptcha === 'ON') ? solveReCaptcha_ruCaptcha(data_sitekey, 'https://freenem.com/', 1) : solveReCaptcha_XCaptcha(data_sitekey, 'https://freenem.com/');
                                if (!answer['status']) {
                                    if (authorizationCycles == 5) {
                                        notificationsBadCaptcha('freenem.com');
                                        break freeNemBody;
                                    }
                                    authorizationCycles++;
                                    continue;
                                }

								iimPlayCode('SET !ERRORIGNORE YES'
										+n+ 'SET !TIMEOUT_PAGE 30'
										+n+ 'SET !TIMEOUT_STEP 10'
										+n+ 'TAG POS=1 TYPE=TEXTAREA FORM=ID:* ATTR=ID:g-recaptcha-response CONTENT=\"' + answer['hash'] + '\"'
										+n+ 'WAIT SECONDS=8');

								 if (!window.content.document.getElementsByClassName('main-button-2 roll-button').length) {
										iimDisplay('Captcha foi resolvido incorretamente. Enviando um relatório e tentando resolver o captcha novamente...');
										log('freenem.com', 'Kapcha não foi resolvido corretamente. Enviando uma reclamação e tentando resolvê-la novamente...');
                                        if (answer['server'].includes('rucaptcha.com')) {
                                            reportCaptcha(answer['server'], apiKey_ruCaptcha, answer['taskId']);
                                        } else {
                                            reportCaptcha(answer['server'], apiKey_XCaptcha, answer['taskId']);
                                        }
										
										if (authorizationCycles == 5) {
											notificationsBadCaptcha('freenem.com');
											break freeNemBody;
										}
										authorizationCycles++;
										continue;
								}
								iimDisplay('Autorização bem sucedida...');
								log('freenem.com', 'Autorização bem sucedida...');
								break;
							}
						}
						break;
					}

					let timer = Number(window.content.document.getElementsByClassName('digits')[0].innerHTML * 60) + Number(window.content.document.getElementsByClassName('digits')[1].innerHTML);
					if (timer > 0)
						timeTillNextRoll('freenem.com', freeNEM_RandomTimer, timer);

					let solvingCaptchaCycles = 1;
					while (solvingCaptchaCycles <= 5) {
						iimDisplay('Atualizando a página e resolvendo o reCAPTCHA v2...');
						log('freenem.com', 'Atualizamos a página e tentando resolver o Invisible reCAPTCHA v2...');
						iimPlayCode('SET !ERRORIGNORE YES'
								+n+ 'SET !TIMEOUT_PAGE 60'
								+n+ 'SET !TIMEOUT_STEP 10'
								+n+ 'TAB CLOSEALLOTHERS'
								+n+ 'TAB T=1'
								+n+ 'TAB CLOSE'
								+n+ 'URL GOTO=https://freenem.com/free'
                                +n+ 'WAIT SECONDS=8');
                                
                        timer = Number(window.content.document.getElementsByClassName('digits')[0].innerHTML * 60) + Number(window.content.document.getElementsByClassName('digits')[1].innerHTML);
                        if (timer > 0) {
							iimDisplay('Houve uma exceção...');
							log('freenem.com', 'Houve uma exceção...');
                            break freeNemBody;
                        }

                        iimPlayCode('SET !ERRORIGNORE YES'
                                +n+ 'SET !TIMEOUT_PAGE 60'
                                +n+ 'SET !TIMEOUT_STEP 10'
                                +n+ 'TAG POS=1 TYPE=BUTTON ATTR=TXT:ROLL!'
                                +n+ 'WAIT SECONDS=8');

						let winningDuringLastSession = Number(window.content.document.getElementsByClassName('result')[0].innerHTML.split(' ')[3]);
						if (!isNaN(winningDuringLastSession) || (winningDuringLastSession > 0)) {
							iimDisplay('Reivindicado com sucesso!');
							log('freenem.com', ' Coletado com Sucesso! Coletado: ' + winningDuringLastSession + ' NEM');
							Winnings_freeNEM += winningDuringLastSession;
							break;
						} else {
							let data_sitekey = window.content.document.getElementsByTagName('iframe')[0].src.split('?k=')[1].split('&co=')[0];
                            let answer = (reCAPTCHA_freeNEM_ruCaptcha === 'ON') ? solveReCaptcha_ruCaptcha(data_sitekey, 'https://freenem.com/', 1) : solveReCaptcha_XCaptcha(data_sitekey, 'https://freenem.com/');
                            if (!answer['status']) {
                                if (authorizationCycles == 5) {
                                    notificationsBadCaptcha('freenem.com');
                                    break freeNemBody;
                                }
                                authorizationCycles++;
                                continue;
                            }

							iimDisplay('Reivindicando NEM...');
							log('freenem.com', 'Reivindicando NEM...');
							iimPlayCode('SET !ERRORIGNORE YES'
									+n+ 'SET !TIMEOUT_PAGE 30'
									+n+ 'SET !TIMEOUT_STEP 10'
									+n+ 'WAIT SECONDS=2.5'
									+n+ 'TAG POS=1 TYPE=TEXTAREA FORM=ID:* ATTR=ID:g-recaptcha-response CONTENT=\"' + answer['hash'] + '\"'
									+n+ 'ONDIALOG POS=1 BUTTON=OK CONTENT='
									+n+ 'WAIT SECONDS=8');
								
							winningDuringLastSession = Number(window.content.document.getElementsByClassName('result')[0].innerHTML.split(' ')[3]);
							if (!isNaN(winningDuringLastSession) || (winningDuringLastSession > 0)) {
								iimDisplay('Reivindicado com sucesso!');
								log('freenem.com', 'Coletado com Sucesso! Coletado: ' + winningDuringLastSession + ' NEM');
								Winnings_freeNEM += winningDuringLastSession;
								break;
							} else {
								iimDisplay('Captcha foi resolvido incorretamente. Enviando um relatório e tentando resolver o captcha novamente...');
								log('freenem.com', 'Kapcha não foi resolvido corretamente. Enviando uma reclamação e tentando resolvê-la novamente...');
                                if (answer['server'].includes('rucaptcha.com')) {
                                    reportCaptcha(answer['server'], apiKey_ruCaptcha, answer['taskId']);
                                } else {
                                    reportCaptcha(answer['server'], apiKey_XCaptcha, answer['taskId']);
                                }
								if (solvingCaptchaCycles == 5) {
									notificationsBadCaptcha('freenem.com');
									break;
								}
								solvingCaptchaCycles++;
								continue;
							}
						}
					}
				}
            }
		}
	}
	catch (e) {
	 	log('RESTART', 'Houve um erro na operação do bot, verifique a conexão com a Internet! O bot será reiniciado após 30 segundos...');
        iimDisplay('Houve um erro na operação do bot, verifique a conexão com a Internet! O bot será reiniciado após 30 segundos....');
         
        let errorMessage = 'Ocorreu um erro, verifique sua conexão com a internet! Vou reiniciar em 30 segundos :)';
		iimPlayCode('SET !ERRORIGNORE YES'
				+n+ 'SET !TIMEOUT_PAGE 60'
				+n+ 'SET !TIMEOUT_STEP 1'
				+n+ 'TAB CLOSEALLOTHERS'
				+n+ 'TAB T=1'
				+n+ 'URL GOTO=http://multicaptchabot.siteme.org/contacts.php'
				+n+ 'TAG POS=1 TYPE=INPUT:EMAIL FORM=ID:feedback-form ATTR=ID:email CONTENT=\"' + mail + '\"'
				+n+ 'TAG POS=1 TYPE=TEXTAREA FORM=ID:feedback-form ATTR=ID:message CONTENT=\"' + errorMessage + '\"'
				+n+ 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ID:feedback-form ATTR=*'
				+n+ 'TAB CLOSE'
				+n+ 'WAIT SECONDS=30');
	}
}