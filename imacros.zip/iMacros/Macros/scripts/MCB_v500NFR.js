﻿/*	
	[ freebitco.in / freedoge.co.in / freenem.com [ MultiCaptcha bot] | MCB_v500NFR.js | February 19, 2018 ]
	
    1) Настройте браузер перед запуском согласно инструкции на сайте: https://multicaptchabot.wixsite.com/multicaptchabot/instruction;
    2) Обязательно войдите в свои аккаунты на всех сайтах, на которых Вы будете использовать бота;
    3) Зарегестрируйтесь и пополните счет на сервисе распознавания капчи - ruCaptcha.com;
    4) Внимание! Не забудьте:
        1. Создать папку MultiCaptcha_bot на диске C;
        2. Вставить Ваш API KEY с сервиса ruCaptcha.com(https://rucaptcha.com/enterpage) / 2Captcha.com (Строка №25);
        3. Активировать нужные краны (Строки №28, 33, 37);
        4. Активировать дополнительные функции на используемых проектах (Строки №28 - 40).

	Какие-то сбои в работе бота или нужна помощь в его настройке?
	Связь со мной: 
                  1) Почта: multicaptchabot@ya.ru
                  2) Сайт: https://multicaptchabot.wixsite.com/multicaptchabot
                  3) ruCaptcha: https://rucaptcha.com/software/view/freebitcoin-multicaptcha-bot
*/

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// [ Блок 1 ] : Пользовательские настройки
const captchaPath      = 'C:\\MultiCaptcha_bot\\';         // Путь для загрузки текстовых капч (если будете менять путь, НЕ ЗАБУДЬТЕ про двойные слеши)
const logPath 	       = 'C:\\MultiCaptcha_bot\\log.txt';  // Путь для файла с логом (если будете менять путь, НЕ ЗАБУДЬТЕ про двойные слеши)

const apiKey_ruCaptcha = '9727fef187729a506869b64a70580515'; // Ваш API KEY с сервиса ruCaptcha.com (https://rucaptcha.com/enterpage) / 2Captcha.com

// [ Блок 2 ] : Кран freebitco.in
const freeBITCOIN              = 'ON';  // [ON / OFF] - Активировать бота на проекте https://freebitco.in/
const freeBITCOIN_RewardPoints = 'ON';  // [ON / OFF] - Авто-использование Reward Points на сайте https://freebitco.in/ (Шаг 4* : https://multicaptchabot.wixsite.com/multicaptchabot/instruction)
const freeBITCOIN_RandomTimer  = 'OFF';  // [ON / OFF] - Случайный таймер от 30 секунд до 2-х минут перед следующим сбором на сайте https://freebitco.in/

// [ Блок 3 ] : Кран freedoge.co.in
const freeDOGECOIN             = 'OFF';  // [ON / OFF] - Активировать бота на проекте https://freedoge.co.in/
const freeDOGECOIN_RandomTimer = 'OFF';  // [ON / OFF] - Случайный таймер от 30 секунд до 2-х минут перед следующим сбором на сайте https://freedoge.co.in/

// [ Блок 4 ] : Кран freenem.com
const freeNEM	               = 'OFF';            // [ON / OFF] - Активировать бота на проекте https://freenem.com/
const freeNEM_Login            = 'gugatrb19@gmail.com';  // Ваш логин на проекте https://freenem.com/ (Это необходимо, т.к. сайт спустя некоторое время завершает сессию и приходиться авторизироваться снова)
const freeNEM_Password         = 'ggtrb123';  // Ваш пароль на проекте https://freenem.com/ (Причина аналогична описанной выше)
const freeNEM_RandomTimer      = 'OFF';	           // [ON / OFF] - Случайный таймер от 30 секунд до 2-х минут перед следующим сбором на сайте https://freenem.com/
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function solveReCaptcha_ruCaptcha(data_sitekey, pageurl, invisble) {
	iimPlayCode('SET !TIMEOUT_PAGE 60'
				+n+ 'TAB OPEN'
				+n+ 'TAB T=2'
				+n+ 'URL GOTO=http://rucaptcha.com/in.php?key=' + apiKey_ruCaptcha + '&method=userrecaptcha&googlekey=' + data_sitekey + '&pageurl=' + pageurl + '&invisible=' + invisble + '&json=1&soft_id=2004');

	var answer = JSON.parse(window.content.document.getElementsByTagName('pre')[0].firstChild.data);
	if (!answer['status']) {
		iimDisplay('[ ruCaptcha.com ] : Error! Trying to solve again...');
		log(pageurl, 'Ошибка ruCaptcha.com(' + answer['request'] + '). Пытаемся еще раз решить капчу...');
		return { 'status' : 0, 'taskId' : 0, 'hash' : answer['request'] }; // => { status : 0, taskId : 0, hash : * ERROR_1 }
	}
	var taskId = answer['request'];

	iimPlayCode('WAIT SECONDS=10');

	var numberOfIterations = 1;
	while (numberOfIterations <= 30) {
		iimPlayCode('SET !TIMEOUT_PAGE 60\nURL GOTO=http://rucaptcha.com/res.php?key=' + apiKey_ruCaptcha + '&action=get&id=' + taskId + '&json=1');
		answer = JSON.parse(window.content.document.getElementsByTagName('pre')[0].firstChild.data);
		if (answer['status']) {
			iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
			break;
		}
		else {
			if (answer['request'] !== 'CAPCHA_NOT_READY') {
				iimDisplay('[ ruCaptcha.com ] : Error! Trying to solve again...');
				log(pageurl, 'Ошибка ruCaptcha.com(' + answer['request'] + '). Пытаемся еще раз решить капчу...');
				return { 'status' : 0, 'taskId' : taskId, 'hash' : answer['request'] }; // => { status : 0, taskId : identificator, hash : * ERROR_2 }
			}
			iimDisplay('Iteration number : ' + numberOfIterations);
			iimPlayCode('WAIT SECONDS=5');
			numberOfIterations++;
		}
	}
	return { 'status' : answer['status'], 'taskId' : taskId, 'hash' : answer['request'] };
}

function solveTextCaptcha_ruCaptcha(pageurl, captchaName, minLen, maxLen, regsense) {
	iimPlayCode('SET !ERRORIGNORE YES'
			+n+ 'SET !TIMEOUT_PAGE 60'
			+n+ 'SET !TIMEOUT_STEP 10'
			+n+ 'TAB OPEN'
			+n+ 'TAB T=2'
			+n+ 'URL GOTO=http://imacros2.rucaptcha.com/new/'
			+n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:getcapcha.php ATTR=NAME:key CONTENT=' + apiKey_ruCaptcha
			+n+ 'TAG POS=1 TYPE=INPUT:FILE FORM=ACTION:getcapcha.php ATTR=NAME:file CONTENT=' + captchaPath + captchaName
			+n+ 'TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ACTION:getcapcha.php ATTR=NAME:get_id CONTENT=YES'
			+n+ 'TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ACTION:getcapcha.php ATTR=NAME:regsense CONTENT=' + regsense
			+n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:getcapcha.php ATTR=NAME:min_len CONTENT=' + minLen
			+n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:getcapcha.php ATTR=NAME:max_len CONTENT=' + maxLen
			+n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:getcapcha.php ATTR=NAME:language CONTENT=2'
			+n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:getcapcha.php ATTR=NAME:numeric CONTENT=2'
			+n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:getcapcha.php ATTR=NAME:soft_id CONTENT=2004'
			+n+ 'SET !TIMEOUT_PAGE 100'
			+n+ 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ACTION:getcapcha.php ATTR=*');
	var result = window.content.document.querySelector("body").innerHTML;
	iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE');

	if (result.includes('OK')) {
		return { 'status' : 1, 'taskId' : result.split('|')[1], 'hash' : result.split('|')[2] };
	}

	iimDisplay('[ ruCaptcha.com ] : Error! Trying to solve again...');
	log(pageurl, 'Ошибка ruCaptcha.com(' + result + '). Пытаемся еще раз решить капчу...');
	return { 'status' : 0, 'taskId' : 0, 'hash' : result }; // => { status : 0, taskId : 0, hash : * ERROR }
}

function reportCaptcha(apiKey, taskId) {
	iimPlayCode('SET !ERRORIGNORE YES'
			+n+ 'SET !TIMEOUT_PAGE 30'
			+n+ 'SET !TIMEOUT_STEP 10'
			+n+ 'TAB OPEN'
			+n+ 'TAB T=2'
			+n+ 'URL GOTO=http://rucaptcha.com/res.php?key=' + apiKey + '&action=reportbad&id=' + taskId
			+n+ 'TAB CLOSE');
}

function timeTillNextRoll(pageurl, pageurl_RandomTimer, seconds) {
	if (pageurl_RandomTimer === 'ON') {
		seconds += Math.floor(Math.random () * 90 + 30);
	}
	else {
		seconds += 10;	// * default waiting
	}

	iimDisplay('Time till next roll: ' + seconds + ' secs.'
		   +n+ 'Earnings during this session:'
		   +n+ '[ freebitco.in ]'
		   +n+ '\t# ' + Winnings_freeBITCOIN.toFixed(8) + ' BTC'
		   +n+ '\t# ' + Rewards_freeBITCOIN + ' Reward Points'
		   +n+ '\t# ' + Tickets_freeBITCOIN + ' Lottery Tickets'
		   +n+ '[ freedoge.co.in ]'
		   +n+ '\t# ' + Winnings_freeDOGECOIN.toFixed(8) + ' DOGE'
		   +n+ '[ freenem.com ]'
		   +n+ '\t# ' + Winnings_freeNEM.toFixed(8) + ' NEM');
	log(pageurl, 'Ожидание ' + seconds + ' до следующего сбора...');

	iimPlayCode('WAIT SECONDS=' + seconds);
	return;
}

function makeUniqueName() {
    var text = 'FreeCrypto_';
    var possible = 'abcdefghijklmnopqrstuvwxyz0123456789';

    for(let i = 0; i <= 10; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    text += '.jpg';

    return text;
}

function log (pageurl, message) {
	var text = '[ ' + new window.Date().toLocaleDateString() + ' ' + new window.Date().toLocaleTimeString() + ' ]: (' + pageurl + ') - ' + message + '\r\n';
	appendToFile(text);
}

function appendToFile(text) {
	var fileDescriptor = imns.FIO.openNode(logPath);
	imns.FIO.appendTextFile(fileDescriptor, text);
}

function notificationsBadCaptcha(project) {
	iimDisplay('Bot didn\'t decide captcha 5 times in a row. Come back a little later...');
	log(project, 'Бот не решил капчу 5 раз подряд. Вернемся чуть позже...');
}

function checkForInattention() {
    if ((freeBITCOIN === 'OFF') && (freeDOGECOIN === 'OFF') && (freeNEM === 'OFF')) {
        alert('Перед запуском бота в текстовом файле \"MCB_v501FR.js\" необходимо выбрать хотя бы один проект, который будет использоваться. Будьте внимательны!\n\nСтрока №28: const freeBITCOIN      = \'OFF\';\nСтрока №33: const freeDOGECOIN = \'OFF\';\nСтрока №37: const freeNEM             = \'OFF\';');
        return true;
    }

    if (apiKey_ruCaptcha === '*******************') {
        alert('Перед запуском бота в текстовом файле \"MCB_v501FR.js\" необходимо вместо звездочек вставить свой API KEY сервиса ruCaptcha.com (https://rucaptcha.com/enterpage) / 2Captcha.com. Будьте внимательны!\n\nСтрока №25: const apiKey_ruCaptcha = \'*******************\';');
        return true;
    }

    return false;
}
//---------------------------------------------------------------------------------------------------------------------------------------------------
const n = '\n';
var Winnings_freeBITCOIN = 0, Rewards_freeBITCOIN = 0, Tickets_freeBITCOIN = 0, Winnings_freeDOGECOIN = 0, Winnings_freeNEM = 0;

while(true)
{
    // Функция, которая в теории должна избавить меня от глупых вопросов на почту...
    if (checkForInattention()) {
        break;
    }

	try {
		while (true)
		{
			// https://freebitco.in/ - - - - - >
			if (freeBITCOIN === 'ON') {
				freeBitcoinBody : {
					do {
						iimDisplay('Connecting to the https://freebitco.in/...');
						log('https://freebitco.in/', 'Подключение к проекту...');
						iimPlayCode('SET !TIMEOUT_PAGE 30'
								+n+ 'TAB CLOSEALLOTHERS'
								+n+ 'TAB T=1'
								+n+ 'TAB CLOSE'
								+n+ 'URL GOTO=https://freebitco.in/?op=home'
								+n+ 'WAIT SECONDS=8');
						if (!window.content.document.getElementById('free_play_form_button')) {
							iimDisplay('Cloudflare protection is detected...');
							log('https://freebitco.in/', 'Обнаружена \'Cloudflare protection\'...');
							iimPlayCode('WAIT SECONDS=20');
							continue;
						}
						break;
					} while (!window.content.document.getElementById('free_play_form_button'));

					if (/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)) {
						let timer = +(/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName("title")[0].innerText)[1]) * 60 + +(/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName("title")[0].innerText)[2]);
						timeTillNextRoll('https://freebitco.in/', freeBITCOIN_RandomTimer, timer);
					}

                    if (!window.content.document.getElementById('free_play_form_button')) {
                        do {
                            iimDisplay('Connecting to the https://freebitco.in/...');
                            log('https://freebitco.in/', 'Подключение к проекту...');
                            iimPlayCode('SET !TIMEOUT_PAGE 30'
                                    +n+ 'TAB CLOSEALLOTHERS'
                                    +n+ 'TAB T=1'
                                    +n+ 'TAB CLOSE'
                                    +n+ 'URL GOTO=https://freebitco.in/?op=home'
                                    +n+ 'WAIT SECONDS=8');
                            if (!window.content.document.getElementById('free_play_form_button')) {
                                iimDisplay('Cloudflare protection is detected...');
                                log('https://freebitco.in/', 'Обнаружена \'Cloudflare protection\'...');
                                iimPlayCode('WAIT SECONDS=20');
                                continue;
                            }
                            break;
                        } while (!window.content.document.getElementById('free_play_form_button'));
                    }

					if (window.content.document.getElementsByClassName('cc_banner cc_container cc_container--open').length) {
						iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 1\nTAG POS=1 TYPE=A ATTR=TXT:Got<SP>it!');
					}

					if (freeBITCOIN_RewardPoints === 'ON') {
						let accountRewardPoints = +window.content.document.getElementsByClassName('user_reward_points')[0].innerHTML.replace(',','');
						if (!window.content.document.getElementById('bonus_container_free_points')) {
							if (accountRewardPoints < 12) {
								;
							}
							else if ((accountRewardPoints >= 12 ) && (accountRewardPoints < 120)) {
								iimDisplay('Activating 1 REWARD POINTS / ROLL...');
								log('https://freebitco.in/', 'Активируем \'1 REWARD POINTS / ROLL\'');
								iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=BUTTON ATTR=ONCLICK:RedeemRPProduct(\'free_points_1\')\nWAIT SECONDS=1');
								accountRewardPoints -= 12;
							}
							else if ((accountRewardPoints >= 120) && (accountRewardPoints < 600)) {
								iimDisplay('Activating 10 REWARD POINTS / ROLL...');
								log('https://freebitco.in/', 'Активируем \'10 REWARD POINTS / ROLL\'');
								iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=BUTTON ATTR=ONCLICK:RedeemRPProduct(\'free_points_10\')\nWAIT SECONDS=1');
								accountRewardPoints -= 120;
							}
							else if ((accountRewardPoints >= 600) && (accountRewardPoints < 1200)) {
								iimDisplay('Activating 50 REWARD POINTS / ROLL...');
								log('https://freebitco.in/', 'Активируем \'50 REWARD POINTS / ROLL\'');
								iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=BUTTON ATTR=ONCLICK:RedeemRPProduct(\'free_points_50\')\nWAIT SECONDS=1');
								accountRewardPoints -= 600;
							}
							else {
								iimDisplay('Activating 100 REWARD POINTS / ROLL...');
								log('https://freebitco.in/', 'Активируем \'100 REWARD POINTS / ROLL\'');
								iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=BUTTON ATTR=ONCLICK:RedeemRPProduct(\'free_points_100\')\nWAIT SECONDS=1');
								accountRewardPoints -= 1200;
							}
						}

						if (!window.content.document.getElementById('bonus_container_fp_bonus')) {
							if (accountRewardPoints < 2800) {
								;
							}
							else if ((accountRewardPoints >= 2800) && (accountRewardPoints < 4400)) {
								iimDisplay('Activating 500% FREE BTC BONUS...');
								log('https://freebitco.in/', 'Активируем \'500% FREE BTC BONUS\'');
								iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=BUTTON ATTR=ONCLICK:RedeemRPProduct(\'fp_bonus_500\')\nWAIT SECONDS=1');
							}
							else
							{
								iimDisplay('Activating 1000% FREE BTC BONUS...');
								log('https://freebitco.in/', 'Активируем \'1000% FREE BTC BONUS\'');
								iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=BUTTON ATTR=ONCLICK:RedeemRPProduct(\'fp_bonus_1000\')\nWAIT SECONDS=1');
							}
						}
					}

					let solvingCaptchaCycles = 1, answer = null;
					freeBitcoinLabel:
					while (solvingCaptchaCycles <= 5) {
					    do {
							iimDisplay('Refreshing page...');
							log('https://freebitco.in/', 'Обновляем страницу...');
							iimPlayCode('SET !TIMEOUT_PAGE 60'
									+n+ 'TAB CLOSEALLOTHERS'
									+n+ 'TAB T=1'
									+n+ 'TAB CLOSE'
									+n+ 'URL GOTO=https://freebitco.in/?op=home'
									+n+ 'WAIT SECONDS=8');
							if (!window.content.document.getElementById('free_play_form_button')) {
								iimDisplay('Cloudflare protection is detected...');
								log('https://freebitco.in/', 'Обнаружена \'Cloudflare protection\'...');
								iimPlayCode('WAIT SECONDS=20');
								continue;
							}
							break;
						} while (!window.content.document.getElementById('free_play_form_button'));

                        if (/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)) {
                            iimDisplay('There was an exception...');
                            //log('https://freebitco.in/', 'Произошел отлов исключительной ситуации...');
                            break;
                        }

						iimDisplay('Determining type of captcha...');
						log('https://freebitco.in/', 'Определяем тип капчи на странице...');
						window.scrollBy(0, 20000);

						if (window.content.document.getElementById('switch_captchas_button'))
						{
							iimDisplay('\'SWITCH CAPTCHA BUTTON\' is detected. Choosing double captchas.net. Solving...');
							log('https://freebitco.in/', 'Двойная captchas.net обнаружена. Попытаемся ее решить...');

							let str = (window.content.document.getElementById("switch_captchas_button").onclick + ' ').split('\'')[1].split('\'')[0];
							if (str == 'double_captchas') {
								iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 1\nEVENT TYPE=CLICK SELECTOR=\'#switch_captchas_button\' BUTTON=0\nWAIT SECONDS=2.5');
							}
				
							let captchasNet = window.content.document.getElementsByClassName('captchasnet_captcha_content');
							for (let i = 1; i <= captchasNet.length; i++) {
								let regsense = (i == 1) ? "NO" : "YES";
								let captchaName = makeUniqueName();
								iimPlayCode('SET !ERRORIGNORE YES'
										+n+ 'SET !TIMEOUT_STEP 10'
										+n+ 'ONDOWNLOAD FOLDER=' + captchaPath + ' FILE=' + captchaName + ' WAIT=YES'
										+n+ 'TAG POS=' + i + ' TYPE=DIV ATTR=CLASS:captchasnet_captcha_content CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT');
								
								answer = solveTextCaptcha_ruCaptcha('https://freebitco.in/', captchaName, 6, 6, regsense);
								if (!answer['status']) {
									if (solvingCaptchaCycles == 5) {
										notificationsBadCaptcha('https://freebitco.in/');
										break freeBitcoinBody;
									}
									solvingCaptchaCycles++;
									continue freeBitcoinLabel;
								}

								iimPlayCode('SET !ERRORIGNORE YES'
										+n+ 'SET !TIMEOUT_STEP 10'
                                        +n+ 'WAIT SECONDS=2.5'
										+n+ 'TAG POS=' + i + ' TYPE=INPUT:TEXT ATTR=CLASS:captchasnet_captcha_input_box CONTENT=\"' + answer['hash'] + '\"'
										+n+ 'FILEDELETE NAME=' + captchaPath + captchaName);
							}
						}
						else {
							if (window.content.document.getElementById('g-recaptcha-response')) {
								iimDisplay('reCAPTCHA v2 is detected. Solving...');
								log('https://freebitco.in/', 'reCAPTCHA v2 обнаружена. Попытаемся ее решить...');

								let data_sitekey = window.content.document.getElementsByClassName('g-recaptcha')[0].getAttribute('data-sitekey');
								answer = solveReCaptcha_ruCaptcha(data_sitekey, 'https://freebitco.in/', 0);
								if (!answer['status']) {
									if (solvingCaptchaCycles == 5) {
										notificationsBadCaptcha('https://freebitco.in/');
										break;
									}
									solvingCaptchaCycles++;
									continue;
								}

								iimPlayCode('SET !ERRORIGNORE YES'
										+n+ 'SET !TIMEOUT_STEP 10'
										+n+ 'WAIT SECONDS=2.5'
										+n+ 'TAG POS=1 TYPE=TEXTAREA FORM=ID:* ATTR=ID:g-recaptcha-response CONTENT=\"' + answer['hash'] + '\"');
							}
							else if (window.content.document.getElementsByClassName('captchasnet_captcha_content').length) {
								iimDisplay('Captchas.net / Freebitco.in custom captcha is detected. Solving...');
								log('https://freebitco.in/', 'captchas.net обнаружена. Попытаемся ее решить...');
								
								let captchasNet = window.content.document.getElementsByClassName('captchasnet_captcha_content');
								for (let i = 1; i <= captchasNet.length; i++) {
									let regsense = (i == 1) ? "NO" : "YES";
									let captchaName = makeUniqueName();
									iimPlayCode('SET !ERRORIGNORE YES'
											+n+ 'SET !TIMEOUT_STEP 10'
											+n+ 'ONDOWNLOAD FOLDER=' + captchaPath + ' FILE=' + captchaName + ' WAIT=YES'
											+n+ 'TAG POS=' + i + ' TYPE=DIV ATTR=CLASS:captchasnet_captcha_content CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT');
									
									answer = solveTextCaptcha_ruCaptcha('https://freebitco.in/', captchaName, 6, 6, regsense);
									if (!answer['status']) {
										if (solvingCaptchaCycles == 5) {
											notificationsBadCaptcha('https://freebitco.in/');
											break freeBitcoinBody;
										}
										solvingCaptchaCycles++;
										continue freeBitcoinLabel;
									}

									iimPlayCode('SET !ERRORIGNORE YES'
											+n+ 'SET !TIMEOUT_STEP 10'
											+n+ 'WAIT SECONDS=2.5'
											+n+ 'TAG POS=' + i + ' TYPE=INPUT:TEXT ATTR=CLASS:captchasnet_captcha_input_box CONTENT=\"' + answer['hash'] + '\"'
											+n+ 'FILEDELETE NAME=' + captchaPath + captchaName);
								}
							}
							else if (window.content.document.getElementById('adcopy-puzzle-image')) {
								iimDisplay('Solvemedia is detected. Solving...');
								log('https://freebitco.in/', 'solvemedia обнаружена. Попытаемся ее решить...');

								let solveMedia = window.content.document.getElementById('adcopy-puzzle-image');
								let captchaName = makeUniqueName();
								iimPlayCode('SET !ERRORIGNORE YES'
										+n+ 'SET !TIMEOUT_STEP 10'
										+n+ 'TAG POS=1 TYPE=IMG ATTR=SRC:https://api-secure.solvemedia.com/media/reload-whV2.gif'
										+n+ 'WAIT SECONDS=10'
										+n+ 'ONDOWNLOAD FOLDER=' + captchaPath + ' FILE=' + captchaName + ' WAIT=YES'
										+n+ 'TAG POS=1 TYPE=DIV ATTR=ID:adcopy-puzzle-image CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT');
								
								answer = solveTextCaptcha_ruCaptcha('https://freebitco.in/', captchaName, 0, 0, 'NO');
								if (!answer['status']) {
									if (solvingCaptchaCycles == 5) {
										notificationsBadCaptcha('https://freebitco.in/');
										break;
									}
									solvingCaptchaCycles++;
									continue;
								}

                                iimPlayCode('SET !ERRORIGNORE YES'
                                        +n+ 'SET !TIMEOUT_PAGE 30'
										+n+ 'SET !TIMEOUT_STEP 10'
										+n+ 'WAIT SECONDS=2.5'
										+n+ 'TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:adcopy_response CONTENT=\"' + answer['hash']  + '\"'
										+n+ 'FILEDELETE NAME=' + captchaPath + captchaName);
							}
						}

						iimDisplay('Claiming satoshis...');
						log('https://freebitco.in/', 'Собираем сатоши...');
						iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=INPUT:SUBMIT ATTR=ID:free_play_form_button\nWAIT SECONDS=8');

						if (+window.content.document.getElementById('winnings').innerHTML > 0) {
							iimDisplay('Successfully claimed!');
							log('https://freebitco.in/', 'Успешный сбор! Собрано: ' + (+window.document.getElementById('winnings').innerHTML) + ' BTC; ' + (+window.document.getElementById('fp_reward_points_won').innerHTML) + ' Reward points; ' + (+window.document.getElementById('fp_lottery_tickets_won').innerHTML) + ' Lottery tickets');
							Winnings_freeBITCOIN += +window.document.getElementById('winnings').innerHTML;
							Rewards_freeBITCOIN  += +window.document.getElementById('fp_reward_points_won').innerHTML;
							Tickets_freeBITCOIN  += +window.document.getElementById('fp_lottery_tickets_won').innerHTML;
							break;
						}
						else {
							if ((window.content.document.getElementById('free_play_error').style.display != "none") && (window.content.document.getElementById('free_play_error').innerText.includes("verify"))) {
								iimDisplay('Email verification is detected...');
								log('https://freebitco.in/', 'Необходимо подтвердить email, чтобы продолжить сбор!');
								break;
							}
							else if ((window.content.document.getElementById('free_play_error').style.display != "none") && (window.content.document.getElementById('free_play_error').innerText.includes("blocked"))) {
								iimDisplay('Account of the https://freebitco.in/ has been banned...');
								log('https://freebitco.in/', 'Аккаунт забанен!');
								break;
							}
							else
							{
								iimDisplay('Captcha was solved incorrectly. Sending a report and trying to solve captcha again...');
								log('https://freebitco.in/', 'Капча была решена неверно. Отправляем жалобу и пытаемся решить еще раз...');
								reportCaptcha(apiKey_ruCaptcha, answer['taskId']);
								
								if (solvingCaptchaCycles == 5) {
									notificationsBadCaptcha('https://freebitco.in/');
									break;
								}
								solvingCaptchaCycles++;
								continue;
							}
						}
					}
				}
			}

			// https://freedoge.co.in/ - - - - - >
			if (freeDOGECOIN === 'ON') {
                do {
                    iimDisplay('Connecting to the https://freedoge.co.in/...');
                    log('https://freedoge.co.in/', 'Подключение к проекту...');
                    iimPlayCode('SET !TIMEOUT_PAGE 30'
                            +n+ 'TAB CLOSEALLOTHERS'
                            +n+ 'TAB T=1'
                            +n+ 'TAB CLOSE'
                            +n+ 'URL GOTO=https://freedoge.co.in/#'
                            +n+ 'WAIT SECONDS=8');

                    if (!window.content.document.getElementById('free_play_form_button')) {
                        iimDisplay('Cloudflare protection is detected...');
                        log('https://freedoge.co.in/', 'Обнаружена \'Cloudflare protection\'...');
                        iimPlayCode('WAIT SECONDS=20');
                        continue;
                    }
                    break;
                } while (!window.content.document.getElementById('free_play_form_button'));

                if (/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)) {
                    let timer = +(/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName("title")[0].innerText)[1]) * 60 + +(/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName("title")[0].innerText)[2]);
                    timeTillNextRoll('https://freedoge.co.in/', freeDOGECOIN_RandomTimer, timer);
                }
                
                if (!window.content.document.getElementById('free_play_form_button')) {
                    do {
                        iimDisplay('Connecting to the https://freebitco.in/...');
                        log('https://freebitco.in/', 'Подключение к проекту...');
                        iimPlayCode('SET !TIMEOUT_PAGE 30'
                                +n+ 'TAB CLOSEALLOTHERS'
                                +n+ 'TAB T=1'
                                +n+ 'TAB CLOSE'
                                +n+ 'URL GOTO=https://freebitco.in/?op=home'
                                +n+ 'WAIT SECONDS=8');
                        if (!window.content.document.getElementById('free_play_form_button')) {
                            iimDisplay('Cloudflare protection is detected...');
                            log('https://freebitco.in/', 'Обнаружена \'Cloudflare protection\'...');
                            iimPlayCode('WAIT SECONDS=20');
                            continue;
                        }
                        break;
                    } while (!window.content.document.getElementById('free_play_form_button'));       
                }

                if (window.content.document.getElementsByClassName('cc_banner cc_container cc_container--open').length) {
                    iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 1\nTAG POS=1 TYPE=A ATTR=TXT:Got<SP>it!');
                }

                if (window.content.document.getElementById('free_play_captcha_types').options[window.content.document.getElementById('free_play_captcha_types').selectedIndex].value === 'recaptcha_v2') {
                    iimDisplay('Choosing captcha by solvemedia...');
                    log('https://freedoge.co.in/', 'Выбираем капчу от solvemedia...');
                    iimPlayCode('SET !ERRORIGNORE NO\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=SELECT ATTR=ID:free_play_captcha_types CONTENT=%solvemedia\nWAIT SECONDS=2.5');
                }

                let solvingCaptchaCycles = 1;
                while (solvingCaptchaCycles <= 5) {
                    do {
                        iimDisplay("Refreshing page...");
                        log('https://freedoge.co.in/', 'Обновляем страницу...')
                        iimPlayCode('SET !TIMEOUT_PAGE 60'
                                +n+ 'TAB CLOSEALLOTHERS'
                                +n+ 'TAB T=1'
                                +n+ 'TAB CLOSE'
                                +n+ 'URL GOTO=https://freedoge.co.in/#'
                                +n+ 'WAIT SECONDS=8');

                        if (!window.content.document.getElementById('free_play_form_button')) {
                            iimDisplay('Cloudflare protection is detected...');
                            log('https://freedoge.co.in/', 'Обнаружена \'Cloudflare protection\'...');
                            iimPlayCode('WAIT SECONDS=20');
                            continue;
                        }
                        break;
                    } while (!window.content.document.getElementById('free_play_form_button'));

                    if (/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)) {
                        iimDisplay('There was an exception...');
                        log('https://freedoge.co.in/', 'Произошел отлов исключительной ситуации...');
                        break;
                    }

                    iimDisplay('Solving solvemdia...');
                    log('https://freedoge.co.in/', 'Пытаемся решить капчу solvemedia...');
                    window.scrollBy(0, 20000);
                        
                    var captchaName = makeUniqueName();
                    iimPlayCode('SET !ERRORIGNORE YES'
                            +n+ 'SET !TIMEOUT_STEP 10'
                            +n+ 'TAG POS=1 TYPE=IMG ATTR=SRC:https://api-secure.solvemedia.com/media/reload-whV2.gif'
                            +n+ 'WAIT SECONDS=15'
                            +n+ 'ONDOWNLOAD FOLDER=' + captchaPath + ' FILE=' + captchaName + ' WAIT=YES'
                            +n+ 'TAG POS=1 TYPE=DIV ATTR=ID:adcopy-puzzle-image CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT');
                            
                    let answer = solveTextCaptcha_ruCaptcha('https://freedoge.co.in/', captchaName, 0, 0, 'NO');
                    if (!answer['status']) {
                        if (solvingCaptchaCycles == 5) {
                            notificationsBadCaptcha('https://freedoge.co.in/');
                            break;
                        }
                        solvingCaptchaCycles++;
                        continue;
                    }

                    iimPlayCode('SET !ERRORIGNORE YES'
                            +n+ 'SET !TIMEOUT_PAGE 30'
                            +n+ 'SET !TIMEOUT_STEP 10'
                            +n+ 'WAIT SECONDS=2.5'
                            +n+ 'TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:adcopy_response CONTENT=\"' + answer['hash']  + '\"'
                            +n+ 'FILEDELETE NAME=' + captchaPath + captchaName);

                    iimDisplay('Claiming dogetoshis...');
                    log('https://freedoge.co.in/', 'Собираем догитоши...');
                    iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=INPUT:SUBMIT ATTR=ID:free_play_form_button\nWAIT SECONDS=8');

                    if (+window.content.document.getElementById("winnings").innerHTML > 0)
                    {
                        iimDisplay('Successfully claimed!');
                        log('https://freedoge.co.in/', 'Успешный сбор! Собрано: ' + (+window.document.getElementById("winnings").innerHTML) + ' DOGE ');
                        Winnings_freeDOGECOIN += +window.document.getElementById("winnings").innerHTML;
                        break;
                    }
                    else
                    {
                        iimDisplay('Unsuccessfully claimed!');
                        if ((window.content.document.getElementById('free_play_error').style.display != "none") && (window.content.document.getElementById('free_play_error').innerText.includes("verify"))) {
                            iimDisplay('Email verification is detected...');
                            log('https://freedoge.co.in/', 'Необходимо подтвердить email, чтобы продолжить сбор!');
                            break;
                        }
                        else if ((window.content.document.getElementById('free_play_error').style.display != "none") && (window.content.document.getElementById('free_play_error').innerText.includes("blocked"))) {
                            iimDisplay('Account of the https://freedoge.co.in/ has been banned...');
                            log('https://freedoge.co.in/', 'Аккаунт забанен!');
                            break;
                        }
                        else
                        {
                            iimDisplay('Captcha was solved incorrectly. Sending a report and trying to solve captcha again...');
                            log('https://freedoge.co.in/', 'Капча была решена неверно. Отправляем жалобу и пытаемся решить еще раз...');
							reportCaptcha(apiKey_ruCaptcha, answer['taskId']);
							
                            if (solvingCaptchaCycles == 5) {
                                notificationsBadCaptcha('https://freedoge.co.in/');
                                break;
                            }
                            solvingCaptchaCycles++;
                            continue;
                        }
                    }
                }
			}

			// https://freenem.com/ - - - - - >
			if (freeNEM === 'ON') {
				freeNemBody : {
					let authorizationCycles = 1;
					while (authorizationCycles <= 5) {
						iimDisplay('Connecting to the https://freenem.com/...');
						log('https://freenem.com/', 'Подключение к проекту...');
						iimPlayCode('SET !TIMEOUT_PAGE 60'
								+n+ 'TAB T=1'
								+n+ 'TAB CLOSEALLOTHERS'
								+n+ 'URL GOTO=https://freenem.com/free'
								+n+ 'WAIT SECONDS=8');

						if (!window.content.document.getElementsByClassName('main-button-2 roll-button').length) {
							iimDisplay('Logging to the https://freenem.com/...');
							log('https://freenem.com/', 'Авторизируемся на проекте...');
							iimPlayCode('SET !ERRORIGNORE YES'
									+n+ 'SET !TIMEOUT_PAGE 30'
									+n+ 'SET !TIMEOUT_STEP 10'
									+n+ 'TAG POS=1 TYPE=INPUT:EMAIL ATTR=NAME:email CONTENT=' + freeNEM_Login
									+n+ 'SET !ENCRYPTION NO'
									+n+ 'TAG POS=1 TYPE=INPUT:PASSWORD ATTR=NAME:password CONTENT=' + freeNEM_Password
									+n+ 'TAG POS=1 TYPE=BUTTON ATTR=TXT:LOGIN!'
									+n+ 'WAIT SECONDS=2');
							
							let data_sitekey = window.content.document.getElementsByTagName('iframe')[0].src.split('?k=')[1].split('&co=')[0];
							let answer = solveReCaptcha_ruCaptcha(data_sitekey, 'https://freenem.com/', 1);
							if (!answer['status']) {
								if (authorizationCycles == 5) {
									notificationsBadCaptcha('https://freenem.com/');
									break freeNemBody;
								}
								authorizationCycles++;
								continue;
							}

							iimPlayCode('SET !ERRORIGNORE YES'
									+n+ 'SET !TIMEOUT_PAGE 30'
									+n+ 'SET !TIMEOUT_STEP 10'
									+n+ 'TAG POS=1 TYPE=TEXTAREA FORM=ID:* ATTR=ID:g-recaptcha-response CONTENT=\"' + answer['hash'] + '\"'
									+n+ 'WAIT SECONDS=6');

							if (window.content.document.getElementsByClassName('error')[0]) {
								if (window.content.document.getElementsByClassName('error')[0].innerHTML.includes('robot')) {
									iimPlayCode('SET !TIMEOUT_PAGE 30\nREFRESH');
									if (window.content.document.getElementsByClassName('main-button-2 roll-button').length) {
										iimDisplay('Successful authorization...');
										log('https://freenem.com/', 'Успешная авторизация...');
										break;
									}

									if (authorizationCycles == 5) {
										notificationsBadCaptcha('https://freenem.com/');
										break freeNemBody;
									}
									authorizationCycles++;
									continue;

								}   
							}
							else if (!window.content.document.getElementsByClassName('main-button-2 roll-button').length) {
									iimDisplay('Captcha was solved incorrectly. Sending a report and trying to solve captcha again...');
									log('https://freenem.com/', 'Капча была решена неверно. Отправляем жалобу и пытаемся решить еще раз...');
									reportCaptcha(apiKey_ruCaptcha, answer['taskId']);
									
									if (authorizationCycles == 5) {
										notificationsBadCaptcha('https://freenem.com/');
										break freeNemBody;
									}
									authorizationCycles++;
									continue;
							}
							else {
								iimDisplay('Successful authorization...');
								log('https://freenem.com/', 'Успешная авторизация...');
								break;
							}
						}
						else {
							break;
						}
					}

					let timer = (+window.content.document.getElementsByClassName('digits')[0].innerHTML * 60) + (+window.content.document.getElementsByClassName('digits')[1].innerHTML);
					if (timer > 0) {
						timeTillNextRoll('https://freenem.com/', freeNEM_RandomTimer, timer);
                    }

					let solvingCaptchaCycles = 1;
					while (solvingCaptchaCycles <= 5) {
						iimDisplay('Refreshing page and solving reCAPTCHA v2...');
						log('https://freenem.com/', 'Обновляем страницу и пытаемся решить invisible reCAPTCHA v2...');
						iimPlayCode('SET !ERRORIGNORE YES'
								+n+ 'SET !TIMEOUT_PAGE 60'
								+n+ 'SET !TIMEOUT_STEP 10'
								+n+ 'TAB CLOSEALLOTHERS'
								+n+ 'TAB T=1'
								+n+ 'TAB CLOSE'
								+n+ 'URL GOTO=https://freenem.com/free'
                                +n+ 'WAIT SECONDS=8');
                                
                        timer = (+window.content.document.getElementsByClassName('digits')[0].innerHTML * 60) + (+window.content.document.getElementsByClassName('digits')[1].innerHTML);
                        if (timer > 0) {
                            break freeNemBody;
                        }

                        iimPlayCode('SET !ERRORIGNORE YES'
                                +n+ 'SET !TIMEOUT_PAGE 60'
                                +n+ 'SET !TIMEOUT_STEP 10'
                                +n+ 'TAG POS=1 TYPE=BUTTON ATTR=TXT:ROLL!'
                                +n+ 'WAIT SECONDS=2');

						let data_sitekey = window.content.document.getElementsByTagName('iframe')[0].src.split('?k=')[1].split('&co=')[0];
						let answer = solveReCaptcha_ruCaptcha(data_sitekey, 'https://freenem.com/', 1);
						if (!answer['status']) {
							if (solvingCaptchaCycles == 5) {
								notificationsBadCaptcha('https://freenem.com/');
								break;
							}
							solvingCaptchaCycles++;
							continue;
						}

						iimDisplay('Claiming NEM...');
						log('https://freenem.com/', 'Собираем NEM...');

						iimPlayCode('SET !ERRORIGNORE YES'
								+n+ 'SET !TIMEOUT_PAGE 30'
                                +n+ 'SET !TIMEOUT_STEP 10'
                                +n+ 'WAIT SECONDS=2.5'
								+n+ 'TAG POS=1 TYPE=TEXTAREA FORM=ID:* ATTR=ID:g-recaptcha-response CONTENT=\"' + answer['hash'] + '\"'
								+n+ 'ONDIALOG POS=1 BUTTON=OK CONTENT='
								+n+ 'WAIT SECONDS=8');
							
						let winningDuringLastSession = +window.content.document.getElementsByClassName('result')[0].innerHTML.split(' ')[3];
						if (!isNaN(winningDuringLastSession) || (winningDuringLastSession > 0)) {
							iimDisplay('Successfully claimed!');
							log('https://freenem.com/', 'Успешный сбор! Собрано: ' + winningDuringLastSession + ' NEM');
							Winnings_freeNEM += winningDuringLastSession;
							break;
						}
						else {
							iimDisplay('Captcha was solved incorrectly. Sending a report and trying to solve captcha again...');
							log('https://freenem.com/', 'Капча была решена неверно. Отправляем жалобу и пытаемся решить еще раз...');
							reportCaptcha(apiKey_ruCaptcha, answer['taskId']);

							if (solvingCaptchaCycles == 5) {
								notificationsBadCaptcha('https://freenem.com/');
								break;
							}
							solvingCaptchaCycles++;
							continue;
						}
					}
				}
            }
		}
	}
	catch (e) {
		log('undefined', 'Произошла ошибка в работе бота, проверьте подключение к интернету! Бот будет перезапущен через 30 секунд...');
		iimDisplay('There was an error in the bot operation, check the connection to the Internet! The bot will be restarted in 30 seconds...');
	}
}