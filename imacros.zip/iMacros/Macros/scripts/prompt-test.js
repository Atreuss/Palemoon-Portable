
var n = '\n';
var dirData = 'Prompt';
var keyApi = new Array();
var pp = 0; 
var prob = 10;
keyApi['Rucaptcha'] = '3d53ea778e4123123123123172317231723'; // INSIRA SUA API 2captcha/Rucaptcha


teste();


function teste(){
	if(pp>prob) return;
	
	prompthtml();

	var file ='bagdoge.png';

	iimPlayCode('PAUSE'
		+n+ 'SET !EXTRACT_TEST_POPUP NO'
		+n+ 'SET !EXTRACT NULL'
		+n+ 'TAG POS=1 TYPE=SELECT FORM=NAME:* ATTR=TXT:* EXTRACT=TXT'
		+n+ 'SET !VAR1 {{!EXTRACT}}'
		+n+ 'SET !EXTRACT NULL'
		+n+ 'SEARCH SOURCE=REGEXP:"<option value=\\\"([^\\\"])\\\">{{!VAR1}}" EXTRACT="$1"'
		+n+ 'PROMPT {{!EXTRACT}}'
	);

	var ligar2captcha = iimGetLastExtract();

	if (Number(ligar2captcha)>=1) {

		SaveCaptcha(file);
	    var str = GetRucaptcha(file, keyApi['Rucaptcha']);
	  	var cText = str['c_text'];
	  	var captha = cText.replace(/\s/g, '<SP>');
	  	
	  	iimDisplay(captha);
	    if (cText == undefined){
	        reportcaptcha(pp + 1);bagdoge(pp + 1);
	        return;
	    }

	    var captha = cText.replace(/\s/g, '<SP>');
	    iimDisplay(captha);
	    if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {reportcaptcha(pp + 1);bagdoge(pp + 1);return}
	}
}


function prompthtml() {
	var strUpFile = '';
    var strUpFile_light = '';
    var header = '&quot;<link rel=\'stylesheet\' href=\'prompt/bootstrap.min.css\' /><link rel=\'stylesheet\' href=\'style.css\' />';
    var table = '';
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'SET !EXTRACT NULL' + n;
    code += 'ADD !EXTRACT {{STRFILE}}' + n;
    code += 'SAVEAS TYPE=EXTRACT FOLDER=C:\\' + dirData + ' FILE=prompt.html ' + n;
    code += 'TAB T=1' + n;
    code += 'URL GOTO=file:///C:/' + dirData + '/prompt.html' + n;
    iimSet('STRFILE', strUpFile);
    iimPlay(code, 60)
}

function SaveCaptcha(file_name) {
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'SET !ENCRYPTION NO' + n;
    code += 'WAIT SECONDS=0.5' + n;
    code += 'ONDOWNLOAD FOLDER=C:\\' + dirData + '\\ FILE=' + file_name + ' WAIT=YES' + n;
	code += 'WAIT SECONDS=0.5' + n;
	code += 'TAG POS=1 TYPE=IMG ATTR=ID:adcopy-puzzle-image-image CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
	iimPlay(code, 60)
}

function GetRucaptcha(file_name, apikey) {
    var result = new Array();
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB OPEN' + n;
    code += 'TAB T=2' + n;
    code += 'URL GOTO=file:///C:/' + dirData + '/form_api_rucaptcha.html' + n;
    code += 'TAG POS=1 TYPE=INPUT:TEXT ATTR=NAME:key&&SIZE:64 CONTENT=' + apikey + n;
    code += 'TAG POS=1 TYPE=INPUT:FILE ATTR=TYPE:file&&NAME:file&&SIZE:20 CONTENT=C:\\' + dirData + '\\' + file_name + n;
    if (file_name == 'calc.png') {
        code += 'TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ACTION:* ATTR=NAME:calc CONTENT=YES' + n
    }
    code += 'TAG POS=1 TYPE=INPUT:SUBMIT ATTR=TYPE:submit&&VALUE:recognize' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=BODY ATTR=TXT:* EXTRACT=TXT' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAB CLOSE' + n;
    iimPlay(code, 120);
    var str = iimGetLastExtract();
    var capthId = str.replace('OK|', '');
    switch (capthId) {
        case'ERROR_NO_SLOT_AVAILABLE':
            var code = '';
            code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
            code += 'TAB T=1' + n;
            code += 'WAIT SECONDS=10' + n;
            return GetRucaptcha(file_name, apikey);
            break;
        default:
            result['c_text'] = GetRucaptchaTEXT(capthId, apikey, file_name, pp);
            result['c_id'] = capthId
    }
    return result
}

function GetRucaptchaTEXT(capthId, apikey, file_name, pp) {
    if(pp > prob) {
    iimDisplay('Captcha Errado - Tentando Novamente');}
    else{
    var result = 'ERROR';
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB OPEN' + n;
    code += 'TAB T=2' + n;
    code += 'URL GOTO=http://rucaptcha.com/res.php?key=' + apikey + '&action=get&id=' + capthId + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=BODY ATTR=TXT:* EXTRACT=TXT' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAB CLOSE' + n;
    iimPlay(code, 60);
    var str = iimGetLastExtract();
    var capth = str.replace('OK|', '');
    switch (capth) {
        case'CAPCHA_NOT_READY':
            var code = '';
            code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
            code += 'TAB T=1' + n;
            code += 'WAIT SECONDS=10' + n;
            iimPlay(code, 60);
            result = GetRucaptchaTEXT(capthId, apikey, file_name, (pp + 1));
            break;
        case'ERROR_KEY_DOES_NOT_EXIST':
            return result = 'ERROR';
            break;
        case'ERROR_WRONG_ID_FORMAT':
            return result = 'ERROR';
            break;
        case'ERROR_WRONG_CAPTCHA_ID':
            return result = 'ERROR';
            break;
        case'ERROR_CAPTCHA_UNSOLVABLE':
            return result = 'ERROR_CAPTCHA_UNSOLVABLE';
            break;
        default:
            var result = capth
    }
    return result}
}