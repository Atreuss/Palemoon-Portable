﻿// --------------------- ALTERAÇÕES --------------------------------------------------------------------------------------------
var loop         = 9999999999					// quantas vezes irá executar o script

// ++++++++++++++++++++++++ LITECOIN +++++++++++++++++++++++++
var ltc          = "LV1Y1Rc8unjLypbzjadcqts8ovFhQn1DPp";	// carteira litecoin
var wdltclimite  = 5000.00;					// sacar a partir de. Exemplo 10.000 litoshis

// ++++++++++++++++++++++++ DOGE +++++++++++++++++++++++++++++
var doge = "DKgCqd5Gw3gPo4mTHTvLVUwJYLVKDmoAiM";		// carteira doge
var wddogelimite = 10.00;					// sacar a partir de. Exemplo 10.00 Doges

// ++++++++++++++++++++++++ BITCOIN ++++++++++++++++++++++++++
var btc          = "158fRAFW2c6TpHHY9123BFPZEdqWL19aTm";	// carteira bitcoin
var wdbtclimite  = 500.00;					// sacar a partir de. Exemplo 2000.00 satoshis

// ++++++++++++++++++++++++ BLACKCOIN ++++++++++++++++++++++++ 
var blk          = "B7b91S9dt5xMND4RKgdyVJZPSdufCqZWci";	// carteira blackcoin
var wdblklimite  = 100000000;					// sacar a partir de. Exemplo 1.000.000.000 satoshis de balckcoin

//------------------------------------------------------

var urls = [];var wallets = [];var wdlimits = [];if(doge.length>0){wallets[0]=doge;urls[0]='https://goo.gl/tjvueb';wdlimits[0]=wddogelimite;}if(ltc.length>0){wallets[1]=ltc;urls[1]='https://goo.gl/Auxdro';wdlimits[1]=wdltclimite;}if(blk.length>0){wallets[2]=blk;urls[2]='https://goo.gl/sUJfPX';wdlimits[2]=wdblklimite;}if(btc.length>0){wallets[3]=btc;urls[3]='https://goo.gl/E7Qyqf';wdlimits[3]=wdbtclimite;}

function withdrawal() {
  iimPlayCode("WAIT SECONDS=0.5\nTAG POS=1 TYPE=A ATTR=TXT:Withdrawal!");
  for (k = 0; k < 10; k++){
    iimPlayCode("SET !ERRORIGNORE YES\nSET !ERRORCONTINUE YES\nSET !TIMEOUT_STEP 0\nFRAME F="+k+"\nTAG POS=1 TYPE=DIV ATTR=ID:verify-me");
  }
     do {
         if (window.location.host != "darak.me"){break;}
         iimPlayCode("TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:NoFormName ATTR=* EXTRACT=HTM");
         var wdextracttxt = iimGetLastExtract(1);
        }
  while (wdextracttxt.indexOf("disabled") > 0);
  iimPlayCode("WAIT SECONDS=0.9\nTAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:NoFormName ATTR=*");
}

for (z = 0; z < loop; z++){
  for(var i=0; i<wallets.length; i++){
    if (typeof wallets[i] !== 'undefined'){
        macro = "CODE:\n"
              + "VERSION BUILD=8970419 RECORDER=FX\n"
              + "SET !EXTRACT_TEST_POPUP NO\n"
              + "SET !ERRORIGNORE YES\n"
              + "SET !ERRORCONTINUE YES\n"
              + "SET !TIMEOUT_STEP 0\n"
              + "SET !EXTRACT NULL\n"
              + "TAB CLOSEALLOTHERS\n"
              //+ "CLEAR\n"
              + "TAB T=1\n"
              + "URL GOTO="+urls[i]+"\n"
              + "TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:NoFormName ATTR=NAME:* CONTENT="+wallets[i]+"\n"
              + "WAIT SECONDS=0.5\n"
              + "TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:NoFormName ATTR=*\n"
      iimPlay(macro);
  
      iimPlayCode("TAG POS=1 TYPE=P ATTR=CLASS:alert<SP>alert-info EXTRACT=TXT");
      var wdvlrtxt = iimGetLastExtract(1);
      //var wdvlratual = parseFloat(wdvlrtxt.substring((wdvlrtxt.indexOf(":")+1),50));
      //if (parseFloat(wdvlratual) >= wdlimits[i]){withdrawal();iimPlay(macro);}
  
      iimPlayCode("WAIT SECONDS=0.5\nTAG POS=1 TYPE=A ATTR=TXT:Claim");
      iimPlayCode("WAIT SECONDS=0.5\nTAG POS=1 TYPE=A ATTR=TXT:Skip<SP>Ad");
  
      if (window.location.host == "www.cardo.pro"){
           do { if (window.location.host != "www.cardo.pro"){break;}
                iimPlayCode("SET !TIMEOUT_STEP 1\nTAG POS=1 TYPE=A ATTR=HREF:javascript:; EXTRACT=TXT");
              }
        while (iimGetLastExtract(1).indexOf("Please") >= 0);
        iimPlayCode("WAIT SECONDS=0.5\nSET !TIMEOUT_STEP 1\nTAG POS=1 TYPE=A ATTR=HREF:javascript:;");
        iimPlayCode("WAIT SECONDS=0.5\nSET !TIMEOUT_STEP 1\nTAG POS=1 TYPE=A ATTR=TXT:Claim");
        iimPlayCode("WAIT SECONDS=0.5\nSET !TIMEOUT_STEP 1\nTAG POS=1 TYPE=A ATTR=TXT:Next<SP>Visit");
      }else{
        iimPlayCode("WAIT SECONDS=0.5\nTAG POS=1 TYPE=IMG ATTR=ID:showlink\n");
        iimPlayCode("WAIT SECONDS=0.5\nSET !TIMEOUT_STEP 0\nEVENT TYPE=CLICK SELECTOR='#showLink>A>IMG' BUTTON=0\n");
        iimPlayCode("WAIT SECONDS=0.5\nSET !TIMEOUT_STEP 0\nEVENT TYPE=CLICK SELECTOR='#resultDecode>A' BUTTON=0\n");
        iimPlayCode("WAIT SECONDS=0.5\nTAB CLOSEALLOTHERS\n");
      }
    
      iimPlayCode("WAIT SECONDS=0.5\n");
      javascript:window.scrollBy(0,1000)
      for (x = 0; x < 10; x++){
        iimPlayCode("SET !ERRORIGNORE YES\nSET !ERRORCONTINUE YES\nSET !TIMEOUT_STEP 0\nFRAME F="+x+"\nTAG POS=1 TYPE=DIV ATTR=ID:verify-me\n"+
	            "TAG POS=1 TYPE=DIV ATTR=ID:verify-me-progress EXTRACT=HTM");
        if (iimGetLastExtract() != "#EANF#"){break;}
      }

         do { if (window.location.host != "darak.me"){break;}
              iimPlayCode("SET !TIMEOUT_STEP 0\nFRAME F="+x+"\nTAG POS=1 TYPE=DIV ATTR=ID:verify-me-progress EXTRACT=HTM");
            }
      while (iimGetLastExtract().indexOf("100%") < 0);
      iimPlayCode("WAIT SECONDS=2\nFRAME F=0\nTAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:NoFormName ATTR=*");
	
    }
  }
}