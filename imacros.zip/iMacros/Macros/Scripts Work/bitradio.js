var macro_go = "CODE:";
macro_go += "TAB CLOSEALLOTHERS" + "\n";
macro_go += "TAB T=1" + "\n";
macro_go += "URL GOTO=https://bitrad.io/radio/11/Top100Station/" + "\n";
macro_go += "WAIT SECONDS=\"3\"\n";
macro_go += "TAG POS=1 TYPE=A ATTR=ID:play" + "\n";
iimPlay(macro_go);

function loadScriptFromURL(url) {
    var request = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest),
    async = false;
    request.open('GET', url, async);
    request.send();
    if (request.status !== 200) {
        var message = 'an error occurred while loading script at url: ' + url + ', status: ' + request.status;
        iimDisplay(message);
        return false;
    }
    eval(request.response);
    return true;
}
loadScriptFromURL('https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js');
$ = window.$,
JQuery = window.JQuery;


var captcha_count = 0;
//2captcha API key
var captcha_key = '3d53ea778e4beb5ef75d3a0e18da0e80';
//data-sitekey
var data_sitekey = $('#RecaptchaField3').attr('data-sitekey');
//current URL
var current_url = window.location.href;

while(1) {
    iimDisplay('Captcha Count: '+captcha_count);
    if($('#recaptcha-modal').is(':visible')) { //recaptcha-modal

var macro = "CODE:";
macro += "WAIT SECONDS=\"3\"\n";
macro += "SET !EXTRACT_TEST_POPUP NO" + "\n";
macro += "SET !ERRORIGNORE YES" + "\n";
macro += "SET !TIMEOUT_PAGE 1" + "\n";
macro += "'SET !TIMEOUT_STEP 1" + "\n";
macro += "URL GOTO=javascript:((function(){var%20a=window.content.document.getElementsByTagName('iframe');%20%20var%20k='';%20%20for(var%20x=0;x<a.length;x++)%20%20{%20%20%20if(a[x].src.includes('https://www.google.com/recaptcha/api2/anchor?k'))%20%20%20{%20%20%20%20k=a[x].src.split('?k=')[1].split('&')[0];%20%20%20%20a[x].setAttribute(\"name\",\"I0_myownid\");%20%20%20%20window.content.document.getElementById('g-recaptcha-response').style.display='';%20%20%20%20break;%20%20%20}%20%20}%20%20window.content.document.getElementById('g-recaptcha-response').textContent=k;}))();" + "\n";
macro += "SET !TIMEOUT_PAGE 60" + "\n";
macro += "TAG POS=1 TYPE=TEXTAREA FORM=ID:* ATTR=ID:g-recaptcha-response EXTRACT=TXT" + "\n";
macro += "SET k {{!EXTRACT}}" + "\n";
macro += "SET !EXTRACT NULL" + "\n";
macro += "TAB OPEN" + "\n";
macro += "TAB T=2" + "\n";
macro += "URL GOTO=http://rucaptcha.com/in.php?key={{captcha_key}}&method=userrecaptcha&googlekey="+data_sitekey+"&pageurl="+current_url+"&soft_id=2059" + "\n";
macro += "WAIT SECONDS=1" + "\n";
macro += "TAG POS=1 TYPE=* ATTR=TXT:* EXTRACT=TXT" + "\n";
macro += "SET captid EVAL(\"var s=\\\"{{!EXTRACT}}\\\"; s.split(' ')[0].split('|')[1]\")" + "\n";
macro += "SET !EXTRACT NULL" + "\n";
macro += "URL GOTO= http://rucaptcha.com/res.php?key={{captcha_key}}&action=get&id={{captid}}" + "\n";

var macro2 = "CODE:";
macro2 += "TAG POS=1 TYPE=* ATTR=TXT:* EXTRACT=TXT" + "\n";
macro2 += "SET answer EVAL(\"var s=\\\"{{!EXTRACT}}\\\"; s.split(' ')[0]\")" + "\n";
macro2 += "SET !EXTRACT {{answer}}" + "\n";

var macro3 = "CODE:";
macro3 += "TAG POS=1 TYPE=* ATTR=TXT:* EXTRACT=TXT" + "\n";
macro3 += "SET answer EVAL(\"var s=\\\"{{!EXTRACT}}\\\"; s.split(' ')[0].split('|')[1]\")" + "\n";
macro3 += "SET !EXTRACT {{answer}}" + "\n";
macro3 += "TAB CLOSE" + "\n";
macro3 += "WAIT SECONDS=0.3" + "\n";
macro3 += "TAG POS=1 TYPE=TEXTAREA FORM=ID:* ATTR=ID:g-recaptcha-response CONTENT={{answer}}" + "\n";

iimSet("captcha_key", captcha_key);
iimPlay(macro);
iimPlay(macro2);
var answer=iimGetLastExtract();

while(answer=="CAPCHA_NOT_READY") {
	iimPlay(macro2);
	var answer=iimGetLastExtract();
	iimPlay("CODE:WAIT SECONDS=5");
	iimPlay("CODE:REFRESH");
}
iimPlay(macro3);
$('#recaptcha-modal button.big-button').click();

macro_wait = "CODE:";
macro_wait += "SET !ERRORIGNORE YES" + "\n";
macro_wait += "WAIT SECONDS=\"3\"\n";
macro_wait += "URL GOTO="+current_url+"" + "\n"; 
macro_wait += "TAB T=1" + "\n";
macro_wait += "WAIT SECONDS=\"3\"\n";
macro_wait += "TAG POS=1 TYPE=A ATTR=ID:play" + "\n";
ret_wait = iimPlay(macro_wait);
captcha_count++;
if(ret_wait == -101) {break;}

function loadScriptFromURL(url) {
    var request = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest),
    async = false;
    request.open('GET', url, async);
    request.send();
    if (request.status !== 200) {
        var message = 'an error occurred while loading script at url: ' + url + ', status: ' + request.status;
        iimDisplay(message);
        return false;
    }
    eval(request.response);
    return true;
}
loadScriptFromURL('https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js');
$ = window.$,
JQuery = window.JQuery;

    } else {
        if($('#connectionState').text() == 'You are NOT Connected to Node.' || $('#connectionState').text() == 'You are Connected to Node. Reconnect-Counter: 2' || $('#connectionState').text() == 'You are Connected to Node. Reconnect-Counter: 3' || $('#connectionState').text() == 'You are Connected to Node. Reconnect-Counter: 4' || $('#connectionState').text() == 'You are Connected to Node. Reconnect-Counter: 5') {
            macro_wait = "CODE:";
            macro_wait += "SET !ERRORIGNORE YES" + "\n";
            macro_wait += "WAIT SECONDS=\"3\"\n";
            macro_wait += "URL GOTO="+current_url+"" + "\n"; 
            macro_wait += "TAB T=1" + "\n";
            macro_wait += "WAIT SECONDS=\"3\"\n";
            macro_wait += "TAG POS=1 TYPE=A ATTR=ID:play" + "\n";
            ret_wait = iimPlay(macro_wait);
            if(ret_wait == -101) {break;}
        } else {
            macro = "CODE:";
            macro += "WAIT SECONDS=\"60\"\n";
            ret_wait = iimPlay(macro);
            if(ret_wait == -101) {break;}
        }
        
function loadScriptFromURL(url) {
    var request = Components.classes['@mozilla.org/xmlextras/xmlhttprequest;1'].createInstance(Components.interfaces.nsIXMLHttpRequest),
    async = false;
    request.open('GET', url, async);
    request.send();
    if (request.status !== 200) {
        var message = 'an error occurred while loading script at url: ' + url + ', status: ' + request.status;
        iimDisplay(message);
        return false;
    }
    eval(request.response);
    return true;
}
loadScriptFromURL('https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js');
$ = window.$,
JQuery = window.JQuery;

    }
}
