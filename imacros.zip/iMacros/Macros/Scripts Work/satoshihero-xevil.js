﻿// API INTERNA DO SITE EM QUESTÃO
var datasitekey = '6LdzSxwUAAAAABzV0lDJ6T1LxprFtn2g053NE05R';                
//BOTÃO QUE DARÁ O CLAIM FINAL
var ENVIAR="TAG POS=1 TYPE=A ATTR=TXT:Continue<SP>to<SP>claim";
//------> URL DA PÁGINA
var pageurl = 'https://satoshihero.com';

var macro = "CODE:";
macro += "SET !EXTRACT_TEST_POPUP NO" + "\n";
macro += "SET !ERRORIGNORE YES" + "\n";
macro += "SET !TIMEOUT_PAGE 350" + "\n";
macro += "SET !EXTRACT NULL" + "\n";
macro += "SET !TIMEOUT_STEP 60" + "\n";
macro += "URL GOTO=https://satoshihero.com/en/game\n";
macro += "WAIT SECONDS=2" + "\n";
macro += "SET !TIMEOUT_TAG 60\nTAG POS=1 TYPE=A ATTR=TXT:Get<SP>free<SP>bitcoins<SP>now" + "\n";
macro += "PAUSE" + "\n";
macro += "SET !TIMEOUT_PAGE 350" + "\n";
macro += 'URL GOTO=javascript:(function(){var<SP>x<SP>=<SP>document.getElementById("g-recaptcha-response");document.getElementByClass("text-center");x.style.display<SP>=<SP>"";})();' + "\n";
macro += "TAB OPEN" + "\n";
macro += "TAB T=2" + "\n";
macro += "URL GOTO=http://23.249.176.210/in.php?method=userrecaptcha&googlekey="+datasitekey+"&pageurl="+pageurl+" "+ "\n";
macro += "WAIT SECONDS=2" + "\n";
macro += "TAG POS=1 TYPE=* ATTR=TXT:* EXTRACT=TXT" + "\n";
macro += "SET captid EVAL(\"var s=\\\"{{!EXTRACT}}\\\"; s.split(' ')[0].split('OK|')[1]\")" + "\n";
macro += "SET !EXTRACT NULL" + "\n";
macro += "URL GOTO= http://23.249.176.210/res.php?action=get&id={{captid}}" + "\n";

var macro2 = "CODE:";
macro2 += "TAG POS=1 TYPE=* ATTR=TXT:* EXTRACT=TXT" + "\n";
macro2 += "SET answer EVAL(\"var s=\\\"{{!EXTRACT}}\\\"; s.split(' ')[0]\")" + "\n";
macro2 += "SET !EXTRACT {{answer}}" + "\n";

var macro3 = "CODE:";
macro3 += 'URL GOTO=javascript:(function(){var<SP>x<SP>=<SP>document.getElementById("g-recaptcha-response");x.style.display<SP>=<SP>"";})();' + "\n";
macro3 += "PAUSE" + "\n";
macro3 += "TAG POS=1 TYPE=* ATTR=TXT:* EXTRACT=TXT" + "\n";
macro3 += "SET answer EVAL(\"var s=\\\"{{!EXTRACT}}\\\"; s.split(' ')[0].split('OK|')[1]\")" + "\n";
macro3 += "SET !EXTRACT {{answer}}" + "\n";
macro3 += "PAUSE" + "\n";
macro3 += "TAB CLOSE" + "\n";
macro3 += "WAIT SECONDS=0.3" + "\n";
macro3 += "TAG POS=1 TYPE=TEXTAREA FORM=ID:recaptcha-demo-form ATTR=ID:g-recaptcha-response CONTENT={{!EXTRACT}}" + "\n";
macro3 += ENVIAR + "\n";
macro3 += "WAIT SECONDS=10" + "\n";

iimPlay(macro);
iimPlay(macro2);

var answer=iimGetLastExtract().trim();
while(answer=="CAPCHA_NOT_READY")
{
iimPlay("CODE:WAIT SECONDS=5");
iimPlay("CODE:REFRESH");
iimPlay(macro2);
var answer=iimGetLastExtract().trim();
}

iimPlay(macro3);