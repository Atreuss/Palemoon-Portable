/**
 *  @description freebitco.in / freedoge.co.in / freenem.com
 *  @author Group Din Din na Net - http://dindinnanet.com.br
 *
 * [ Instruções ]:
 * ⑴ Baixar o Mozilla Firefox, iMacros v8.9.7 e Configurar de acordo com as Instruções README.md: http://dindinnanet.com.br/url-do-script
 * 	⑵ Entre nos sites para os quais você vai usar o Script
 * 	⑶ Registre-se e adicione fundos à sua conta de serviço de reconhecimento captcha usando qualquer método de pagamento de sua preferência
 * 	⑷ Atenção, não esqueça de fazer as seguintes ações:
 * 		▻ Criar pasta C: \ IWANTMONEY
 * 		▻ Coloque sua APIKEY do ruCaptcha.com / 2Captcha.com em vez de ** (linha №26) -> Ex: const apiKey ='9727fef187729a506869b64a70580515';
 * 		▻ Ativar torneiras que você precisa e funções adicionais para eles (Linhas №31 - 44)
 * ▻ Para usar o freenem.com você precisará instalar qualquer extensão para bloquear anúncios. Eu sugiro Visitar o Nosso Site para ver o Tutorial
 * Link para download: http://dindinnanet.com.br/2018/02/27/tutorial/
 *
 * Entre em contato Conosco:
 * ⑴ E-mail: contato@dindinnanet.com.br
 * ⑵ Website: http://dindinnanet.com.br
 * ⑶ Telegram: t.me/grupoDinDinnaNet
 */
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// [ Configurações №1 ]: Configurações personalizadas
const captchaPath      = 'C:\\MultiCaptcha_bot\\';         // Caminho de download de captchas de texto (não se esqueça de usar barras duplas invertidas)
const logPath 	       = 'C:\\MultiCaptcha_bot\\log.txt';  // Nome de arquivo completo do log (não se esqueça de usar barras invertidas duplas)
const mail             = 'gugatrb19@gmail.com';                  // Seu e-mail, para o qual as informações serão enviadas, sobre falhas no trabalho

const apiKey_ruCaptcha = '9727fef187729a506869b64a70580515'; // Sua API KEY de ruCaptcha.com (https://rucaptcha.com/enterpage) / 2Captcha.com
const apiKey_XCaptcha  = 'c5827df8b82d7411bbe09d87690223ad'; // Sua API KEY do X-Captcha.ru


// [ Configurações №2 ]: Faucet https://freebitco.in/
const freeBITCOIN                     = 'ON';  // [ON / OFF] - Usar bot em https://freebitco.in/
const freeBITCOIN_RewardPoints        = 'ON';  // [ON / OFF] - plicar automaticamente pontos de recompensa em https://freebitco.in/
const freeBITCOIN_RandomTimer         = 'OFF';  // [ON / OFF] - Atraso aleatório de 30 segundos a 2 minutos antes do próximo lançamento em https://freebitco.in/

const reCAPTCHA_freeBITCOIN_ruCaptcha = 'ON';  // [ON / OFF] - Reconhecimento do reCAPTCHA v2 em https://freebitco.in/ via ruCaptcha.com / 2Captcha.com
const reCAPTCHA_freeBITCOIN_XCaptcha  = 'OFF';  // [ON / OFF] - Reconhecimento do reCAPTCHA v2 em https://freebitco.in/ via X-Captcha.ru

// [ Configurações №3 ]: Faucet https://freedoge.co.in/
const freeDOGECOIN                     = 'ON';  // [ON / OFF] - Usar bot em https://freedoge.co.in/
const freeDOGECOIN_RandomTimer         = 'OFF';  // [ON / OFF] - Atraso aleatório de 30 segundos a 2 minutos antes do próximo lançamento em https://freedoge.co.in/

const reCAPTCHA_freeDOGECOIN_ruCaptcha = 'OFF';  // [ON / OFF] - Reconhecimento do reCAPTCHA v2 em https://freedoge.co.in/ via ruCaptcha.com / 2Captcha.com
const reCAPTCHA_freeDOGECOIN_XCaptcha  = 'ON';  // [ON / OFF] - Reconhecimento do reCAPTCHA v2 em https://freedoge.co.in/ via X-Captcha.ru

// [ Configurações №4 ]: Faucet https://freenem.com/
const freeNEM	                  = 'OFF';            // [ON / OFF] - Usar bot em https://freenem.com/
const freeNEM_Login               = '*************';  // Login (obrigatório, porque a sessão é válida por apenas 3 horas)
const freeNEM_Password            = '*************';  // Senha (pelo mesmo motivo)
const freeNEM_RandomTimer         = 'OFF';	          // [ON / OFF] - Atraso aleatório de 30 segundos a 2 minutos antes do próximo lançamento em https://freenem.com/

const reCAPTCHA_freeNEM_ruCaptcha = 'OFF';            // [ON / OFF] - Reconhecimento do reCAPTCHA v2 em https://freenem.com/ via ruCaptcha.com / 2Captcha.com
const reCAPTCHA_freeNEM_XCaptcha  = 'ON';            // [ON / OFF] - Reconhecimento do reCAPTCHA v2 em https://freenem.com/ via X-Captcha.ru
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 *  @description Resolvendo o reCAPTCHA v2 via https://ruCaptcha.com (http://discount.ruCaptcha.com) / http://2Captcha.com (http://discount.2Captcha.com)
 *  @author Group Din Din na Net - http://dindinnanet.com.br
 *
 *  @function solveReCaptcha_ruCaptcha
 *  @param { String } data_sitekey Site key
 *  @param { String } URL de pageurl da página na qual o reCAPTCHA v2 é reconhecido
 *  @param { Number } Parâmetro de solicitação invisível necessário para resolver o reCAPTCHA V2 invisível
 *  @returns { JSON } Um objeto que contém informações sobre uma solicitação bem-sucedida / malsucedida para o servidor - https://ruCaptcha.com (http://discount.ruCaptcha.com) / http://2Captcha.com (http: //discount.2Captcha. com)
 */
function solveReCaptcha_ruCaptcha(data_sitekey, pageurl, invisble) {
	var serverURL = 'http://discount.rucaptcha.com/';
	while (true) {
		iimPlayCode('SET !TIMEOUT_PAGE 60\nTAB OPEN\nTAB T=2\nURL GOTO=' + serverURL + 'in.php?key=' + apiKey_ruCaptcha + '&method=userrecaptcha&googlekey=' + data_sitekey + '&pageurl=' + pageurl + '&invisible=' + invisble + '&json=1&soft_id=2004');
		var answer = JSON.parse(window.content.document.getElementsByTagName('pre')[0].firstChild.data);
		if (!answer['status']) {
			if (answer['request'] === 'ERROR_NO_SLOT_AVAILABLE') {
                iimDisplay('[ ' + serverURL + ' ]: Error! Tentando resolver de novo...');
                log(pageurl, 'Error ' + serverURL + ' (' + answer['request'] + '). Alterando o servidor para a prioridade e tente novamente...');
                serverURL = 'http://rucaptcha.com/'; // => Nós mudamos o servidor para a prioridade, por causa da fila lotada no servidor com desconto
                iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
				continue;
			}
			iimDisplay('[ ' + serverURL + ' ]: Error! Tentando resolver de novo...');
            log(pageurl, 'Error ' + serverURL + ' (' + answer['request'] + '). Tentando mais uma vez resolver o captcha...');
            iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
			return { 'status' : 0, 'taskId' : 0, 'hash' : answer['request'], 'server' : serverURL }; // => { status : 0, taskId : 0, hash : ERROR_CODE, server : SERVER_URL }
		}
		var taskId = answer['request'];
		break;
	}

	iimPlayCode('WAIT SECONDS=10');

	var numberOfIterations = 1;
	while (numberOfIterations <= 30) {
		iimPlayCode('SET !TIMEOUT_PAGE 60\nURL GOTO=' + serverURL + 'res.php?key=' + apiKey_ruCaptcha + '&action=get&id=' + taskId + '&json=1');
		answer = JSON.parse(window.content.document.getElementsByTagName('pre')[0].firstChild.data);
		if (answer['status']) {
			iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
			break;
		} else {
			if (answer['request'] !== 'CAPCHA_NOT_READY') {
				iimDisplay('[ ' + serverURL + ' ]: Error! Trying to solve again...');
				log(pageurl, 'Ошибка ' + serverURL + ' (' + answer['request'] + '). Пытаемся ещё раз решить капчу...');
				iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
				return { 'status' : 0, 'taskId' : taskId, 'hash' : answer['request'], 'server' : serverURL }; // => { status : 0, taskId : 0, hash : ERROR_CODE, server : SERVER_URL }
			}

			if (numberOfIterations == 30) {
				iimDisplay('[ ' + serverURL + ' ]: O tempo de resposta expirou! Tentando novamente...');
				log(pageurl, 'O tempo de resposta expirou! Tente mais...');
				iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
				return { 'status' : 0, 'taskId' : taskId, 'hash' : answer['request'], 'server' : serverURL }; // => { status : 0, taskId : 0, hash : 'CAPCHA_NOT_READY', server : SERVER_URL }
			}

			iimDisplay('N° de Tentativas : ' + numberOfIterations);
			iimPlayCode('WAIT SECONDS=5'); // => 10 + 30 * 5 = 160 Segundos.
			numberOfIterations++;
		}
	}
	return { 'status' : answer['status'], 'taskId' : taskId, 'hash' : answer['request'], 'server' : serverURL };
}

/**
 *  @description Resolvendo captchas reCAPTCHA v2 via http://X-Captcha.ru/
 *  @author Group Din Din na Net - http://dindinnanet.com.br
 *
 *	@function solveReCaptcha_XCaptcha
 *  @param { String } data_sitekey Chave do site
 *  @param { String } pageurl URL a página na qual o reconhecimento ocorre reCAPTCHA v2
 *  @returns { JSON } Um objeto que contém informações sobre bem-sucedida / um pedido mal-sucedido para o servidor - http://x-captcha2.ru
 */
function solveReCaptcha_XCaptcha(data_sitekey, pageurl) {
    while (true) {
        iimPlayCode('SET !TIMEOUT_PAGE 60\nTAB OPEN\nTAB T=2\nURL GOTO=http://x-captcha2.ru/in.php?key=' + apiKey_XCaptcha + '&method=userrecaptcha&googlekey=' + data_sitekey + '&pageurl=' + pageurl + '&json=1');
        var answer = JSON.parse(window.content.document.getElementsByTagName('pre')[0].firstChild.data);
        if (!answer['request'].includes('OK')) {
            if ((answer['request'] === 'ERROR_NOT_SLOT_ZERO') || (answer['request'] === 'ERROR_NOT_SLOT_BUSY') || (answer['request'] === 'ERROR_PAUSE_SERVICE')) {
                iimDisplay('[ http://x-captcha2.ru/ ]: Erro! Tentando resolver de novo...');
                log(pageurl, 'Erro http://x-captcha2.ru/ (' + answer['request'] + '). Tentando novamente...');
                iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
				continue;
            }
            iimDisplay('[ http://x-captcha2.ru/ ] : Erro! Tentando resolver de novo...');
            log(pageurl, 'Erro http://x-captcha2.ru/ (' + answer['request'] + '). Tentando novamente...');
            iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
            return { 'status' : 0, 'taskId' : 0, 'hash' : answer['request'], 'server' : 'http://x-captcha2.ru/' }; // => { status : 0, taskId : 0, hash : ERROR_CODE, server : 'http://x-captcha2.ru/' }
        }
        var taskId = answer['request'].split('|')[1];
        break;
    }

	iimPlayCode('WAIT SECONDS=10');

	var numberOfIterations = 1;
	while (numberOfIterations <= 16) {
        iimPlayCode('SET !TIMEOUT_PAGE 60\nURL GOTO=http://x-captcha2.ru/res.php?key=' + apiKey_XCaptcha + '&id=' + taskId + '&json=1');
		answer = JSON.parse(window.content.document.getElementsByTagName('pre')[0].firstChild.data);
        if (answer['request'].includes('OK')) {
			iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
			break;
		}
		else {
			if (answer['request'] !== 'CAPCHA_NOT_READY') {
				iimDisplay('[ http://x-captcha2.ru/ ] : Erro! Tentando resolver de novo...');
                log(pageurl, 'Erro http://x-captcha2.ru/ (' + answer['request'] + '). Tentando mais uma vez resolver o captcha...');
                iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
				return { 'status' : 0, 'taskId' : taskId, 'hash' : answer['request'], 'server' : 'http://x-captcha2.ru/' }; // => { status : 0, taskId : identificator, hash : ERROR_CODE, server : 'http://x-captcha2.ru/' }
            }
            
            if (numberOfIterations == 16) {
                iimDisplay('[ http://x-captcha2.ru/ ]: O tempo de resposta expirou! Tentando novamente...');
				log(pageurl, 'O tempo de resposta expirou! Tentando novamente...');
				iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE')
				return { 'status' : 0, 'taskId' : taskId, 'hash' : answer['request'], 'server' : 'http://x-captcha2.ru/' }; // => { status : 0, taskId : 0, hash : 'CAPCHA_NOT_READY', server : 'http://x-captcha2.ru/' }
            }

			iimDisplay('Iteration number : ' + numberOfIterations);
			iimPlayCode('WAIT SECONDS=5'); // => 10 + 16 * 5 = 90 Segundos.
			numberOfIterations++;
        }
	}
	return { 'status' : answer['status'], 'taskId' : taskId, 'hash' : answer['request'].split('|')[1], 'server' : 'http://x-captcha2.ru/' };
}

/**
 *  @description Resolvendo captchas de texto via https://ruCaptcha.com / http://2Captcha.com
 *  @author Group Din Din na Net - http://dindinnanet.com.br
 *
 *  @function solveTextCaptcha_ruCaptcha
 *  @param {String} URL de pageurl da página em que o captcha de texto é reconhecido
 * 	@param {String} captchaName O nome da imagem com captcha
 * 	@param {Number} minLen Número mínimo de caracteres na resposta
 * 	@param {Number} maxLen Número máximo de caracteres na resposta
 * 	@param {String} regsense Sensibilidade ao case - nem pergunte o que esta pohaaa - esta no site do 2captcha e rucaptcha
 * 	@returns {JSON} Um objeto que contém informações sobre uma solicitação bem-sucedida / mal-sucedida para o servidor - http://ruCaptcha.com / http://2Captcha.com
 */
function solveTextCaptcha_ruCaptcha(pageurl, captchaName, minLen, maxLen, regsense) {
	iimPlayCode('SET !ERRORIGNORE YES'
			+n+ 'SET !TIMEOUT_PAGE 60'
			+n+ 'SET !TIMEOUT_STEP 10'
			+n+ 'TAB OPEN'
			+n+ 'TAB T=2'
			+n+ 'URL GOTO=http://imacros2.rucaptcha.com/new/'
			+n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:getcapcha.php ATTR=NAME:key CONTENT=' + apiKey_ruCaptcha
			+n+ 'TAG POS=1 TYPE=INPUT:FILE FORM=ACTION:getcapcha.php ATTR=NAME:file CONTENT=' + captchaPath + captchaName
			+n+ 'TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ACTION:getcapcha.php ATTR=NAME:get_id CONTENT=YES'
			+n+ 'TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ACTION:getcapcha.php ATTR=NAME:regsense CONTENT=' + regsense
			+n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:getcapcha.php ATTR=NAME:min_len CONTENT=' + minLen
			+n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:getcapcha.php ATTR=NAME:max_len CONTENT=' + maxLen
			+n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:getcapcha.php ATTR=NAME:language CONTENT=2'
			+n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:getcapcha.php ATTR=NAME:numeric CONTENT=2'
			+n+ 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:getcapcha.php ATTR=NAME:soft_id CONTENT=2004'
			+n+ 'SET !TIMEOUT_PAGE 100'
			+n+ 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ACTION:getcapcha.php ATTR=*');
	var result = window.content.document.querySelector("body").innerHTML;
	iimPlayCode('SET !TIMEOUT_PAGE 30\nTAB CLOSE');

	if (result.includes('OK'))
		return { 'status' : 1, 'taskId' : result.split('|')[1], 'hash' : result.split('|')[2], 'server' : 'http://rucaptcha.com/' };
	iimDisplay('[ http://rucaptcha.com/ ] : Erro! Tentando resolver de novo...');
	log(pageurl, 'Erro http://rucaptcha.com/ (' + result + '). Tentando mais uma vez resolver o captcha...');
	return { 'status' : 0, 'taskId' : 0, 'hash' : result, 'server' : 'http://rucaptcha.com/' }; // => { status : 0, taskId : 0, hash : ERROR_CODE, server : 'http://rucaptcha.com/' }
}

/**
 *  @description Enviando relatórios para respostas erradas de http://discount.rucaptcha.com / https://rucaptcha.com
 *  @author Group Din Din na Net - http://dindinnanet.com.br
 *
 *  @function reportCaptcha
 *  @param {String} URL serverURL do servidor de reconhecimento captcha
 *  @param {String} ID de tarefa do captcha resolvido incorretamente
 */
function reportCaptcha(serverURL, apiKey, taskId) {
	iimPlayCode('SET !ERRORIGNORE YES'
			+n+ 'SET !TIMEOUT_PAGE 30'
			+n+ 'TAB OPEN'
			+n+ 'TAB T=2'
			+n+ 'URL GOTO=' + serverURL + 'res.php?key=' + apiKey + '&action=reportbad&id=' + taskId
			+n+ 'TAB CLOSE');
}

/**
 *  @description Aguardando até o próximo encontro
 *  @author Group Din Din na Net - http://dindinnanet.com.br
 *
 *  @function timeTillNextRoll
 *  @param {String} URL do pageurl da página em que o timer foi detectado (para log.txt)
 * 	@param {String} pageurl_RandomTimer Atraso aleatório
 * 	@param {Number} segundos Tempo até o próximo lançamento em segundos
 */
function timeTillNextRoll(pageurl, pageurl_RandomTimer, seconds) {
	if (pageurl_RandomTimer === 'ON')
		seconds += Math.floor(Math.random () * 90 + 20);
	seconds += 10;	// => espera padrão

	iimDisplay('Time till next roll: ' + seconds + ' secs.'
		   +n+'dindinnanet.com.br'
		   +n+ 'Ganhos para esta sessão:'
		   +n+ '[ freebitco.in ]'
		   +n+ '\t# ' + Winnings_freeBITCOIN.toFixed(8) + ' BTC'
		   +n+ '\t# ' + Rewards_freeBITCOIN + ' Reward Points'
		   +n+ '\t# ' + Tickets_freeBITCOIN + ' Lottery Tickets'
		   +n+ '[ freedoge.co.in ]'
		   +n+ '\t# ' + Winnings_freeDOGECOIN.toFixed(8) + ' DOGE'
		   +n+ '[ freenem.com ]'
		   +n+ '\t# ' + Winnings_freeNEM.toFixed(8) + ' NEM');
	log(pageurl, 'Esperando ' + seconds + ' até o próximo roll...');
	iimPlayCode('WAIT SECONDS=' + seconds);
}

/**
 * 	@description Gerando um nome aleatório para o arquivo de texto com captcha de texto
 * 	@author Group Din Din na Net - http://dindinnanet.com.br
 *
 * 	@função timeTillNextRoll
 * 	@returns {String} O nome da imagem com captcha
 */
function makeUniqueName() {
    var text = 'FreeCrypto_';
    var possible = 'abcdefghijklmnopqrstuvwxyz0123456789';

    for(let i = 0; i <= 10; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    return text + '.jpg';
}

/**
 *  @description Logging
 * 	@author Group Din Din na Net - http://dindinnanet.com.br
 *
 *  @function log
 *  @param {String} URL do pageurl da página
 *  @param {String} message Novo registro
 */
function log(pageurl, message) {
	var text = '[ ' + new window.Date().toLocaleDateString() + ' ' + new window.Date().toLocaleTimeString() + ' ]: (' + pageurl + ') - ' + message + '\r\n';
	var fileDescriptor = imns.FIO.openNode(logPath);
	imns.FIO.appendTextFile(fileDescriptor, text);
}

/**
 *  @description Gerando um nome aleatório para um arquivo de texto com um captcha
 * 	@author Group Din Din na Net - http://dindinnanet.com.br
 *
 *	@function sendEmail
 *  @param { String } message Mensagem informativa que irá para o Email
 */
function sendEmail(message) {
	iimPlayCode('SET !ERRORIGNORE YES'
			+n+ 'SET !TIMEOUT_PAGE 60'
			+n+ 'SET !TIMEOUT_STEP 1'
			+n+ 'TAB OPEN'
			+n+ 'TAB T=2'
			+n+ 'URL GOTO=http://multicaptchabot.siteme.org/contacts.php'
			+n+ 'TAG POS=1 TYPE=INPUT:EMAIL FORM=ID:feedback-form ATTR=ID:email CONTENT=\"' + mail + '\"'
			+n+ 'TAG POS=1 TYPE=TEXTAREA FORM=ID:feedback-form ATTR=ID:message CONTENT=\"' + message + '\"'
			+n+ 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ID:feedback-form ATTR=*'
			+n+ 'TAB CLOSE');
}

/**
 *  @description Informing about the unsuccessful captcha solution
 *	@author Group Din Din na Net - http://dindinnanet.com.br
 *
 *  @function notificationsBadCaptcha
 *  @param {String} URL do pageurl da página
 */
function notificationsBadCaptcha(pageurl) {
	iimDisplay('Bot didn\'Decida o captcha 5 vezes seguidas. Volte um pouco mais tarde...');
	log(pageurl, 'Bot não decidiu captcha 5 vezes seguidas. Vamos voltar daqui a pouco...');
	sendEmail('( ' + pageurl + ' ) - Bot não decidiu captcha 5 vezes seguidas. Vamos voltar daqui a pouco...');
}

/**
 *  @description Informando o preenchimento incompleto dos dados iniciais
 *  @author Group Din Din na Net - http://dindinnanet.com.br
 *
 *  @função checkForInattention
 *  @returns {Boolean} Um sinalizador indicando o preenchimento incorreto dos dados iniciais
 */
function checkForInattention() {
    if ((freeBITCOIN === 'OFF') && (freeDOGECOIN === 'OFF') && (freeNEM === 'OFF')) {
        alert('Antes de iniciar o Script \"Free-Bitcoin-Dogecoin-Xem.js\" você deve condifgurar para ser usado corretamente. Seja cuidadoso!\n\nLinha - 32: const freeBITCOIN      = \'OFF\';\nLinha - 40: const freeDOGECOIN = \'OFF\';\nLinha - 47: const freeNEM             = \'OFF\';');
        return true;
    }

    if ((apiKey_ruCaptcha === '******************************') && (apiKey_XCaptcha === '******************************')) {
        alert('Antes de lançar o bot em um arquivo de texto \"Free-Bitcoin-Dogecoin-Xem.js\" precisa inserir API KEY serviço de reconhecimento(em vez de asteriscos), através de qual solução de captcha o bot Resolvera. Tenha cuidado!\n\nLinha - 27: const apiKey_ruCaptcha = \'******************************\';\nLinha - 28: const apiKey_XCaptcha  = \'******************************\';');
        return true;
    }

    // https://freebitco.in/ - - - - - >
    if ((freeBITCOIN === 'ON') && (reCAPTCHA_freeBITCOIN_ruCaptcha === 'OFF') && (reCAPTCHA_freeBITCOIN_XCaptcha === 'OFF')) {
        alert('Você ativou o bot para https://freebitco.in/, mas esqueceu de escolher o serviço para resolver o reCAPTCHA v2. Tenha cuidado!\n\nLinha - 36: const reCAPTCHA_freeBITCOIN_ruCaptcha = \'OFF\';\nLinha - 37: const reCAPTCHA_freeBITCOIN_XCaptcha  = \'OFF\';');
        return true;
    }

    if ((freeBITCOIN === 'ON') && (reCAPTCHA_freeBITCOIN_ruCaptcha === 'ON') && (apiKey_ruCaptcha === '******************************')) {
        alert('Você ativou o bot para https://freebitco.in/ e escolheu o serviço ruCaptcha.com, através do qual a Resolução será tomada reCAPTCHA v2, mas esqueceu de colocar a API KEY. Seja cuidadoso!\n\nLinha - 27: const apiKey_ruCaptcha = \'******************************\';');
        return true;
    }

    if ((freeBITCOIN === 'ON') && (reCAPTCHA_freeBITCOIN_XCaptcha === 'ON') && (apiKey_XCaptcha === '******************************')) {
        alert('Você ativou o bot para https://freebitco.in/ e escolheu o serviço X-Captcha.ru, através do qual a Resolução será tomada reCAPTCHA v2, mas esqueceu de colocar a API KEY. Seja cuidadoso!\n\nLinha - 28: const apiKey_XCaptcha = \'******************************\';');
        return true;
    }

    if ((freeBITCOIN === 'ON') && (apiKey_ruCaptcha === '******************************')) {
        alert('Você ativou o bot para https://freebitco.in/, mas esqueceu de inserir a API KEY do ruCaptcha.com, Seja cuidadoso!!\n\nLinha - 27: const apiKey_ruCaptcha = \'******************************\';');
        return true;
    }

    // https://freedoge.co.in/ - - - - - >
    if ((freeDOGECOIN === 'ON') && (reCAPTCHA_freeDOGECOIN_ruCaptcha === 'OFF') && (reCAPTCHA_freeDOGECOIN_XCaptcha === 'OFF')) {
        alert('Você ativou o bot para https://freedoge.co.in/, mas esqueci de escolher o serviço através do qual a solução irá ocorrer reCAPTCHA v2. Tenha cuidado!\n\nLinha - 43: const reCAPTCHA_freeDOGECOIN_ruCaptcha = \'OFF\';\nLinha - 44: const reCAPTCHA_freeDOGECOIN_XCaptcha  = \'OFF\';');
        return true;
    }

    if ((freeDOGECOIN === 'ON') && (reCAPTCHA_freeDOGECOIN_ruCaptcha === 'ON') && (apiKey_ruCaptcha === '******************************')) {
        alert('Você ativou o bot para https://freedoge.co.in/ e escolheu o serviço ruCaptcha.com, através do qual a Resolução será tomada reCAPTCHA v2, mas esqueceu de colocar a API KEY. Seja cuidadoso!\n\nLinha - 27: const apiKey_ruCaptcha = \'******************************\';');
        return true;
    }

    if ((freeDOGECOIN === 'ON') && (reCAPTCHA_freeDOGECOIN_XCaptcha === 'ON') && (apiKey_XCaptcha === '******************************')) {
        alert('Você ativou o bot para https://freedoge.co.in/ e escolheu o serviço X-Captcha.ru, através do qual a Resolução será tomada reCAPTCHA v2, mas esqueceu de colocar a API KEY. Seja cuidadoso!\n\nLinha - 28: const apiKey_XCaptcha = \'******************************\';');
        return true;
    }
    
    // https://freenem.com/ - - - - - >
    if ((freeNEM === 'ON') && (reCAPTCHA_freeNEM_ruCaptcha === 'OFF') && (reCAPTCHA_freeNEM_XCaptcha === 'OFF')) {
        alert('Você ativou o bot para https://frenem.com/, mas esqueceu de escolher o serviço através do qual a solução irá resolver reCAPTCHA v2. Tenha cuidado!\n\nLinha - 52: const reCAPTCHA_freeNEM_ruCaptcha = \'OFF\';\nLinha - 53: const reCAPTCHA_freeNEM_XCaptcha  = \'OFF\';');
        return true;
    }

    if ((freeNEM === 'ON') && (reCAPTCHA_freeNEM_ruCaptcha === 'ON') && (apiKey_ruCaptcha === '******************************')) {
        alert('Você ativou o bot para проекте https://frenem.com/ e escolheu o serviço ruCaptcha.com, através do qual uma decisão será tomada reCAPTCHA v2, mas esqueceu de colocar na API KEY. Tenha cuidado!\n\nLinha - 27: const apiKey_ruCaptcha = \'******************************\';');
        return true;
    }

    if ((freeNEM === 'ON') && (reCAPTCHA_freeNEM_XCaptcha === 'ON') && (apiKey_XCaptcha === '******************************')) {
        alert('Você ativou o bot para https://frenem.com/ e escolheu o serviço X-Captcha.ru, através do qual uma decisão será tomada reCAPTCHA v2, mas esqueceu de colocar na API KEY. Tenha cuidado!\n\nLinha - 28: const apiKey_XCaptcha = \'******************************\';');
        return true;
	}
	
	if ((freeNEM === 'ON') && ((freeNEM_Login === '*************') || (freeNEM_Password === '*************'))) {
		alert('Você ativou o bot para https://freenem.com/, Mas esqueci de especificar seu login e senha. Tenha cuidado!\n\nLinha - 48: const freeNEM_Login        = \'*************\';\n\nLinha - 49: const freeNEM_Password = \'*************\';');
		return true;
	}

    return false;
}
//---------------------------------------------------------------------------------------------------------------------------------------------------
const n = '\n';
var Winnings_freeBITCOIN = 0, Rewards_freeBITCOIN = 0, Tickets_freeBITCOIN = 0, Winnings_freeDOGECOIN = 0, Winnings_freeNEM = 0;

while (true) {
    if (checkForInattention())
        break;

	try {
		while (true) {
			// https://freebitco.in/ - - - - - >
			if (freeBITCOIN === 'ON') {
				freeBitcoinBody : {
					do {
						iimDisplay('Connecting to the https://freebitco.in/...');
						log('freebitco.in', 'Подключение к проекту...');
						iimPlayCode('SET !TIMEOUT_PAGE 30'
								+n+ 'TAB CLOSEALLOTHERS'
								+n+ 'TAB T=1'
								+n+ 'TAB CLOSE'
								+n+ 'URL GOTO=https://freebitco.in/?op=home'
								+n+ 'WAIT SECONDS=8');
						if (!window.content.document.getElementById('free_play_form_button')) {
							iimDisplay('Cloudflare protection is detected...');
							log('freebitco.in', 'Detectado cloudflare protection...');
							iimPlayCode('WAIT SECONDS=20');
							continue;
						}
						break;
					} while (!window.content.document.getElementById('free_play_form_button'));

					if (/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)) {
						let timer = Number(/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)[1]) * 60 + Number(/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)[2]);
						timeTillNextRoll('freebitco.in', freeBITCOIN_RandomTimer, timer);
					}

					let solvingCaptchaCycles = 1, answer = null;
					freeBitcoinLabel:
					while (solvingCaptchaCycles <= 5) {
					    do {
							iimDisplay('Refreshing page...');
							log('freebitco.in', 'Обновляем страницу...');
							iimPlayCode('SET !TIMEOUT_PAGE 60'
									+n+ 'TAB CLOSEALLOTHERS'
									+n+ 'TAB T=1'
									+n+ 'TAB CLOSE'
									+n+ 'URL GOTO=https://freebitco.in/?op=home'
									+n+ 'WAIT SECONDS=8');
							if (!window.content.document.getElementById('free_play_form_button')) {
								iimDisplay('Cloudflare protection is detected...');
								log('freebitco.in', 'Обнаружена cloudflare protection...');
								iimPlayCode('WAIT SECONDS=20');
								continue;
							}
							break;
						} while (!window.content.document.getElementById('free_play_form_button'));

                        if (/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)) {
                            iimDisplay('There was an exception...');
                            log('freebitco.in', 'Произошел отлов исключительной ситуации...');
                            break;
                        }
	
						if (freeBITCOIN_RewardPoints === 'ON') {
							let accountRewardPoints = Number(window.content.document.getElementsByClassName('user_reward_points')[0].innerHTML.replace(',', ''));
							if (!window.content.document.getElementById('bonus_container_free_points')) {
								if (accountRewardPoints < 12) { }
								else if ((accountRewardPoints >= 12 ) && (accountRewardPoints < 120)) {
									iimDisplay('Activating 1 REWARD POINTS / ROLL...');
									log('freebitco.in', 'Активируем \'1 REWARD POINTS / ROLL\'');
									iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=BUTTON ATTR=ONCLICK:RedeemRPProduct(\'free_points_1\')\nWAIT SECONDS=1');
									accountRewardPoints -= 12;
								}
								else if ((accountRewardPoints >= 120) && (accountRewardPoints < 600)) {
									iimDisplay('Activating 10 REWARD POINTS / ROLL...');
									log('freebitco.in', 'Активируем \'10 REWARD POINTS / ROLL\'');
									iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=BUTTON ATTR=ONCLICK:RedeemRPProduct(\'free_points_10\')\nWAIT SECONDS=1');
									accountRewardPoints -= 120;
								}
								else if ((accountRewardPoints >= 600) && (accountRewardPoints < 1200)) {
									iimDisplay('Activating 50 REWARD POINTS / ROLL...');
									log('freebitco.in', 'Активируем \'50 REWARD POINTS / ROLL\'');
									iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=BUTTON ATTR=ONCLICK:RedeemRPProduct(\'free_points_50\')\nWAIT SECONDS=1');
									accountRewardPoints -= 600;
								}
								else {
									iimDisplay('Activating 100 REWARD POINTS / ROLL...');
									log('freebitco.in', 'Активируем \'100 REWARD POINTS / ROLL\'');
									iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=BUTTON ATTR=ONCLICK:RedeemRPProduct(\'free_points_100\')\nWAIT SECONDS=1');
									accountRewardPoints -= 1200;
								}
							}
	
							if (!window.content.document.getElementById('bonus_container_fp_bonus')) {
								if (accountRewardPoints < 2800) { }
								else if ((accountRewardPoints >= 2800) && (accountRewardPoints < 4400)) {
									iimDisplay('Activating 500% FREE BTC BONUS...');
									log('freebitco.in', 'Активируем \'500% FREE BTC BONUS\'');
									iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=BUTTON ATTR=ONCLICK:RedeemRPProduct(\'fp_bonus_500\')\nWAIT SECONDS=1');
								}
								else
								{
									iimDisplay('Activating 1000% FREE BTC BONUS...');
									log('freebitco.in', 'Активируем \'1000% FREE BTC BONUS\'');
									iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=BUTTON ATTR=ONCLICK:RedeemRPProduct(\'fp_bonus_1000\')\nWAIT SECONDS=1');
								}
							}
						}

						if (window.content.document.getElementsByClassName('cc_banner cc_container cc_container--open').length)
							iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 1\nTAG POS=1 TYPE=A ATTR=TXT:Got<SP>it!');

						iimDisplay('Determining type of captcha...');
						log('freebitco.in', 'Определяем тип капчи на странице...');
						window.scrollBy(0, 20000);

						if (window.content.document.getElementById('switch_captchas_button')) {
							iimDisplay('\'SWITCH CAPTCHA BUTTON\' is detected. Choosing double captchas.net. Solving...');
							log('freebitco.in', 'Двойная captchas.net обнаружена. Попытаемся ее решить...');

							let str = (window.content.document.getElementById("switch_captchas_button").onclick + ' ').split('\'')[1].split('\'')[0];
							if (str === 'double_captchas')
								iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nEVENT TYPE=CLICK SELECTOR=\'#switch_captchas_button\' BUTTON=0\nWAIT SECONDS=2.5');
				
							let captchasNet = window.content.document.getElementsByClassName('captchasnet_captcha_content');
							for (let i = 1; i <= captchasNet.length; i++) {
								let regsense = (i == 1) ? 'NO' : 'YES';
								let captchaName = makeUniqueName();
								iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nONDOWNLOAD FOLDER=' + captchaPath + ' FILE=' + captchaName + ' WAIT=YES\nTAG POS=' + i + ' TYPE=DIV ATTR=CLASS:captchasnet_captcha_content CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT');
								
								answer = solveTextCaptcha_ruCaptcha('freebitco.in', captchaName, 6, 6, regsense);
								if (!answer['status']) {
									if (solvingCaptchaCycles == 5) {
										notificationsBadCaptcha('freebitco.in');
										break freeBitcoinBody;
									}
									solvingCaptchaCycles++;
									continue freeBitcoinLabel;
								}

								iimPlayCode('SET !ERRORIGNORE YES'
										+n+ 'SET !TIMEOUT_STEP 10'
                                        +n+ 'WAIT SECONDS=2.5'
										+n+ 'TAG POS=' + i + ' TYPE=INPUT:TEXT ATTR=CLASS:captchasnet_captcha_input_box CONTENT=\"' + answer['hash'] + '\"'
										+n+ 'FILEDELETE NAME=' + captchaPath + captchaName);
							}
						} else {
							if (window.content.document.getElementById('g-recaptcha-response')) {
								iimDisplay('reCAPTCHA v2 is detected. Solving...');
								log('freebitco.in', 'reCAPTCHA v2 обнаружена. Попытаемся ее решить...');

								window.content.document.getElementById('g-recaptcha-response').style.display = '';
								iimPlayCode('SET !ERRORIGNORE YES'
										+n+ 'SET !TIMEOUT_STEP 10'
										+n+ 'FRAME F=1'
										+n+ 'TAG POS=1 TYPE=DIV ATTR=ROLE:presentation&&CLASS:recaptcha-checkbox-checkmark&&TXT:'
										+n+ 'WAIT SECONDS=8');

								if (!window.content.document.getElementById('g-recaptcha-response').value.length) {
									let data_sitekey = window.content.document.getElementsByClassName('g-recaptcha')[0].getAttribute('data-sitekey');
                                    answer = (reCAPTCHA_freeBITCOIN_ruCaptcha === 'ON') ? solveReCaptcha_ruCaptcha(data_sitekey, 'https://freebitco.in/', 0) : solveReCaptcha_XCaptcha(data_sitekey, 'https://freebitco.in/');
                                    if (!answer['status']) {
                                        if (solvingCaptchaCycles == 5) {
                                            notificationsBadCaptcha('freebitco.in');
                                            break;
                                        }
                                        solvingCaptchaCycles++;
                                        continue;
                                    }
									iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nWAIT SECONDS=2.5\nTAG POS=1 TYPE=TEXTAREA FORM=ID:* ATTR=ID:g-recaptcha-response CONTENT=\"' + answer['hash'] + '\"');
								}
							} else if (window.content.document.getElementsByClassName('captchasnet_captcha_content').length) {
								iimDisplay('Captchas.net / Freebitco.in custom captcha is detected. Solving...');
								log('freebitco.in', 'Captchas.net обнаружена. Попытаемся ее решить...');
								
								let captchasNet = window.content.document.getElementsByClassName('captchasnet_captcha_content');
								for (let i = 1; i <= captchasNet.length; i++) {
									let regsense = (i == 1) ? 'NO' : 'YES';
									let captchaName = makeUniqueName();
									iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nONDOWNLOAD FOLDER=' + captchaPath + ' FILE=' + captchaName + ' WAIT=YES\nTAG POS=' + i + ' TYPE=DIV ATTR=CLASS:captchasnet_captcha_content CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT');
									
									answer = solveTextCaptcha_ruCaptcha('freebitco.in', captchaName, 6, 6, regsense);
									if (!answer['status']) {
										if (solvingCaptchaCycles == 5) {
											notificationsBadCaptcha('freebitco.in');
											break freeBitcoinBody;
										}
										solvingCaptchaCycles++;
										continue freeBitcoinLabel;
									}

									iimPlayCode('SET !ERRORIGNORE YES'
											+n+ 'SET !TIMEOUT_STEP 10'
											+n+ 'WAIT SECONDS=2.5'
											+n+ 'TAG POS=' + i + ' TYPE=INPUT:TEXT ATTR=CLASS:captchasnet_captcha_input_box CONTENT=\"' + answer['hash'] + '\"'
											+n+ 'FILEDELETE NAME=' + captchaPath + captchaName);
								}
							} else if (window.content.document.getElementById('adcopy-puzzle-image')) {
								iimDisplay('Solvemedia is detected. Solving...');
								log('freebitco.in', 'Solvemedia обнаружена. Попытаемся ее решить...');

								let solveMedia = window.content.document.getElementById('adcopy-puzzle-image');
								let captchaName = makeUniqueName();
								iimPlayCode('SET !ERRORIGNORE YES'
										+n+ 'SET !TIMEOUT_STEP 10'
										+n+ 'TAG POS=1 TYPE=IMG ATTR=SRC:https://api-secure.solvemedia.com/media/reload-whV2.gif'
										+n+ 'WAIT SECONDS=10'
										+n+ 'ONDOWNLOAD FOLDER=' + captchaPath + ' FILE=' + captchaName + ' WAIT=YES'
										+n+ 'TAG POS=1 TYPE=DIV ATTR=ID:adcopy-puzzle-image CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT');
								
								answer = solveTextCaptcha_ruCaptcha('freebitco.in', captchaName, 0, 0, 'NO');
								if (!answer['status']) {
									if (solvingCaptchaCycles == 5) {
										notificationsBadCaptcha('freebitco.in');
										break;
									}
									solvingCaptchaCycles++;
									continue;
								}

                                iimPlayCode('SET !ERRORIGNORE YES'
                                        +n+ 'SET !TIMEOUT_PAGE 30'
										+n+ 'SET !TIMEOUT_STEP 10'
										+n+ 'WAIT SECONDS=2.5'
										+n+ 'TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:adcopy_response CONTENT=\"' + answer['hash']  + '\"'
										+n+ 'FILEDELETE NAME=' + captchaPath + captchaName);
							}
						}

						iimDisplay('Claiming satoshis...');
						log('freebitco.in', 'Собираем сатоши...');
						iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=INPUT:SUBMIT ATTR=ID:free_play_form_button\nWAIT SECONDS=8');

						if (Number(window.content.document.getElementById('winnings').innerHTML) > 0) {
							iimDisplay('Successfully claimed!');
							log('freebitco.in', 'Успешный сбор! Собрано: ' + Number(window.content.document.getElementById('winnings').innerHTML) + ' BTC; ' + Number(window.content.document.getElementById('fp_reward_points_won').innerHTML) + ' Reward Points; ' + Number(window.content.document.getElementById('fp_lottery_tickets_won').innerHTML) + ' Lottery Tickets');
							Winnings_freeBITCOIN += Number(window.content.document.getElementById('winnings').innerHTML);
							Rewards_freeBITCOIN  += Number(window.content.document.getElementById('fp_reward_points_won').innerHTML);
							Tickets_freeBITCOIN  += Number(window.content.document.getElementById('fp_lottery_tickets_won').innerHTML);
							break;
						} else {
							if ((window.content.document.getElementById('free_play_error').style.display !== 'none') && (window.content.document.getElementById('free_play_error').innerText.includes('verify'))) {
								iimDisplay('Email verification is detected...');
                                log('freebitco.in', 'Необходимо подтвердить email, чтобы продолжить сбор!');
                                sendEmail('( freebitco.in ) - Необходимо подтвердить email, чтобы продолжить сбор!');
								break;
							} else if ((window.content.document.getElementById('free_play_error').style.display !== 'none') && (window.content.document.getElementById('free_play_error').innerText.includes('blocked'))) {
								iimDisplay('Account of the https://freebitco.in/ has been banned...');
                                log('freebitco.in', 'Аккаунт забанен!');
                                sendEmail('( freebitco.in ) - Аккаунт забанен!');
								break;
							} else {
								iimDisplay('Captcha was solved incorrectly. Sending a report and trying to solve captcha again...');
								log('freebitco.in', 'Капча была решена неверно. Отправляем жалобу и пытаемся решить еще раз...');
                                if (answer['server'].includes('rucaptcha.com')) {
                                    reportCaptcha(answer['server'], apiKey_ruCaptcha, answer['taskId']);
                                } else {
                                    reportCaptcha(answer['server'], apiKey_XCaptcha, answer['taskId']);
                                }
								
								if (solvingCaptchaCycles == 5) {
									notificationsBadCaptcha('freebitco.in');
									break;
								}
								solvingCaptchaCycles++;
								continue;
							}
						}
					}
				}
			}

			// https://freedoge.co.in/ - - - - - >
			if (freeDOGECOIN === 'ON') {
                do {
                    iimDisplay('Connecting to the https://freedoge.co.in/...');
                    log('freedoge.co.in', 'Подключение к проекту...');
                    iimPlayCode('SET !TIMEOUT_PAGE 30'
                            +n+ 'TAB CLOSEALLOTHERS'
                            +n+ 'TAB T=1'
                            +n+ 'TAB CLOSE'
                            +n+ 'URL GOTO=https://freedoge.co.in/'
                            +n+ 'WAIT SECONDS=8');

                    if (!window.content.document.getElementById('free_play_form_button')) {
                        iimDisplay('Cloudflare protection is detected...');
                        log('freedoge.co.in', 'Обнаружена cloudflare protection...');
                        iimPlayCode('WAIT SECONDS=20');
                        continue;
                    }
                    break;
                } while (!window.content.document.getElementById('free_play_form_button'));

                if (/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)) {
                    let timer = Number(/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)[1]) * 60 + Number(/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)[2]);
                    timeTillNextRoll('freedoge.co.in', freeDOGECOIN_RandomTimer, timer);
                }
                
                let solvingCaptchaCycles = 1, answer = null;
                while (solvingCaptchaCycles <= 5) {
					do {
						iimDisplay('Refreshing page...');
						log('freedoge.co.in', 'Обновляем страницу...');
						iimPlayCode('SET !TIMEOUT_PAGE 60'
								+n+ 'TAB CLOSEALLOTHERS'
								+n+ 'TAB T=1'
								+n+ 'TAB CLOSE'
								+n+ 'URL GOTO=https://freedoge.co.in/'
								+n+ 'WAIT SECONDS=8');
						if (!window.content.document.getElementById('free_play_form_button')) {
							iimDisplay('Cloudflare protection is detected...');
							log('freedoge.co.in', 'Обнаружена cloudflare protection...');
							iimPlayCode('WAIT SECONDS=20');
							continue;
						}
						break;
					} while (!window.content.document.getElementById('free_play_form_button'));

                    if (/^(\d+)m:(\d+)s/.exec(window.content.document.getElementsByTagName('title')[0].innerText)) {
                        iimDisplay('There was an exception...');
                        log('freedoge.co.in', 'Произошел отлов исключительной ситуации...');
                        break;
					}
					
					if (window.content.document.getElementById('free_play_captcha_types').value === 'solvemedia') {
						iimDisplay('Selecting reCAPTCHA v2...');
						log('freedoge.co.in', 'Выбираем reCAPTCHA v2...');
						iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=SELECT ATTR=ID:free_play_captcha_types CONTENT=%recaptcha_v2\nWAIT SECONDS=2');
					}
	
					if (window.content.document.getElementsByClassName('cc_banner cc_container cc_container--open').length)
						iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 1\nTAG POS=1 TYPE=A ATTR=TXT:Got<SP>it!');

                    iimDisplay('reCAPTCHA v2 is detected. Solving...');
					log('freedoge.co.in', 'reCAPTCHA v2 обнаружена. Попытаемся ее решить...');
                    window.scrollBy(0, 20000);
                        
					window.content.document.getElementById('g-recaptcha-response').style.display = '';
					iimPlayCode('SET !ERRORIGNORE YES'
							+n+ 'SET !TIMEOUT_STEP 10'
							+n+ 'FRAME F=1'
							+n+ 'TAG POS=1 TYPE=DIV ATTR=ROLE:presentation&&CLASS:recaptcha-checkbox-checkmark&&TXT:'
							+n+ 'WAIT SECONDS=8');

					if (!window.content.document.getElementById('g-recaptcha-response').value.length) {
						let data_sitekey = window.content.document.getElementsByClassName('g-recaptcha')[0].getAttribute('data-sitekey');
                        answer = (reCAPTCHA_freeDOGECOIN_ruCaptcha === 'ON') ? solveReCaptcha_ruCaptcha(data_sitekey, 'https://freedoge.co.in/', 0) : solveReCaptcha_XCaptcha(data_sitekey, 'https://freedoge.co.in/');
                        if (!answer['status']) {
                            if (solvingCaptchaCycles == 5) {
                                notificationsBadCaptcha('freedoge.co.in');
                                break;
                            }
                            solvingCaptchaCycles++;
                            continue;
                        }
						iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nWAIT SECONDS=2.5\nTAG POS=1 TYPE=TEXTAREA FORM=ID:* ATTR=ID:g-recaptcha-response CONTENT=\"' + answer['hash'] + '\"');
					}

					iimDisplay('Claiming dogetoshis...');
					log('freedoge.co.in', 'Собираем догитоши...');
					iimPlayCode('SET !ERRORIGNORE YES\nSET !TIMEOUT_STEP 10\nTAG POS=1 TYPE=INPUT:SUBMIT ATTR=ID:free_play_form_button\nWAIT SECONDS=8');

					if (Number(window.content.document.getElementById('winnings').innerHTML) > 0) {
						iimDisplay('Successfully claimed!');
						log('freedoge.co.in', 'Успешный сбор! Собрано: ' + Number(window.content.document.getElementById('winnings').innerHTML) + ' DOGE ');
						Winnings_freeDOGECOIN += Number(window.content.document.getElementById('winnings').innerHTML);
						break;
					} else {
						iimDisplay('Unsuccessfully claimed!');
						if ((window.content.document.getElementById('free_play_error').style.display !== 'none') && (window.content.document.getElementById('free_play_error').innerText.includes('verify'))) {
							iimDisplay('Email verification is detected...');
                            log('freedoge.co.in', 'Необходимо подтвердить email, чтобы продолжить сбор!');
                            sendEmail('( freedoge.co.in ) - Необходимо подтвердить email, чтобы продолжить сбор!');
							break;
						} else if ((window.content.document.getElementById('free_play_error').style.display !== 'none') && (window.content.document.getElementById('free_play_error').innerText.includes('blocked'))) {
							iimDisplay('Account of the https://freedoge.co.in/ has been banned...');
                            log('freedoge.co.in', 'Аккаунт забанен!');
                            sendEmail('( freedoge.co.in ) - Аккаунт забанен!');
							break;
						} else {
							iimDisplay('Captcha was solved incorrectly. Sending a report and trying to solve captcha again...');
							log('freedoge.co.in', 'Капча была решена неверно. Отправляем жалобу и пытаемся решить еще раз...');
                            if (answer['server'].includes('rucaptcha.com')) {
                                reportCaptcha(answer['server'], apiKey_ruCaptcha, answer['taskId']);
                            } else {
                                reportCaptcha(answer['server'], apiKey_XCaptcha, answer['taskId']);
                            }
							
							if (solvingCaptchaCycles == 5) {
								notificationsBadCaptcha('freedoge.co.in');
								break;
							}
							solvingCaptchaCycles++;
							continue;
						}
					}
				}
			}

			// https://freenem.com/ - - - - - >
			if (freeNEM === 'ON') {
				freeNemBody : {
					let authorizationCycles = 1;
					while (authorizationCycles <= 5) {
						iimDisplay('Connecting to the https://freenem.com/...');
						log('freenem.com', 'Подключение к проекту...');
						iimPlayCode('SET !TIMEOUT_PAGE 60'
								+n+ 'TAB T=1'
								+n+ 'TAB CLOSEALLOTHERS'
								+n+ 'URL GOTO=https://freenem.com/free'
								+n+ 'WAIT SECONDS=8');

						if (!window.content.document.getElementsByClassName('main-button-2 roll-button').length) {
							iimDisplay('Logging to the https://freenem.com/...');
							log('freenem.com', 'Авторизируемся на проекте...');
							iimPlayCode('SET !ERRORIGNORE YES'
									+n+ 'SET !TIMEOUT_PAGE 30'
									+n+ 'SET !TIMEOUT_STEP 10'
									+n+ 'TAG POS=1 TYPE=INPUT:EMAIL ATTR=NAME:email CONTENT=' + freeNEM_Login
									+n+ 'SET !ENCRYPTION NO'
									+n+ 'TAG POS=1 TYPE=INPUT:PASSWORD ATTR=NAME:password CONTENT=' + freeNEM_Password
									+n+ 'TAG POS=1 TYPE=BUTTON ATTR=TXT:LOGIN!'
									+n+ 'WAIT SECONDS=8');
							
							if (!window.content.document.getElementsByClassName('main-button-2 roll-button').length) {
								let data_sitekey = window.content.document.getElementsByTagName('iframe')[0].src.split('?k=')[1].split('&co=')[0];                                
                                let answer = (reCAPTCHA_freeNEM_ruCaptcha === 'ON') ? solveReCaptcha_ruCaptcha(data_sitekey, 'https://freenem.com/', 1) : solveReCaptcha_XCaptcha(data_sitekey, 'https://freenem.com/');
                                if (!answer['status']) {
                                    if (authorizationCycles == 5) {
                                        notificationsBadCaptcha('freenem.com');
                                        break freeNemBody;
                                    }
                                    authorizationCycles++;
                                    continue;
                                }

								iimPlayCode('SET !ERRORIGNORE YES'
										+n+ 'SET !TIMEOUT_PAGE 30'
										+n+ 'SET !TIMEOUT_STEP 10'
										+n+ 'TAG POS=1 TYPE=TEXTAREA FORM=ID:* ATTR=ID:g-recaptcha-response CONTENT=\"' + answer['hash'] + '\"'
										+n+ 'WAIT SECONDS=8');

								 if (!window.content.document.getElementsByClassName('main-button-2 roll-button').length) {
										iimDisplay('Captcha was solved incorrectly. Sending a report and trying to solve captcha again...');
										log('freenem.com', 'Капча была решена неверно. Отправляем жалобу и пытаемся решить еще раз...');
                                        if (answer['server'].includes('rucaptcha.com')) {
                                            reportCaptcha(answer['server'], apiKey_ruCaptcha, answer['taskId']);
                                        } else {
                                            reportCaptcha(answer['server'], apiKey_XCaptcha, answer['taskId']);
                                        }
										
										if (authorizationCycles == 5) {
											notificationsBadCaptcha('freenem.com');
											break freeNemBody;
										}
										authorizationCycles++;
										continue;
								}
								iimDisplay('Successful authorization...');
								log('freenem.com', 'Успешная авторизация...');
								break;
							}
						}
						break;
					}

					let timer = Number(window.content.document.getElementsByClassName('digits')[0].innerHTML * 60) + Number(window.content.document.getElementsByClassName('digits')[1].innerHTML);
					if (timer > 0)
						timeTillNextRoll('freenem.com', freeNEM_RandomTimer, timer);

					let solvingCaptchaCycles = 1;
					while (solvingCaptchaCycles <= 5) {
						iimDisplay('Refreshing page and solving reCAPTCHA v2...');
						log('freenem.com', 'Обновляем страницу и пытаемся решить Invisible reCAPTCHA v2...');
						iimPlayCode('SET !ERRORIGNORE YES'
								+n+ 'SET !TIMEOUT_PAGE 60'
								+n+ 'SET !TIMEOUT_STEP 10'
								+n+ 'TAB CLOSEALLOTHERS'
								+n+ 'TAB T=1'
								+n+ 'TAB CLOSE'
								+n+ 'URL GOTO=https://freenem.com/free'
                                +n+ 'WAIT SECONDS=8');
                                
                        timer = Number(window.content.document.getElementsByClassName('digits')[0].innerHTML * 60) + Number(window.content.document.getElementsByClassName('digits')[1].innerHTML);
                        if (timer > 0) {
							iimDisplay('There was an exception...');
							log('freenem.com', 'Произошел отлов исключительной ситуации...');
                            break freeNemBody;
                        }

                        iimPlayCode('SET !ERRORIGNORE YES'
                                +n+ 'SET !TIMEOUT_PAGE 60'
                                +n+ 'SET !TIMEOUT_STEP 10'
                                +n+ 'TAG POS=1 TYPE=BUTTON ATTR=TXT:ROLL!'
                                +n+ 'WAIT SECONDS=8');

						let winningDuringLastSession = Number(window.content.document.getElementsByClassName('result')[0].innerHTML.split(' ')[3]);
						if (!isNaN(winningDuringLastSession) || (winningDuringLastSession > 0)) {
							iimDisplay('Successfully claimed!');
							log('freenem.com', 'Успешный сбор! Собрано: ' + winningDuringLastSession + ' NEM');
							Winnings_freeNEM += winningDuringLastSession;
							break;
						} else {
							let data_sitekey = window.content.document.getElementsByTagName('iframe')[0].src.split('?k=')[1].split('&co=')[0];
                            let answer = (reCAPTCHA_freeNEM_ruCaptcha === 'ON') ? solveReCaptcha_ruCaptcha(data_sitekey, 'https://freenem.com/', 1) : solveReCaptcha_XCaptcha(data_sitekey, 'https://freenem.com/');
                            if (!answer['status']) {
                                if (authorizationCycles == 5) {
                                    notificationsBadCaptcha('freenem.com');
                                    break freeNemBody;
                                }
                                authorizationCycles++;
                                continue;
                            }

							iimDisplay('Claiming NEM...');
							log('freenem.com', 'Собираем NEM...');
							iimPlayCode('SET !ERRORIGNORE YES'
									+n+ 'SET !TIMEOUT_PAGE 30'
									+n+ 'SET !TIMEOUT_STEP 10'
									+n+ 'WAIT SECONDS=2.5'
									+n+ 'TAG POS=1 TYPE=TEXTAREA FORM=ID:* ATTR=ID:g-recaptcha-response CONTENT=\"' + answer['hash'] + '\"'
									+n+ 'ONDIALOG POS=1 BUTTON=OK CONTENT='
									+n+ 'WAIT SECONDS=8');
								
							winningDuringLastSession = Number(window.content.document.getElementsByClassName('result')[0].innerHTML.split(' ')[3]);
							if (!isNaN(winningDuringLastSession) || (winningDuringLastSession > 0)) {
								iimDisplay('Successfully claimed!');
								log('freenem.com', 'Успешный сбор! Собрано: ' + winningDuringLastSession + ' NEM');
								Winnings_freeNEM += winningDuringLastSession;
								break;
							} else {
								iimDisplay('Captcha was solved incorrectly. Sending a report and trying to solve captcha again...');
								log('freenem.com', 'Капча была решена неверно. Отправляем жалобу и пытаемся решить еще раз...');
                                if (answer['server'].includes('rucaptcha.com')) {
                                    reportCaptcha(answer['server'], apiKey_ruCaptcha, answer['taskId']);
                                } else {
                                    reportCaptcha(answer['server'], apiKey_XCaptcha, answer['taskId']);
                                }
								if (solvingCaptchaCycles == 5) {
									notificationsBadCaptcha('freenem.com');
									break;
								}
								solvingCaptchaCycles++;
								continue;
							}
						}
					}
				}
            }
		}
	}
	catch (e) {
	 	log('RESTART', 'Произошла ошибка в работе бота, проверьте подключение к интернету! Бот будет перезапущен через 30 секунд...');
        iimDisplay('There was an error in the bot operation, check the connection to the Internet! The bot will be restarted in 30 seconds...');
         
        let errorMessage = 'Произошла ошибка в работе, проверьте подключение к интернету! Я перезапущусь через 30 секунд :)';
		iimPlayCode('SET !ERRORIGNORE YES'
				+n+ 'SET !TIMEOUT_PAGE 60'
				+n+ 'SET !TIMEOUT_STEP 1'
				+n+ 'TAB CLOSEALLOTHERS'
				+n+ 'TAB T=1'
				+n+ 'URL GOTO=http://multicaptchabot.siteme.org/contacts.php'
				+n+ 'TAG POS=1 TYPE=INPUT:EMAIL FORM=ID:feedback-form ATTR=ID:email CONTENT=\"' + mail + '\"'
				+n+ 'TAG POS=1 TYPE=TEXTAREA FORM=ID:feedback-form ATTR=ID:message CONTENT=\"' + errorMessage + '\"'
				+n+ 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ID:feedback-form ATTR=*'
				+n+ 'TAB CLOSE'
				+n+ 'WAIT SECONDS=30');
	}
}