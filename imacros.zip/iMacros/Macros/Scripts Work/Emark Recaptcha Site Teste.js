﻿var t1='SET !ERRORIGNORE YES\nSET !TIMEOUT 30\n';
var faucetOn = new Array();
var t0='SET !TIMEOUT_STEP 0\n';
var pp = 0; 
var prob = 10;
var dirData = 'adms1';

faucetOn['log'] = 1440;
faucetOn['emark']=5;

//=========================================================================================================================

//---------> NÃO ALTERE NADA NO CÓDIGO ABAIXO.
// CADA SITE TEM A SUA API E DEVERÁ SER CAPTURADA ANTES DA EXECUÇÃO DO SCRIPT
// API INTERNA DO SITE EM QUESTÃO
var datasitekey = '6LeWECIUAAAAAPUs3rHlm8oNNB0Mbi-6UKGZmUkw';
                
//BOTÃO QUE DARÁ O CLAIM FINAL
var ENVIAR="TAG POS=1 TYPE=INPUT:SUBMIT FORM=ACTION:* ATTR=*";
//------> URL DA PÁGINA
var pageurl = 'https://emark.space/emark-faucet/';

//=========================================================================================================================

var Tabs = {
	_browser: function () {
		var wm = Components.classes["@mozilla.org/appshell/window-mediator;1"]
			.getService(Components.interfaces.nsIWindowMediator);
		return wm.getMostRecentWindow("navigator:browser").gBrowser;
	}(),
	go: function (tabIndex) {
		this._browser.selectedTab = this._browser.tabContainer.childNodes[tabIndex - 1];
	}
};

var loadFile = function (fileName) {
   var fileDescriptor = imns.FIO.openNode(fileName);
   var text = imns.FIO.readTextFile(fileDescriptor);
   return {
       text: text,
       strings: text.replace(/ /gi, "").split("\r\n")
    };
};

var appendToFile = function (fileName, text) {
   var fileDescriptor = imns.FIO.openNode(fileName);
   imns.FIO.appendTextFile(fileDescriptor, text);
}

var n = '\n';

function log(feler){
   var timer=getDate();
   txt=feler+'    '+timer; 
   iimPlayCode('SET !EXTRACT '+txt.replace(/ /gi,"<SP>") + ' \nSAVEAS TYPE=EXTRACT  FOLDER=C:\\' + dirData + '\\ FILE=log.txt');}

 function getDate(){var d=new Date(); return d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();}  
   
function weitrandom(){	
    var randomNumber = Math.floor(Math.random()*240 + 120); 
    iimDisplay('esperando por ' + randomNumber + ' segundos');
	iimPlayCode('WAIT SECONDS='+randomNumber);	
	} 
	
function milisec() {
    return new Date().getTime()
}

function closeAllOthers() {
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'TAB CLOSEALLOTHERS' + n;
    iimPlay(code, 60)
}
function getTimerSite() {
    var t = new Array();
    var str = '';
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'SET !DATASOURCE C:\\' + dirData + '\\timer2.csv' + n;
    code += 'SET !DATASOURCE_LINE 1' + n;
    code += 'SET !EXTRACT NULL ' + n;
    code += 'SET !VAR1 {{!COL1}}' + n;
    code += 'ADD !EXTRACT {{!VAR1}}' + n;
    iimPlay(code, 60);
    str = iimGetLastExtract();
    return str.split('|')
}

function updateTimer(t, i, min) {
    var str = '';
    var nowtime = milisec();
    msec = min * 60 * 1000;
    t[i] = nowtime + msec;
    nextsbor[i] = t[i];
    str = t.join('|');
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'SET !EXTRACT NULL' + n;
    code += 'ADD !EXTRACT ' + str + n;
    code += 'FILEDELETE NAME=C:\\' + dirData + '\\timer2.csv ' + n;
    code += 'SAVEAS TYPE=EXTRACT FOLDER=C:\\' + dirData + '\\ FILE=timer2.csv ' + n;
    iimPlay(code, 60)
}

function updateWaitTimer2() {
    var waitSecond = 999999;
    var t = nextsbor;
    var nowMilisec = milisec();
    var strUpFile = '';
    var strUpFile_light = '';
    timeToCountDown = '';
    var header = '&quot;<link href=\'bootstrap/css/bootstrap.min.css\' rel=\'stylesheet\' media=\'screen\'><link href=\'bootstrap/css/bootstrap-responsive.min.css\' rel=\'stylesheet\' media=\'screen\'><link href=\'vendors/easypiechart/jquery.easy-pie-chart.css\' rel=\'stylesheet\' media=\'screen\'><link href=\'assets/styles.css\' rel=\'stylesheet\' media=\'screen\'>';
    var table = '';
    var i = 0;
    table += '<div class=\'block\'><div class=\'navbar navbar-inner block-header\'><div class=\'muted pull-left\'>Bem Vindo</div></div><div class=\'block-content collapse in\'><div class=\'span12\'><table class=\'table table-condensed\'><thead><tr><th></th><th>Site</th><th>Contador</th><th>Tempo</th></tr></thead><tbody>';
    for (var key in faucetOn) {
        i++;
        if (faucetOn[key] > 0) {
            var countdownSec = parseInt((t[i] - nowMilisec) / 1000);
            if (countdownSec < 3) {
                countdownSec = 3
            }
            if (countdownSec < waitSecond) {
                nextSite = key;
                waitSecond = countdownSec
            }
            table += '<tr><td>' + i + '</td><td>' + key + '</td><td class=\'ttimer\'>' + countdownSec + '</td><td><span class=\'badge badge-info\'>' + faucetOn[key] + '</span></td></tr>'
        } else {
            table += '<tr><td>' + i + '</td><td>' + key + '</td><td>OFF</td><td></td></tr>'
        }
    }
    table += '</tbody></table></div></div></div>';
    var footer = '<script src=\'vendors/jquery-1.9.1.min.js\'></script><script src=\'bootstrap/js/bootstrap.min.js\'></script><script src=\'vendors/easypiechart/jquery.easy-pie-chart.js\'></script><script src=\'js/fn.js\'></script><script>$(timerTable());</script>';
    var dopdata = '<span class=\'badge badge-warning \'>Next: ' + nextSite + '</span><span class=\'badge badge-success ttimer\'> ' + waitSecond + '</span><span class=\'badge badge-info pull-right\'><i class=\'icon-tag\'></i>PAZ</span> ';
    strUpFile += header + dopdata + table + footer + '&quot;';
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'FILEDELETE NAME=C:\\' + dirData + '\\site_table.html ' + n;
    code += 'SET !EXTRACT NULL' + n;
    code += 'ADD !EXTRACT {{STRFILE}}' + n;
    code += 'SAVEAS TYPE=EXTRACT FOLDER=C:\\' + dirData + ' FILE=site_table.html ' + n;
    code += 'TAB T=1' + n;
    code += 'URL GOTO=file:///C:/' + dirData + '/wait.html' + n;
    code += 'WAIT SECONDS=' + waitSecond + n;
    iimSet("STRFILE", strUpFile);
    iimPlay(code, 60)
}

function getFaucetIndex(){
    var t = new Array();
    var i =0;
    for (var key in faucetOn) {
        i++;
        t[i]= key;
    }
    return t
}

function Faucet_emark(pp){
if(pp>prob) return;

var macro = "CODE:";
macro += "SET !EXTRACT_TEST_POPUP NO" + "\n";
macro += "SET !ERRORIGNORE YES" + "\n";
macro += "SET !TIMEOUT_PAGE 350" + "\n";
macro += "SET !EXTRACT NULL" + "\n";
macro += "SET !TIMEOUT_STEP 0" + "\n";
macro += "URL GOTO=https://emark.space/emark-faucet/\n";
macro += 'URL GOTO=javascript:(function(){var<SP>x<SP>=<SP>document.getElementById("g-recaptcha-response");x.style.display<SP>=<SP>"";})();' + "\n";
macro += "TAB OPEN" + "\n";
macro += "TAB T=2" + "\n";
macro += "URL GOTO=http://23.249.176.210/in.php?method=userrecaptcha&googlekey="+datasitekey+"&pageurl="+pageurl+" "+ "\n";
macro += "WAIT SECONDS=2" + "\n";
//macro += 'PAUSE' + "\n";
macro += "TAG POS=1 TYPE=* ATTR=TXT:* EXTRACT=TXT" + "\n";
macro += "SET captid EVAL(\"var s=\\\"{{!EXTRACT}}\\\"; s.split(' ')[0].split('|')[1]\")" + "\n";
macro += "SET !EXTRACT NULL" + "\n";
macro += "URL GOTO= http://23.249.176.210/res.php?action=get&id={{captid}}" + "\n";
var macro2 = "CODE:";
macro2 += "TAG POS=1 TYPE=* ATTR=TXT:* EXTRACT=TXT" + "\n";

var macro3 = "CODE:";
//macro3 += "TAG POS=1 TYPE=TEXTAREA ATTR=TXT:* EXTRACT=TXT" + "\n";
macro3 += "TAG POS=1 TYPE=* ATTR=TXT:* EXTRACT=TXT" + "\n";
macro3 += "SET answer {{!EXTRACT}}" + "\n";
macro3 += "TAB CLOSE" + "\n";
macro3 += "WAIT SECONDS=0.3" + "\n";
macro3 += "TAG POS=1 TYPE=TEXTAREA FORM=ACTION://emark.space/emark-faucet/ ATTR=ID:g-recaptcha-response CONTENT={{!EXTRACT}}" + "\n";
macro3 += "WAIT SECONDS = 2" + "\n";
macro3 += 'PAUSE' + "\n";
macro3 += ENVIAR + "\n";
macro3 += "WAIT SECONDS=10" + "\n";

iimPlay(macro);
iimPlay(macro2);

var answer=iimGetLastExtract().trim();
while(answer=="CAPCHA_NOT_READY")
{
iimPlay("CODE:WAIT SECONDS=5");
iimPlay("CODE:REFRESH");
iimPlay(macro2);
var answer=iimGetLastExtract().trim();
}

iimPlay(macro3);

}
//========================================== GET-SAVE-REPORT-CAPTCHA ===============================================

function runFaucet(facetName){

    switch (facetName) {
		case 'emark':
    Faucet_emark();
    break;
    }
}

var col = 40;
var nextsbor = new Array();

nextsbor = getTimerSite();
while (100 > 0) {
    var msec = milisec();
    var i = 0;

    for (var key in faucetOn) {
        i++;
        if (nextsbor[i]< msec && faucetOn[key] > 0){
            runFaucet(key);
            updateTimer(nextsbor, i, faucetOn[key]);
        }
    }
  closeAllOthers();
  updateWaitTimer2();       
    }
function weit(s) {iimPlayCode("WAIT SECONDS=" + s);}