﻿//=====================//

// ele irar trabalhar com 10 frames, entao rode uma unica vez e veja o tempo que e gasto na barra da coinhive




var claim='1';   // coloque a quantidade de vezes que o seu script irar rodar
var tempo='30';    // coloque o tempo que o seu pc irar gastar na barra da coinhive
var btc= '158fRAFW2c6TpHHY9123BFPZEdqWL19aTm'; // CARTEIRA DE LITECOIN
var ltc = 'LV1Y1Rc8unjLypbzjadcqts8ovFhQn1DPp'; // CARTEIRA DE LITECOIN
var doge = 'DKgCqd5Gw3gPo4mTHTvLVUwJYLVKDmoAiM'; // CARTEIRA DE DOGECOIN
var blk = 'B7b91S9dt5xMND4RKgdyVJZPSdufCqZWci'; // CARTEIRA DE BLACKCOIN


//=====================//

for (var i = 0; i < + claim + ''; i++) { 
darakLTC();
darakBLK();
darakDOGE();
}

var limpar = '';
limpar +=  'CLEAR' + n;
iimPlay(limpar, 60);

function darakLTC(pp) {
     
    iimPlayCode('CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n');
       iimPlayCode('CLEAR'); weit(.75);
        iimPlayCode('http://darak.me/ltc/?cc=CoinHive&r=LP2YM24t4AQ3QyyJjmG42TbNuKPKDRnhZH');
		iimPlayCode ('WAIT SECONDS=1');
      	iimPlayCode('TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:NoFormName ATTR=NAME:* CONTENT=' + ltc+ '');
		iimPlayCode ('WAIT SECONDS=0.5');
        iimPlayCode('TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:NoFormName ATTR=*');
		iimPlayCode ('WAIT SECONDS=1');
		iimPlayCode ('TAG POS=1 TYPE=A ATTR=TXT:Claim');
        iimPlayCode('WAIT SECONDS=1');
		iimPlayCode ('TAG POS=1 TYPE=A ATTR=TXT:Skip<SP>Ad');
    	iimPlayCode('SET !TIMEOUT_TAG 150 \n TAG POS=1 TYPE=IMG ATTR=SRC:* \n SET !TIMEOUT_TAG 6');
		iimPlayCode('SET !TIMEOUT_TAG 150 \n TAG POS=1 TYPE=IMG ATTR=ID:showlink \n SET !TIMEOUT_TAG 6');
		iimPlayCode('TAB CLOSEALLOTHERS');
		iimPlayCode ('WAIT SECONDS=1');
				
		solve();
		
		iimPlayCode ('WAIT SECONDS='+ tempo + '');
		iimPlayCode('FRAME F=0 \nTAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:NoFormName ATTR=*');
		iimPlayCode ('WAIT SECONDS=2');
		
}
function darakBLK(pp) {
     
    iimPlayCode('CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n');
       iimPlayCode('CLEAR'); weit(.75);
        iimPlayCode('URL GOTO=http://darak.me/blk/?cc=CoinHive&r=BFg1VQzgkLpn7du4saAoXE23v4Q26Aagmy');
		iimPlayCode ('WAIT SECONDS=1');
      	iimPlayCode('TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:NoFormName ATTR=NAME:* CONTENT=' + blk+ '');
		iimPlayCode ('WAIT SECONDS=0.5');
        iimPlayCode('TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:NoFormName ATTR=*');
		iimPlayCode ('WAIT SECONDS=1');
		iimPlayCode ('TAG POS=1 TYPE=A ATTR=TXT:Claim');
        iimPlayCode('WAIT SECONDS=1');
		iimPlayCode ('TAG POS=1 TYPE=A ATTR=TXT:Skip<SP>Ad');
    	//iimPlayCode('SET !TIMEOUT_TAG 150 \n TAG POS=1 TYPE=IMG ATTR=SRC:* \n SET !TIMEOUT_TAG 6');
		//iimPlayCode('SET !TIMEOUT_TAG 150 \n TAG POS=1 TYPE=IMG ATTR=ID:showlink \n SET !TIMEOUT_TAG 6');
		iimPlayCode('TAB CLOSEALLOTHERS');
		iimPlayCode ('WAIT SECONDS=1');
				
		solve();
		
		iimPlayCode ('WAIT SECONDS='+ tempo + '');
		iimPlayCode('FRAME F=0 \nTAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:NoFormName ATTR=*');
		iimPlayCode ('WAIT SECONDS=2');
		
}
function darakDOGE(pp) {
     
    iimPlayCode('CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n');
       iimPlayCode('CLEAR'); weit(.75);
        iimPlayCode('URL GOTO=http://darak.me/doge/?cc=CoinHive&r=?r=DPc4gK1mBJsajmu7wfb3XQHvrRqvod2KM7');
		iimPlayCode ('WAIT SECONDS=1');
      	iimPlayCode('TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:NoFormName ATTR=NAME:* CONTENT=' + doge+ '');
		iimPlayCode ('WAIT SECONDS=0.5');
        iimPlayCode('TAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:NoFormName ATTR=*');
		iimPlayCode ('WAIT SECONDS=1');
		iimPlayCode ('TAG POS=1 TYPE=A ATTR=TXT:Claim');
        iimPlayCode('WAIT SECONDS=1');
		iimPlayCode ('TAG POS=1 TYPE=A ATTR=TXT:Skip<SP>Ad');
    	iimPlayCode('SET !TIMEOUT_TAG 150 \n TAG POS=1 TYPE=IMG ATTR=SRC:* \n SET !TIMEOUT_TAG 6');
		iimPlayCode('SET !TIMEOUT_TAG 150 \n TAG POS=1 TYPE=IMG ATTR=ID:showlink \n SET !TIMEOUT_TAG 6');
		iimPlayCode('TAB CLOSEALLOTHERS');
		iimPlayCode ('WAIT SECONDS=1');
				
		solve();
		
		iimPlayCode ('WAIT SECONDS='+ tempo + '');
		iimPlayCode('FRAME F=0 \nTAG POS=1 TYPE=INPUT:SUBMIT FORM=NAME:NoFormName ATTR=*');
		iimPlayCode ('WAIT SECONDS=2');
		
}
function solve() {
   	  var ifremesCount = window.length;   
   for(w=1; w<=10; w++)
	    iimPlayCode('FRAME F='+w+'\nTAG POS=1 TYPE=DIV ATTR=ID:verify-me');
        
   }

//========================================================
function weit(s) {iimPlay("WAIT SECONDS=" + s);}