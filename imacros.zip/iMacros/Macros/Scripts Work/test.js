﻿var faucetOn = new Array();
var keyApi = new Array();

var ligar2captcha = 0  // Opção para ligar e desligar o 2captcha -> 1 = On 0 = Off.

var n = '\n';
var pp = 0; 
var prob = 10;
var dirData = 'adms1';
keyApi['Rucaptcha'] = 'apikey'; // INSIRA SUA API 2captcha/Rucaptcha

faucetOn['log'] = 480;
faucetOn['bagdoge']=5;

var doge = 'DPc4gK1mBJsajmu7wfb3XQHvrRqvod2KM7'; // CARTEIRA DE DOGECOIN

//=========================================================================================================================

var Tabs = {
	_browser: function () {
		var wm = Components.classes['@mozilla.org/appshell/window-mediator;1']
			.getService(Components.interfaces.nsIWindowMediator);
		return wm.getMostRecentWindow('navigator:browser').gBrowser;
	}(),
	go: function (tabIndex) {
		this._browser.selectedTab = this._browser.tabContainer.childNodes[tabIndex - 1];
	}
};

var loadFile = function (fileName) {
   var fileDescriptor = imns.FIO.openNode(fileName);
   var text = imns.FIO.readTextFile(fileDescriptor);
   return {
       text: text,
       strings: text.replace(/ /gi, '').split('\r\n')
    };
};

var appendToFile = function (fileName, text) {
   var fileDescriptor = imns.FIO.openNode(fileName);
   imns.FIO.appendTextFile(fileDescriptor, text);
}

//=========================================================================================================================

function log(feler){
   var timer=getDate();
   txt=feler+'    '+timer; 
   iimPlayCode('SET !EXTRACT '+txt.replace(/ /gi,'<SP>') + ' \nSAVEAS TYPE=EXTRACT  FOLDER=C:\\' + dirData + '\\ FILE=log.txt');}

 function getDate(){var d=new Date(); return d.getHours()+':'+d.getMinutes()+':'+d.getSeconds();}  
   
function weitrandom(){	
    var randomNumber = Math.floor(Math.random()*240 + 120); 
    iimDisplay('esperando por ' + randomNumber + ' segundos');
	iimPlayCode('WAIT SECONDS='+randomNumber);	
	} 
	
function milisec() {
    return new Date().getTime()
}

function closeAllOthers() {
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'TAB CLOSEALLOTHERS' + n;
    iimPlay(code, 60)
}
function getTimerSite() {
    var t = new Array();
    var str = '';
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'SET !DATASOURCE C:\\' + dirData + '\\timer2.csv' + n;
    code += 'SET !DATASOURCE_LINE 1' + n;
    code += 'SET !EXTRACT NULL ' + n;
    code += 'SET !VAR1 {{!COL1}}' + n;
    code += 'ADD !EXTRACT {{!VAR1}}' + n;
    iimPlay(code, 60);
    str = iimGetLastExtract();
    return str.split('|')
}

function updateTimer(t, i, min) {
    var str = '';
    var nowtime = milisec();
    msec = min * 60 * 1000;
    t[i] = nowtime + msec;
    nextsbor[i] = t[i];
    str = t.join('|');
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'SET !EXTRACT NULL' + n;
    code += 'ADD !EXTRACT ' + str + n;
    code += 'FILEDELETE NAME=C:\\' + dirData + '\\timer2.csv ' + n;
    code += 'SAVEAS TYPE=EXTRACT FOLDER=C:\\' + dirData + '\\ FILE=timer2.csv ' + n;
    iimPlay(code, 60)
}

function resoluçãodecaptcha() {
	var strUpFile = '';
    var strUpFile_light = '';
    var header = '&quot;<link rel=\'stylesheet\' href=\'prompt/bootstrap.min.css\' /><link rel=\'stylesheet\' href=\'style.css\' />';
    var table = '';
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'SET !EXTRACT NULL' + n;
    code += 'ADD !EXTRACT {{STRFILE}}' + n;
    code += 'SAVEAS TYPE=EXTRACT FOLDER=C:\\' + dirData + ' FILE=prompt.html ' + n;
    code += 'TAB T=1' + n;
    code += 'URL GOTO=file:///C:/' + dirData + '/prompt.html' + n;
    iimSet('STRFILE', strUpFile);
    iimPlay(code, 60)
}

function updateWaitTimer2() {
    var waitSecond = 999999;
    var t = nextsbor;
    var nowMilisec = milisec();
    var strUpFile = '';
    var strUpFile_light = '';
    timeToCountDown = '';
    var header = '&quot;<link href=\'bootstrap/css/bootstrap.min.css\' rel=\'stylesheet\' media=\'screen\'><link href=\'bootstrap/css/bootstrap-responsive.min.css\' rel=\'stylesheet\' media=\'screen\'><link href=\'vendors/easypiechart/jquery.easy-pie-chart.css\' rel=\'stylesheet\' media=\'screen\'><link href=\'assets/styles.css\' rel=\'stylesheet\' media=\'screen\'>';
    var table = '';
    var i = 0;
    table += '<div class=\'block\'><div class=\'navbar navbar-inner block-header\'><div class=\'muted pull-left\'>Seja Bem Vindo</div></div><div class=\'block-content collapse in\'><div class=\'span12\'><table class=\'table table-condensed\'><thead><tr><th></th><th>Nome do Site</th><th>Tempo Restante</th><th>Tempo da Faucet</th></tr></thead><tbody>';
    for (var key in faucetOn) {
        i++;
        if (faucetOn[key] > 0) {
            var countdownSec = parseInt((t[i] - nowMilisec) / 1000);
            if (countdownSec < 3) {
                countdownSec = 3
            }
            if (countdownSec < waitSecond) {
                nextSite = key;
                waitSecond = countdownSec
            }
            table += '<tr><td>' + i + '</td><td>' + key + '</td><td class=\'ttimer\'>' + countdownSec + '</td><td><span class=\'badge badge-info\'>' + faucetOn[key] + '</span></td></tr>'
        } else {
            table += '<tr><td>' + i + '</td><td>' + key + '</td><td>OFF</td><td></td></tr>'
        }
    }
    table += '</tbody></table></div></div></div>';
    var footer = '<script src=\'vendors/jquery-1.9.1.min.js\'></script><script src=\'bootstrap/js/bootstrap.min.js\'></script><script src=\'vendors/easypiechart/jquery.easy-pie-chart.js\'></script><script src=\'js/fn.js\'></script><script>$(timerTable());</script>';
    var dopdata = '<span class=\'badge badge-warning \'>Next: ' + nextSite + '</span><span class=\'badge badge-success ttimer\'> ' + waitSecond + '</span><span class=\'badge badge-info pull-right\'><i class=\'icon-tag\'></i>PAz a Todos</span> ';
    strUpFile += header + dopdata + table + footer + '&quot;';
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'FILEDELETE NAME=C:\\' + dirData + '\\site_table.html ' + n;
    code += 'SET !EXTRACT NULL' + n;
    code += 'ADD !EXTRACT {{STRFILE}}' + n;
    code += 'SAVEAS TYPE=EXTRACT FOLDER=C:\\' + dirData + ' FILE=site_table.html ' + n;
    code += 'TAB T=1' + n;
    code += 'URL GOTO=file:///C:/' + dirData + '/wait.html' + n;
    code += 'WAIT SECONDS=' + waitSecond + n;
    iimSet('STRFILE', strUpFile);
    iimPlay(code, 60)
}

function getFaucetIndex(){
    var t = new Array();
    var i =0;
    for (var key in faucetOn) {
        i++;
        t[i]= key;
    }
    return t
}

//=========================================================================================================================

function bagdoge(pp){
	if(pp>prob) return;
	
	resoluçãodecaptcha();

	var file ='bagdoge.png';
	var code='';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'PAUSE' + n;
	code += 'URL GOTO=https://bagi.co.in/dogecoin/' + n;
	code += 'WAIT SECONDS=1' + n;
	code += 'TAG POS=1 TYPE=BUTTON FORM=ACTION:captha.php ATTR=TXT:NEXT' + n;
	code += 'WAIT SECONDS=2' + n;
	code += 'TAG POS=2 TYPE=BUTTON FORM=ACTION:index.php?Claim=doge ATTR=ID:submit' + n;
	code += 'WAIT SECONDS=2' + n;
	code += 'TAG POS=1 TYPE=BUTTON FORM=ACTION:index.php?Claim=doge ATTR=ID:submit' + n;
	code += 'WAIT SECONDS=2' + n;
	iimPlay(code, 60);

	if (Number(ligar2captcha)>=1) {

		SaveCaptcha(file);
	    var str = GetRucaptcha(file, keyApi['Rucaptcha']);
	  	var cText = str['c_text'];
	  	var captha = cText.replace(/\s/g, '<SP>');
	  	
	  	iimDisplay(captha);
	    if (cText == undefined){
	        reportcaptcha(pp + 1);bagdoge(pp + 1);
	        return;
	    }

	    var captha = cText.replace(/\s/g, '<SP>');
	    iimDisplay(captha);
	    if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {reportcaptcha(pp + 1);bagdoge(pp + 1);return}
	}

    iimPlayCode(`
    PAUSE
    SET !ERRORIGNORE YES
    SET !TIMEOUT_STEP 0
    TAG POS=1 TYPE=INPUT:TEXT ATTR=NAME:adcopy_response CONTENT=${captha}
    WAIT SECONDS=0.5
    TAG POS=2 TYPE=BUTTON FORM=ACTION:index.php?Claim=doge ATTR=TXT:Claim<SP>DogeCoin!
    FILEDELETE NAME=C:\\${dirData}\\${file}
    `);

	iimPlay('CODE:SET !TIMEOUT_STEP 1\nTAG POS=1 TYPE=DIV ATTR=TXT:Captcha<SP>is<SP>wrong.<SP>Try<SP>again. EXTRACT=TXT');
	err = iimGetLastExtract();
	if (err != '' && err != '#EANF#') { 
	reportcaptcha(pp + 1);bagdoge(pp + 1);return;} 
		
	iimPlay('CODE:SET !TIMEOUT 1\nTAG POS=1 TYPE=DIV ATTR=TXT:*<SP>claimed<SP>successfully<SP>*<SP>Satoshi* EXTRACT=TXT');
	win=iimGetLastExtract();
	if(win == '#EANF#') {return;}
}

//=========================================================================================================================
//=========================================================================================================================

function SaveCaptcha(file_name) {
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'SET !ENCRYPTION NO' + n;
    code += 'WAIT SECONDS=0.5' + n;
    code += 'ONDOWNLOAD FOLDER=C:\\' + dirData + '\\ FILE=' + file_name + ' WAIT=YES' + n;
	code += 'WAIT SECONDS=0.5' + n;
	code += 'TAG POS=1 TYPE=IMG ATTR=ID:adcopy-puzzle-image-image CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
	iimPlay(code, 60)
}

function GetRucaptcha(file_name, apikey) {
    var result = new Array();
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB OPEN' + n;
    code += 'TAB T=2' + n;
    code += 'URL GOTO=file:///C:/' + dirData + '/form_api_rucaptcha.html' + n;
    code += 'TAG POS=1 TYPE=INPUT:TEXT ATTR=NAME:key&&SIZE:64 CONTENT=' + apikey + n;
    code += 'TAG POS=1 TYPE=INPUT:FILE ATTR=TYPE:file&&NAME:file&&SIZE:20 CONTENT=C:\\' + dirData + '\\' + file_name + n;
    if (file_name == 'calc.png') {
        code += 'TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ACTION:* ATTR=NAME:calc CONTENT=YES' + n
    }
    code += 'TAG POS=1 TYPE=INPUT:SUBMIT ATTR=TYPE:submit&&VALUE:recognize' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=BODY ATTR=TXT:* EXTRACT=TXT' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAB CLOSE' + n;
    iimPlay(code, 120);
    var str = iimGetLastExtract();
    var capthId = str.replace('OK|', '');
    switch (capthId) {
        case'ERROR_NO_SLOT_AVAILABLE':
            var code = '';
            code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
            code += 'TAB T=1' + n;
            code += 'WAIT SECONDS=10' + n;
            return GetRucaptcha(file_name, apikey);
            break;
        default:
            result['c_text'] = GetRucaptchaTEXT(capthId, apikey, file_name, pp);
            result['c_id'] = capthId
    }
    return result
}

function GetRucaptchaTEXT(capthId, apikey, file_name, pp) {
    if(pp > prob) {
    iimDisplay('Captcha Errado - Tentando Novamente');}
    else{
    var result = 'ERROR';
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB OPEN' + n;
    code += 'TAB T=2' + n;
    code += 'URL GOTO=http://rucaptcha.com/res.php?key=' + apikey + '&action=get&id=' + capthId + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=BODY ATTR=TXT:* EXTRACT=TXT' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAB CLOSE' + n;
    iimPlay(code, 60);
    var str = iimGetLastExtract();
    var capth = str.replace('OK|', '');
    switch (capth) {
        case'CAPCHA_NOT_READY':
            var code = '';
            code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
            code += 'TAB T=1' + n;
            code += 'WAIT SECONDS=10' + n;
            iimPlay(code, 60);
            result = GetRucaptchaTEXT(capthId, apikey, file_name, (pp + 1));
            break;
        case'ERROR_KEY_DOES_NOT_EXIST':
            return result = 'ERROR';
            break;
        case'ERROR_WRONG_ID_FORMAT':
            return result = 'ERROR';
            break;
        case'ERROR_WRONG_CAPTCHA_ID':
            return result = 'ERROR';
            break;
        case'ERROR_CAPTCHA_UNSOLVABLE':
            return result = 'ERROR_CAPTCHA_UNSOLVABLE';
            break;
        default:
            var result = capth
    }
    return result}
}

function reportRucaptcha(apikey, capthId) {
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB OPEN' + n;
    code += 'TAB T=2' + n;
    code += 'URL GOTO=http://rucaptcha.com/res.php?key=' + apikey + '&action=reportbad&id=' + capthId + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAB CLOSE' + n;
    iimPlay(code, 60)
}

function runFaucet(facetName){

    switch (facetName) {
    case 'bagdoge':
    	bagdoge();
    break;
	}
}

var col = 40;
var nextsbor = new Array();

nextsbor = getTimerSite();
while (100 > 0) {
    var msec = milisec();
    var i = 0;

    for (var key in faucetOn) {
        i++;
        if (nextsbor[i]< msec && faucetOn[key] > 0){
            runFaucet(key);
            updateTimer(nextsbor, i, faucetOn[key]);
        }
    }
  closeAllOthers();
  updateWaitTimer2();       
    }