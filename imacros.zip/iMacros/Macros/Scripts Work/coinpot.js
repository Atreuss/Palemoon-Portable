var t1='SET !ERRORIGNORE YES\nSET !TIMEOUT 30\n';
var er='SET !ERRORIGNORE YES\n', strings=""
var keyApi = new Array();
var faucetOn = new Array();
var pp = 0; 
var prob = 1;
var n = '\n'; 
var Cc=Components.classes, Ci=Components.interfaces, Path='C:\\CapNum\\solve\\';
var proc=Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
var file=Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsILocalFile);
var cok=Cc["@mozilla.org/cookiemanager;1"].getService(Ci.nsICookieManager);
var prf=Cc["@mozilla.org/preferences-service;1"].getService(Ci.nsIPrefBranch);
var str=Cc["@mozilla.org/supports-string;1"].createInstance(Ci.nsISupportsString);
var alt=Cc["@mozilla.org/embedcomp/prompt-service;1"].getService(Ci.nsIPromptService);
var iP=iimPlayCode, iD=iimDisplay, t0='SET !TIMEOUT_STEP 0\n', t3='SET !ERRORIGNORE YES\nSET !TIMEOUT 60\n';
var kap="javascript:document.write('<b><h1>ResoluÃƒÂ§ÃƒÂ£o</h1></b>');window.stop();"; 
t = '', txt = '', w = 0, i = 0;

var dirData = 'Bitfun';
//keyApi['solutions'] = 'xxxxxxxxxxxxxxxxxxxxxx'; // INSIRA SUA KEY CAPTCHA SOLUTIONS
//keyApi['secret'] = 'xxxxxxxxxxxxxxxx'; // SECRET KEY CAPTCHA SOLUTIONS
var apikey = '5TKEIXHBMYFITV5VEG'; // INSIRA SUA API 9KW

faucetOn['log'] = 1440;
faucetOn['freedogcoin']=0;
faucetOn['moondash']=30;
faucetOn['moonbch']=30;
faucetOn['moonlct']=30;
faucetOn['moondoge']=30;
faucetOn['bonusbitcoin']=15;
faucetOn['bitfun']=30;

var Flash = 1;  // Opção para ligar e desligar o Captcha Flash -> 1 = On 0 = Off.  

var ligar9kw = 0; // Opção para ligar e desligar o 9KW -> 2 = On 0 = Off.

var CS = 0;  // Opção para ligar e desligar o CS -> 3 = On 0 = Off.


//=========================================================================================================================


var Tabs = {
	_browser: function () {
		var wm = Components.classes["@mozilla.org/appshell/window-mediator;1"]
			.getService(Components.interfaces.nsIWindowMediator);
		return wm.getMostRecentWindow("navigator:browser").gBrowser;
	}(),
	go: function (tabIndex) {
		this._browser.selectedTab = this._browser.tabContainer.childNodes[tabIndex - 1];
	}
};

var loadFile = function (fileName) {
   var fileDescriptor = imns.FIO.openNode(fileName);
   var text = imns.FIO.readTextFile(fileDescriptor);
   return {
       text: text,
       strings: text.replace(/ /gi, "").split("\r\n")
    };
};

var appendToFile = function (fileName, text) {
   var fileDescriptor = imns.FIO.openNode(fileName);
   imns.FIO.appendTextFile(fileDescriptor, text);
}

//=========================================================================================================================
//=========================================================================================================================

var n = '\n';

function log(feler){
   var timer=getDate();
   txt=feler+'    '+timer; 
   iimPlayCode('SET !EXTRACT '+txt.replace(/ /gi,"<SP>") + ' \nSAVEAS TYPE=EXTRACT  FOLDER=C:\\' + dirData + '\\ FILE=log.txt');}

 function getDate(){var d=new Date(); return d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();}  
   
function weitrandom(){	
    var randomNumber = Math.floor(Math.random()*240 + 120); 
    iimDisplay('esperando por ' + randomNumber + ' segundos');
	iimPlayCode('WAIT SECONDS='+randomNumber);	
	} 
	
function milisec() {
    return new Date().getTime()
}

function closeAllOthers() {
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'TAB CLOSEALLOTHERS' + n;
    iimPlay(code, 60)
}
function getTimerSite() {
    var t = new Array();
    var str = '';
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'SET !DATASOURCE C:\\' + dirData + '\\timer2.csv' + n;
    code += 'SET !DATASOURCE_LINE 1' + n;
    code += 'SET !EXTRACT NULL ' + n;
    code += 'SET !VAR1 {{!COL1}}' + n;
    code += 'ADD !EXTRACT {{!VAR1}}' + n;
    iimPlay(code, 60);
    str = iimGetLastExtract();
    return str.split('|')
}

function updateTimer(t, i, min) {
    var str = '';
    var nowtime = milisec();
    msec = min * 60 * 1000;
    t[i] = nowtime + msec;
    nextsbor[i] = t[i];
    str = t.join('|');
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'SET !EXTRACT NULL' + n;
    code += 'ADD !EXTRACT ' + str + n;
    code += 'FILEDELETE NAME=C:\\' + dirData + '\\timer2.csv ' + n;
    code += 'SAVEAS TYPE=EXTRACT FOLDER=C:\\' + dirData + '\\ FILE=timer2.csv ' + n;
    iimPlay(code, 60)
}

function updateWaitTimer2() {
    var waitSecond = 999999;
    var t = nextsbor;
    var nowMilisec = milisec();
    var strUpFile = '';
    var strUpFile_light = '';
    timeToCountDown = '';
    var header = '&quot;<link href=\'bootstrap/css/bootstrap.min.css\' rel=\'stylesheet\' media=\'screen\'><link href=\'bootstrap/css/bootstrap-responsive.min.css\' rel=\'stylesheet\' media=\'screen\'><link href=\'vendors/easypiechart/jquery.easy-pie-chart.css\' rel=\'stylesheet\' media=\'screen\'><link href=\'assets/styles.css\' rel=\'stylesheet\' media=\'screen\'>';
    var table = '';
    var i = 0;
    table += '<div class=\'block\'><div class=\'navbar navbar-inner block-header\'><div class=\'muted pull-left\'>Seja Bem Vindo</div></div><div class=\'block-content collapse in\'><div class=\'span12\'><table class=\'table table-condensed\'><thead><tr><th></th><th>Nome do Site</th><th>Tempo Restante</th><th>Tempo da Faucet</th></tr></thead><tbody>';
    for (var key in faucetOn) {
        i++;
        if (faucetOn[key] > 0) {
            var countdownSec = parseInt((t[i] - nowMilisec) / 1000);
            if (countdownSec < 3) {
                countdownSec = 3
            }
            if (countdownSec < waitSecond) {
                nextSite = key;
                waitSecond = countdownSec
            }
            table += '<tr><td>' + i + '</td><td>' + key + '</td><td class=\'ttimer\'>' + countdownSec + '</td><td><span class=\'badge badge-info\'>' + faucetOn[key] + '</span></td></tr>'
        } else {
            table += '<tr><td>' + i + '</td><td>' + key + '</td><td>OFF</td><td></td></tr>'
        }
    }
    table += '</tbody></table></div></div></div>';
    var footer = '<script src=\'vendors/jquery-1.9.1.min.js\'></script><script src=\'bootstrap/js/bootstrap.min.js\'></script><script src=\'vendors/easypiechart/jquery.easy-pie-chart.js\'></script><script src=\'js/fn.js\'></script><script>$(timerTable());</script>';
    var dopdata = '<span class=\'badge badge-warning \'>Next: ' + nextSite + '</span><span class=\'badge badge-success ttimer\'> ' + waitSecond + '</span><span class=\'badge badge-info pull-right\'><i class=\'icon-tag\'></i>PAz a Todos</span> ';
    strUpFile += header + dopdata + table + footer + '&quot;';
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'FILEDELETE NAME=C:\\' + dirData + '\\site_table.html ' + n;
    code += 'SET !EXTRACT NULL' + n;
    code += 'ADD !EXTRACT {{STRFILE}}' + n;
    code += 'SAVEAS TYPE=EXTRACT FOLDER=C:\\' + dirData + ' FILE=site_table.html ' + n;
    code += 'TAB T=1' + n;
    code += 'URL GOTO=file:///C:/' + dirData + '/wait.html' + n;
    code += 'WAIT SECONDS=' + waitSecond + n;
    iimSet("STRFILE", strUpFile);
    iimPlay(code, 60)
}

function getFaucetIndex(){
    var t = new Array();
    var i =0;
    for (var key in faucetOn) {
        i++;
        t[i]= key;
    }
    return t
}


//========================================== EDIÃƒÆ’Ã¢â‚¬Â¡AO DAS FAUCETS ================================================

//==================moondash==============================
function moondash(pp){
if(pp>prob) return;
var file ='moondash.png';
 var code='';
  code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
  code += 'TAB T=1' + n;
  code += 'URL GOTO=http://moondash.co.in/?ref=2470603578D6' + n;
  code += 'WAIT SECONDS=2' + n;
  code += 'TAG POS=1 TYPE=A ATTR=TXT:claim<SP>from<SP>faucet' + n;
  code += 'WAIT SECONDS=10' + n;
  code += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:claim<SP>now<SP>please<SP>wait' + n;
  code += 'WAIT SECONDS=2' + n;
  iimPlay(code, 60);    
	
		
	 if (Number(Flash)>=1) {
	solve(); weit(2);}
	
	/*if (Number(ligar9kw)>=2) {
    SaveCaptcha(file);
    GetCaptcha(keyApi['9kw'], file);}
	
	if (Number(ligarCS)>=3) {	
	SaveCaptcha(file);
    GetCaptchaCS(keyApi['solutions'],keyApi['secret'], file);}*/

  var code = '';
  code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
  code += 'TAB T=1' + n;
  code += 'WAIT SECONDS=3' + n;
  code += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:Claim' + n;
  code += 'WAIT SECONDS=10' + n;
  iimPlay(code, 60);
  
		
	iimPlay("CODE:SET !TIMEOUT 1\nTAG POS=1 TYPE=H4 ATTR=TXT:Faucet<SP>claim<SP>successful EXTRACT=TXT"); 
	win=iimGetLastExtract();
	if(win == '#EANF#') {return;}
}
//==================moondoge==============================
function moondoge(pp){
if(pp>prob) return;
var file ='moondoge.png';
 var code='';
  code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
  code += 'TAB T=1' + n;
  code += 'URL GOTO=http://moondoge.co.in/?ref=d7807c49da0a' + n;
  code += 'WAIT SECONDS=2' + n;
  code += 'TAG POS=1 TYPE=INPUT:BUTTON FORM=ID:MainForm ATTR=ID:SubmitButton' + n;
  code += 'WAIT SECONDS=4' + n;
  iimPlay(code, 60);
 
  if (Number(Flash)>=1) {
	solve(); weit(2);}
	
	/*if (Number(ligar9kw)>=2) {
    SaveCaptcha(file);
    GetCaptcha(keyApi['9kw'], file);}
	
	if (Number(ligarCS)>=3) {	
	SaveCaptcha(file);
    GetCaptchaCS(keyApi['solutions'],keyApi['secret'], file);}*/


  var code = '';
  code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
  code += 'TAB T=1' + n;
  code += 'WAIT SECONDS=3' + n;
  code += 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ID:MainForm ATTR=ID:Pook6HBN' + n;
  code += 'WAIT SECONDS=10' + n;
  iimPlay(code, 60);
  
			
	iimPlay("CODE:SET !TIMEOUT 1\nTAG POS=1 TYPE=H4 ATTR=TXT:Faucet<SP>claim<SP>successful EXTRACT=TXT"); 
	win=iimGetLastExtract();
	if(win == '#EANF#') {return;}
}
//==================moonbch==============================
function moonbch(pp){
if(pp>prob) return;
var file ='moonbch.png';
 var code='';
  code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
  code += 'TAB T=1' + n;
  code += 'URL GOTO=http://moonbitcoin.cash/?ref=A15250174943' + n;
  code += 'WAIT SECONDS=2' + n;
  code += 'TAG POS=1 TYPE=A ATTR=TXT:claim<SP>from<SP>faucet' + n;
  code += 'WAIT SECONDS=10' + n;
  code += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:claim<SP>now<SP>please<SP>wait' + n;
  code += 'WAIT SECONDS=2' + n;
  iimPlay(code, 60);
 
  if (Number(Flash)>=1) {
	solve(); weit(2);}
	
	/*if (Number(ligar9kw)>=2) {
    SaveCaptcha(file);
    GetCaptcha(keyApi['9kw'], file);}
	
	if (Number(ligarCS)>=3) {	
	SaveCaptcha(file);
    GetCaptchaCS(keyApi['solutions'],keyApi['secret'], file);}*/


  var code = '';
  code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
  code += 'TAB T=1' + n;
  code += 'WAIT SECONDS=3' + n;
  code += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:Claim' + n;
  code += 'WAIT SECONDS=10' + n;
  iimPlay(code, 60);
  
			
	iimPlay("CODE:SET !TIMEOUT 1\nTAG POS=1 TYPE=H4 ATTR=TXT:Faucet<SP>claim<SP>successful EXTRACT=TXT"); 
	win=iimGetLastExtract();
	if(win == '#EANF#') {return;}
}
//==================moonlct==============================
function moonlct(pp){
if(pp>prob) return;
var file ='moonlct.png';
 var code='';
  code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
  code += 'TAB T=1' + n;
  code += 'URL GOTO=http://moonliteco.in/?ref=047fe232c92c' + n;
  code += 'WAIT SECONDS=10' + n;
  code += 'TAG POS=1 TYPE=INPUT:BUTTON FORM=ID:MainForm ATTR=ID:SubmitButton' + n;
  code += 'WAIT SECONDS=5' + n;
  iimPlay(code, 60);
 
  if (Number(Flash)>=1) {
	solve(); weit(2);}
	
	/*if (Number(ligar9kw)>=2) {
    SaveCaptcha(file);
    GetCaptcha(keyApi['9kw'], file);}
	
	if (Number(ligarCS)>=3) {	
	SaveCaptcha(file);
    GetCaptchaCS(keyApi['solutions'],keyApi['secret'], file);}*/


  var code = '';
  code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
  code += 'TAB T=1' + n;
  code += 'WAIT SECONDS=0.5' + n;
  code += 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ID:MainForm ATTR=ID:OHnn4FFjV' + n;
  code += 'WAIT SECONDS=10' + n;
  iimPlay(code, 60);
  
		
	iimPlay("CODE:SET !TIMEOUT 1\nTAG POS=1 TYPE=H4 ATTR=TXT:Faucet<SP>claim<SP>successful EXTRACT=TXT"); 
	win=iimGetLastExtract();
	if(win == '#EANF#') {return;}
}
//==================bitfun==============================
function bitfun(pp){
if(pp>prob) return;
var file ='bitfun.png';
 var code='';
  code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
  code += 'TAB T=1' + n;
  code += 'URL GOTO=http://bitfun.co/?ref=BAAC804F6A9C' + n;
  code += 'WAIT SECONDS=2' + n;
  code += 'TAG POS=1 TYPE=A ATTR=TXT:Play<SP>games' + n;
  code += 'WAIT SECONDS=2' + n;
  code += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:Claim<SP>now!<SP>Please<SP>wait' + n;
  code += 'WAIT SECONDS=2' + n;
  iimPlay(code, 60);
 
    if (Number(Flash)>=1) {
	solve(); weit(2);}
	
	/*if (Number(ligar9kw)>=2) {
    SaveCaptcha(file);
    GetCaptcha(keyApi['9kw'], file);}
	
	if (Number(ligarCS)>=3) {	
	SaveCaptcha(file);
    GetCaptchaCS(keyApi['solutions'],keyApi['secret'], file);}*/


  var code = '';
  code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
  code += 'TAB T=1' + n;
  code += 'WAIT SECONDS=3' + n;
  code += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:Claim' + n;
  code += 'WAIT SECONDS=10' + n;
  iimPlay(code, 60);

  		
	iimPlay("CODE:SET !TIMEOUT 1\nTAG POS=1 TYPE=DIV ATTR=TXT:*<SP>satoshi<SP>was<SP>sent<SP>to<SP>you<SP>on<SP>FaucetHu* EXTRACT=TXT"); 
	win=iimGetLastExtract();
	if(win == '#EANF#') {return;}
}
//==================bonusbitcoin==============================
function bonusbitcoin(pp){
if(pp>prob) return;
var file ='bonusbitcoin.png';
 var code='';
  code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
  code += 'TAB T=1' + n;
  code += 'URL GOTO=http://bonusbitcoin.co/?ref=5A585865BEA7' + n;
  code += 'WAIT SECONDS=2' + n;
  code += 'TAG POS=1 TYPE=A ATTR=ID:PageContent_FaucetButton' + n;
  code += 'WAIT SECONDS=2' + n;
  iimPlay(code, 60);
 
  if (Number(Flash)>=1) {
	solve(); weit(2);}
	
	/*if (Number(ligar9kw)>=2) {
    SaveCaptcha(file);
    GetCaptcha(keyApi['9kw'], file);}
	
	if (Number(ligarCS)>=3) {	
	SaveCaptcha(file);
    GetCaptchaCS(keyApi['solutions'],keyApi['secret'], file);}*/


  var code = '';
  code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
  code += 'TAB T=1' + n;
  code += 'WAIT SECONDS=3' + n;
  code += 'TAG POS=1 TYPE=BUTTON FORM=ID:FaucetForm ATTR=TXT:Claim<SP>now!' + n;
  code += 'WAIT SECONDS=15' + n;  
  iimPlay(code, 60);

  iimPlay('CODE:SET !TIMEOUT_STEP 1\nTAG POS=1 TYPE=DIV ATTR=TXT:Faucet<SP>claim<SP>failed:<SP>The<SP>captcha<SP>is<SP>not* EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') { 
        bonusbitcoin(pp + 1);return;} 
		
	iimPlay("CODE:SET !TIMEOUT 1\nTAG POS=1 TYPE=H4 ATTR=TXT:Faucet<SP>claim<SP>successful EXTRACT=TXT"); 
	win=iimGetLastExtract();
	if(win == '#EANF#') {return;}
}
//==================freedogcoin==============================
function freedogcoin(pp){
if(pp>prob) return;
var file ='freedogcoin.png';

    var code='';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'URL GOTO=https://freedoge.co.in/?op=home' + n;
    code += 'WAIT SECONDS=5' + n;
    iimPlay(code, 60); 
    
 if (Number(Flash)>=1) {
	solve(); weit(2);}
	
	/*if (Number(ligar9kw)>=2) {
    SaveCaptcha(file);
    GetCaptcha(keyApi['9kw'], file);}
	
	if (Number(ligarCS)>=3) {	
	SaveCaptcha(file);
    GetCaptchaCS(keyApi['solutions'],keyApi['secret'], file);}*/
     
	var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'WAIT SECONDS=0.5' + n;
    code += 'TAG POS=1 TYPE=INPUT:SUBMIT ATTR=ID:free_play_form_button' + n;
    code += 'WAIT SECONDS=5' + n;
    iimPlay(code, 60);

    iimPlay('CODE:SET !TIMEOUT_STEP 1\nTAG POS=1 TYPE=P ATTR=ID:free_play_error EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') { 
    freedogcoin(pp + 1);return;} 
		
	iimPlay("CODE:SET !TIMEOUT 1\nTAG POS=1 TYPE=SPAN ATTR=ID:winnings EXTRACT=TXT"); 
	win=iimGetLastExtract();
	if(win == '#EANF#') {return;}
}

//========================================== EDIÃƒÆ’Ã¢â‚¬Â¡AO DAS FAUCETS ================================================

//========================================== GET-SAVE-REPORT-CAPTCHA ===============================================
function SaveCaptha(file_name) {
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'SET !ENCRYPTION NO' + n;
    code += 'WAIT SECONDS=2' + n;
    code += 'ONDOWNLOAD FOLDER=C:\\' + dirData + '\\ FILE=' + file_name + ' WAIT=YES' + n;
    code += 'WAIT SECONDS=0.1' + n;
    code += 'TAG POS=1 TYPE=IMG ATTR=ID:adcopy-puzzle-image-image CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'WAIT SECONDS=1' + n;	
    code += 'TAG POS=1 TYPE=IMG ATTR=ID:adcopy-puzzle-image-image* CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'WAIT SECONDS=1' + n;	
    code += 'FRAME F=1' + n;
    code += 'TAG POS=1 TYPE=SPAN ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'TAG POS=1 TYPE=CANVAS ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'WAIT SECONDS=0.2' + n;
	code += 'FRAME F=2' + n;
    code += 'TAG POS=1 TYPE=SPAN ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'TAG POS=1 TYPE=CANVAS ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'WAIT SECONDS=0.2' + n;	
	code += 'FRAME F=3' + n;
    code += 'TAG POS=1 TYPE=SPAN ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'TAG POS=1 TYPE=CANVAS ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'WAIT SECONDS=0.2' + n;	
    code += 'FRAME F=4' + n;
    code += 'TAG POS=1 TYPE=SPAN ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'TAG POS=1 TYPE=CANVAS ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'WAIT SECONDS=0.2' + n;
	code += 'FRAME F=5' + n;
    code += 'TAG POS=1 TYPE=SPAN ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'TAG POS=1 TYPE=CANVAS ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'WAIT SECONDS=0.2' + n;	
	code += 'FRAME F=6' + n;
    code += 'TAG POS=1 TYPE=SPAN ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'TAG POS=1 TYPE=CANVAS ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'WAIT SECONDS=0.2' + n;	
	code += 'FRAME F=7' + n;
    code += 'TAG POS=1 TYPE=SPAN ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'TAG POS=1 TYPE=CANVAS ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'WAIT SECONDS=0.2' + n;	
	code += 'FRAME F=8' + n;
    code += 'TAG POS=1 TYPE=SPAN ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'TAG POS=1 TYPE=CANVAS ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'WAIT SECONDS=0.2' + n;	
	code += 'FRAME F=9' + n;
    code += 'TAG POS=1 TYPE=SPAN ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'TAG POS=1 TYPE=CANVAS ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'WAIT SECONDS=0.2' + n;	
	code += 'FRAME F=10' + n;
    code += 'TAG POS=1 TYPE=SPAN ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'TAG POS=1 TYPE=CANVAS ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'WAIT SECONDS=0.2' + n;	
	code += 'FRAME F=11' + n;
    code += 'TAG POS=1 TYPE=SPAN ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'TAG POS=1 TYPE=CANVAS ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'WAIT SECONDS=0.2' + n;	
	code += 'FRAME F=12' + n;
    code += 'TAG POS=1 TYPE=SPAN ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'TAG POS=1 TYPE=CANVAS ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'WAIT SECONDS=0.2' + n;	
	code += 'FRAME F=13' + n;
    code += 'TAG POS=1 TYPE=SPAN ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'TAG POS=1 TYPE=CANVAS ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'WAIT SECONDS=0.2' + n;	
	code += 'FRAME F=14' + n;
    code += 'TAG POS=1 TYPE=SPAN ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'TAG POS=1 TYPE=CANVAS ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'WAIT SECONDS=0.2' + n;	
	code += 'FRAME F=15' + n;
    code += 'TAG POS=1 TYPE=SPAN ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'TAG POS=1 TYPE=CANVAS ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'WAIT SECONDS=0.2' + n;	
	code += 'FRAME F=16' + n;
    code += 'TAG POS=1 TYPE=SPAN ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'TAG POS=1 TYPE=CANVAS ATTR=ID:slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'WAIT SECONDS=0.2' + n;	
    iimPlay(code, 60)
}

function GetCaptchaCS(solutions, secret, file) {
  var code = '';
  code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
  code += 'TAB OPEN' + n;
  code += 'TAB T=2' + n;
  code += 'URL GOTO=http://dindinnanet.com.br/saldo/content/captchasolutions.html' + n;
  code += 'WAIT SECONDS=.5' + n;  
  code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:http://api.captchasolutions.com/solve ATTR=NAME:key CONTENT=' + solutions + n;
  code += 'WAIT SECONDS=.5' + n;
  code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:http://api.captchasolutions.com/solve ATTR=NAME:secret CONTENT=' + secret + n;
  code += 'TAG POS=1 TYPE=INPUT:FILE FORM=ACTION:http://api.captchasolutions.com/solve ATTR=NAME:captcha CONTENT=C:\\' + dirData + '\\' + file + n;
  code += 'WAIT SECONDS=1' + n;
  code += 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ACTION:http://api.captchasolutions.com/solve ATTR=*' + n;
  code += 'SET !EXTRACT_TEST_POPUP NO' + n;
  code += 'SET !EXTRACT NULL' + n;
  code += 'TAG POS=1 TYPE=DECAPTCHA ATTR=TXT:* EXTRACT=TXT' + n;
  code += 'WAIT SECONDS=1' + n;
  code += 'TAB CLOSE' + n;
  code += 'TAB T=1' + n;
  code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ID:ClaimForm ATTR=ID:adcopy_response CONTENT={{!EXTRACT}}' + n;
	code += 'WAIT SECONDS=0.5' + n;
code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ID:* ATTR=ID:adcopy_response CONTENT={{!EXTRACT}}' + n;
	iimPlay(code, 60)
}
function GetCaptcha(keyApi, file) {
  var code = '';
  code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
  code += 'TAB OPEN' + n;
  code += 'TAB T=2' + n;
  code += 'URL GOTO=http://www.9kw.eu/grafik/form.html' + n;
  code += 'WAIT SECONDS=.5' + n;  
  code += 'TAG POS=1 TYPE=INPUT ATTR=NAME:apikey CONTENT=' + apikey + n;
  code += 'WAIT SECONDS=.5' + n;
  code += 'TAG POS=1 TYPE=INPUT ATTR=NAME:prio CONTENT=1' + n;
  code += 'TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ACTION:/index.cgi ATTR=NAME:selfsolve CONTENT=NO' + n;  
  code += 'TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ACTION:/index.cgi ATTR=NAME:confirm CONTENT=NO' + n;
  code += 'TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ACTION:/index.cgi ATTR=NAME:case-sensitive CONTENT=NO' + n;
  code += 'TAG POS=1 TYPE=INPUT ATTR=NAME:source CONTENT=imacros' + n;  
  code += 'TAG POS=1 TYPE=INPUT ATTR=NAME:file-upload-01  CONTENT=C:\\' + dirData + '\\' + file + n;
  code += 'WAIT SECONDS=1' + n;
  code += 'TAG POS=1 TYPE=INPUT ATTR=TYPE:submit' + n;
  code += 'SET !EXTRACT_TEST_POPUP NO' + n;
  code += 'SET !TIMEOUT_STEP 300' + n;
  code += 'TAG POS=1 TYPE=INPUT ATTR=NAME:result EXTRACT=TXT' + n;
  code += 'WAIT SECONDS=1' + n;
  code += 'TAB CLOSE' + n;
  code += 'TAB T=1' + n;
  code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:* ATTR=ID:adcopy_response CONTENT={{!EXTRACT}}' + n;
  code += 'WAIT SECONDS=1' + n; 
    iimPlay(code, 60)
  }

function reload() {
    iimPlayCode(t1 + "TAG POS=1 TYPE=IMG ATTR=ALT:New<SP>Puzzle&&SRC://api-secure.solvemedia.com/media/reload-whV2.gif\nWAIT SECONDS=3");
}

//========================================== GET-SAVE-REPORT-CAPTCHA ===============================================

function runFaucet(facetName){

    switch (facetName) {
		case 'freedogcoin':
    freedogcoin();
    break;
		case 'moondash':
    moondash();
    break;
		case 'moondoge':
    moondoge();
    break;
		case 'moonbch':
    moonbch();
    break;
		case 'bitfun':
    bitfun();
    break;
		case 'moonlct':
    moonlct();
    break;
		case 'bonusbitcoin':
    bonusbitcoin();
    break;
		default:
            break
    }
}

var col = 40;
var nextsbor = new Array();

nextsbor = getTimerSite();
while (100 > 0) {
    var msec = milisec();
    var i = 0;

    for (var key in faucetOn) {
        i++;
        if (nextsbor[i]< msec && faucetOn[key] > 0){
            runFaucet(key);
            updateTimer(nextsbor, i, faucetOn[key]);
        }
    }
  closeAllOthers();
  updateWaitTimer2();       
    }
function solve() {
    for (var i=1;i<=15;i++) {
iimPlay('CODE:SET !TIMEOUT_STEP 0 \n FRAME F='+i+'\nEVENT TYPE=CLICK SELECTOR="#videoPoster" BUTTON=0');
};
   for (q=0; q<2; q++) {
    var ifremesCount = window.length;
   for (z=0; z<2; z++) {
     /* Atualizando Captcha Flash */
       //iP(t0+'TAG POS=1 TYPE=AREA ATTR=SHAPE:rect&&COORDS:0,0,300,150&&ALT:&&TITLE:&&HREF:* EXTRACT=TXT'); caphc=iimGetLastExtract();
    if(iP(t0+'TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:adcopy_response')<0 || iP(t0+'TAG POS=1 TYPE=IMG ATTR=ID:adcopy-puzzle-image-image')>0) reload();
     //if((iP(t0+'TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:adcopy_response')<0 || iP(t0+'TAG POS=1 TYPE=IMG ATTR=ID:adcopy-puzzle-image-image')>0) && caphc.indexOf('EANF')>0) reload();
      else{ z=100;
   for(w=0; w<=60; w++){
      /* NÃƒÆ’Ã‚Â³s estamos tratando o captcha na tag SPAN(Reconhecimento do Captcha) captcha ou flash ou tela convencional (CAPTCHA com letras Legiveis) */
      if(iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=SPAN ATTR=ID:slog')>0 || iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=CANVAS ATTR=ID:*playIcn')>0 || iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=DIV ATTR=ID:overlay')>0 || iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=AREA ATTR=ONCLICK:no_click()&&COORDS:168,105,263,137&&SHAPE:rect')>0 || iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=AREA ATTR=ONCLICK:no_click()&&COORDS:156,75,238,103&&SHAPE:rect&&TXT:')>0 || iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=AREA ATTR=ONCLICK:don_click()&&COORDS:152,116,286,141&&SHAPE:rect&&TXT:')>0 || iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=DIV ATTR=ID:typein_area')>0 || iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=DIV ATTR=ID:optout')>0 || iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=CANVAS ATTR=ID:slog')>0){
      /* Se extrair o texto da imagem */
      if(iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=SPAN ATTR=ID:slog')>0){
         iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=SPAN ATTR=ID:slog  EXTRACT=TXT'); txt=iimGetLastExtract();}
      /* Se o CAPTCHA flash, manter ilegivel () eo cÃƒÆ’Ã‚Â³digo inferior faltando */
else if(iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=CANVAS ATTR=ID:*playIcn')>0 || iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=DIV ATTR=ID:overlay')>0){
      if(iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=CANVAS ATTR=ID:*playIcn')>0 || iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=DIV ATTR=ID:overlay')>0) weit(3.5);
         iP('ONDOWNLOAD FOLDER='+Path+' FILE=a.jpg WAIT=YES\nFRAME F='+w+'\nTAG POS=1 TYPE=DIV ATTR=ID:overlay CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT');
         iP(t0+'TAG POS=1 TYPE=A ATTR=TXT:Return*Page'); flesh();}
else if(iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=AREA ATTR=ONCLICK:no_click()&&COORDS:168,105,263,137&&SHAPE:rect')>0 || iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=AREA ATTR=ONCLICK:no_click()&&COORDS:156,75,238,103&&SHAPE:rect&&TXT:')>0 || iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=AREA ATTR=ONCLICK:don_click()&&COORDS:152,116,286,141&&SHAPE:rect&&TXT:')>0 || iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=DIV ATTR=ID:typein_area')>0){
      if(iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=AREA ATTR=ONCLICK:no_click()&&COORDS:168,105,263,137&&SHAPE:rect')>0 || iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=AREA ATTR=ONCLICK:no_click()&&COORDS:156,75,238,103&&SHAPE:rect&&TXT:')>0 || iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=AREA ATTR=ONCLICK:don_click()&&COORDS:152,116,286,141&&SHAPE:rect&&TXT:')>0) weit(2);
     iP('ONDOWNLOAD FOLDER='+Path+' FILE=a.jpg WAIT=YES\nFRAME F='+w+'\nTAG POS=1 TYPE=DIV ATTR=ID:typein_area CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT');weit(1); typein();}
      /* Se uma tela comum (CAPTCHA com letras mesmo) sÃƒÆ’Ã‚Â£o armazenados no computador e executar a tela funÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o() */
else if(iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=DIV ATTR=ID:optout')>0){
      if(iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=DIV ATTR=ID:optout')>0) weit(2);
         iP('ONDOWNLOAD FOLDER='+Path+' FILE=a.jpg WAIT=YES\nFRAME F='+w+'\nTAG POS=1 TYPE=DIV ATTR=ID:captcha CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT');weit(1); canvas();}
else if(iP(t0+'FRAME F='+w+'\nTAG POS=1 TYPE=CANVAS ATTR=ID:slog')>0){
         iP('ONDOWNLOAD FOLDER='+Path+' FILE=a.jpg WAIT=YES\nFRAME F='+w+'\nTAG POS=1 TYPE=CANVAS ATTR=ID:*slog CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT');weit(1); canvas();} w=100;}}}}
     /* Se (CAPTCHA com letras mesmo) sÃƒÆ’Ã‚Â£o armazenados na funÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o do computador e executar o ABBYY () ou se alguma coisa nÃƒÆ’Ã‚Â£o funciona a partir do topo*/
if (txt.length < 4) {
    if (iP(t0 + "TAG POS=1 TYPE=AREA ATTR=SHAPE:rect&&COORDS:0,0,300,150&&ALT:&&TITLE:&&HREF:#") > 0 || iP(t0 + "TAG POS=1 TYPE=AREA ATTR=SHAPE:rect&&COORDS:0,0,150,75&&ALT:&&TITLE:&&HREF:#") > 0) { weit(4);}
        Tabs.go(1);
        iP(t0 + "TAB CLOSEALLOTHERS\nTAG POS=1 TYPE=A ATTR=ID:adcopy-page-return");
        iP(t0 + "TAG POS=1 TYPE=AREA ATTR=SHAPE:rect&&COORDS:0,0,300,150&&ALT:&&TITLE:&&HREF:* EXTRACT=TXT");
    if (iimGetLastExtract().indexOf("EANF") < 0) {
        iP("ONDOWNLOAD FOLDER=" + Path + " FILE=a.png WAIT=YES\nTAG POS=1 TYPE=DIV ATTR=ID:adcopy-puzzle-image CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT"); weit(1); abbyy();
    }
    if (iP(t0 + "TAG POS=1 TYPE=EMBED ATTR=ID:adcopy-puzzle-image-image") > 0) {
        iP("ONDOWNLOAD FOLDER=" + Path + " FILE=a.jpg WAIT=YES\nTAG POS=1 TYPE=EMBED ATTR=ID:adcopy-puzzle-image-image CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT"); EMBED();
    }
    if (iP(t0 + "TAG POS=1 TYPE=OBJECT ATTR=ID:adcopy-puzzle-image-image") > 0) {
        iP("ONDOWNLOAD FOLDER=" + Path + " FILE=a.jpg WAIT=YES\nTAG POS=1 TYPE=OBJECT ATTR=ID:adcopy-puzzle-image-image CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT"); EMBED();
    }
}
     /* Se (CAPTCHA com letras mesmo) sÃƒÆ’Ã‚Â£o armazenados no computador e executar a funÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o carne () ou se alguma coisa nÃƒÆ’Ã‚Â£o funciona a partir do topo*/
if (w!=100 && txt.length<4) {
  for (w=0; w<=60; w++) {
  if (iP(t0 + "FRAME F=" + w + "\nTAG POS=1 TYPE=DIV ATTR=ID:*videoPoster&&STYLE:display:<SP>block;") > 0) { weit(9); f=w+1;
    iP(t0 + "FRAME F=" + w + "\nTAG POS=1 TYPE=DIV ATTR=ID:captcha&&STYLE:display:<SP>block; EXTRACT=TXT");
    if (iimGetLastExtract().indexOf("EANF") < 0) { weit(1);
    iP("ONDOWNLOAD FOLDER=" + Path + " FILE=a.jpg WAIT=YES\nFRAME F=" + w + "\nTAG POS=1 TYPE=DIV ATTR=ID:captcha CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT");
    iP(t0 + "TAG POS=1 TYPE=A ATTR=TXT:Return*Page"); flesh1(); break;}
    if (iP(t0 + "FRAME F=" + f + "\nTAG POS=1 TYPE=DIV ATTR=ID:Stage*") > 0) { weit(20);
    iP("ONDOWNLOAD FOLDER=" + Path + " FILE=a.jpg WAIT=YES\nFRAME F=" + f + "\nTAG POS=1 TYPE=DIV ATTR=ID:Stage_botox_pre_* CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT");
    iP(t0 + "TAG POS=1 TYPE=A ATTR=TXT:Return*Page"); flesh1();}
    iP(t0 + "FRAME F=" + f + "\nTAG POS=1 TYPE=DIV ATTR=CLASS:sprite<SP>slide&&ID:slide9 EXTRACT=TXT");
    if (iimGetLastExtract().indexOf("EANF") < 0) { weit(1);
    iP("ONDOWNLOAD FOLDER=" + Path + " FILE=a.jpg WAIT=YES\nFRAME F=" + f + "\nTAG POS=1 TYPE=DIV ATTR=CLASS:sprite<SP>slide&&ID:slide9 CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT");
    iP(t0 + "TAG POS=1 TYPE=A ATTR=TXT:Return*Page"); flesh1();} w=100;}}}

if (txt != "" && txt.length > 3) {
  //iimPlayCode('TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:NoFormName ATTR=NAME:* CONTENT='+wallet+'')
    iimPlayCode(t0 + 'TAG POS=1 TYPE=INPUT:TEXT ATTR=ID:adcopy_response CONTENT="'+txt+'"');
    txt = "";
  window.scrollBy(0,50);
  try {
  var timer = window.document.querySelector(".timer").textContent.match(/\d+/);}
  catch(e) {var timer = 0;};
  iimDisplay("Aguarde um Poquito");
    reportbad(); t="";}
if (Number(timer) < 1) q = 10;}}
  
        /***-= Resolvendo de flash captcha =-***/
function abbyy() { iimDisplay("Resolvendo Captcha Flash");
for (skz = 1; skz <= 20; skz += 1) {
    iimPlayCode("set !datasource " + Path + "captcha.txt");
    if (iimGetErrorText().indexOf("not exist") > -1) {
    weit(5);
    } else {
    weit(5);
        var content = loadFile("" + Path + "captcha.txt").text;
        txt = content.replace(/\n/gi, " ").replace(/\*/gi, ":").replace(/>|</gi, ":").split(/:|=|-|;/)[1];
        if (!txt) {txt = content.split(/nter |nters |nswer |nter. |nter^ /)[1];}
        break;
    }
}
        if (!txt) {
for (skz = 1; skz <= 20; skz += 1) {
    iimPlayCode("set !datasource " + Path + "captcha-1.txt");
        if (iimGetErrorText().indexOf("not exist") > -1) {
      weit(5);
        } else {
      weit(5);
            var content = loadFile("" + Path + "captcha-1.txt").text;
            txt = content.split(/:|=|-|;/)[1];
            if (!txt) {txt = content.split(/nter |nters |nswer |nter. |nter^ /)[1];}
            break;
        }
    }
}
    if (!txt) {txt = "";};
        var Cc = Components.classes, Ci = Components.interfaces, args = ["" + Path + "del.vbs"];
        var proc = Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
        var file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsILocalFile);
        file.initWithPath("C:\\Windows\\System32\\wscript.exe");
        proc.init(file); proc.run(false, args, args.length);}

         /***-= Resolvendo Captcha Flash =-***/
function flesh(){ iimDisplay('Resolvendo Captcha Flash');
    var Cc = Components.classes, Ci = Components.interfaces, args = ["" + Path + "flesh.vbs"];
        var proc = Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
        var file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsILocalFile);
        file.initWithPath("C:\\Windows\\System32\\wscript.exe");
        proc.init(file); proc.run(false, args, args.length); weit(5);
        try {
    var content = loadFile("" + Path + "otvet.txt").text;
    txt = content.replace(/\n/gi, " ").replace(/\*/gi, ":").replace(/>/gi, ":").split(/:|=|-|;/)[1];
    if (!txt) {txt = content.replace(/\n/gi, " ").split(/nter |nters |nswer |nter. |nter^ /)[1];}
    if (!txt) {txt = content;}
        txt = txt.replace(/\W/gi, "").replace(/[0-9]/gi, "").replace(/_/gi, "");
} catch(e) { weit(0.5);}
 
  if(txt=="CoHeccan"){txt="CollectCall"};    
  if(txt=="owminded"){txt="narrow-minded"};   
  if(txt=="baronanh"){txt="baconandeggs"};
  if(txt=="ofixnreah"){txt="ofixnreah"};
  if(txt=="cuuingedge"){txt="cuttingedge"};
  if(txt=="postofce"){txt="postoffice"};
  if(txt=="thinkiwirv"){txt="thinkitwice"};
  if(txt=="hotsauceT"){txt="hotsauce"};
  if(txt=="poycoke"){txt="pattycake"};
  if(txt=="SLLSCLQQS"){txt="sausages"};
  if(txt=="brfqqeyorfeomgj"){txt="mybeatingheart"};
  if(txt=="long"){txt="comealong,pond"};
  if(txt=="blaze_a tra11"){txt="blazeatrail"};
  if(txt=="teisgusnjj"){txt="Timeisanillusion"};
  if(txt=="FxshTacus"){txt="FishTacos"};
  if(txt=="BirdiePun"){txt="BirdiePutt"};
  if(txt=="Flannelshut"){txt="Flannelshirt"};
  if(txt=="TeamPlager"){txt="TeamPlayer"};
  if(txt=="TeamFLamar"){txt="TeamPlayer"};
  if(txt=="DwmgBuard"){txt="DivingBoard"};
  if(txt=="EEILLEEIcan"){txt="CollectCall"};
  if(txt=="SDHHETrannS"){txt="SpringTraining"};
  if(txt=="studuEruuu"){txt="StudyGroup"};
  if(txt=="StudgGroup"){txt="StudyGroup"};
  if(txt=="MaxPoer"){txt="MaxPower"};
  if(txt=="MaxFer"){txt="MaxPower"};
  if(txt=="TennisRaule"){txt="TennisRacket"};
  if(txt=="TennisCcurl"){txt="TennisCourt"};
  if(txt=="Hm"){txt="HockeyNet"};
  if(txt=="Hccle"){txt="HockeyStick"};
  if(txt=="HcclePurl"){txt="HockeyPuck"};
  if(txt=="snPcles"){txt="SkiPoles"};
  if(txt=="allCcun"){txt="BasketballCourt"};
  if(txt=="BaseballEa"){txt="BaseballBat"};
  if(txt=="Fccthsllcle"){txt="FootballCleats"};
  if(txt=="Iavbnx"){txt="FootballCleats"};
  if(txt=="PoolPany"){txt="PoolParty"};
  if(txt=="PiuaParty"){txt="PizzaParty"};
  if(txt=="PovieCircuit"){txt="PowerCircuit"};
  if(txt=="powerCiruzt"){txt="PowerCircuit"};
  if(txt=="ApplePio"){txt="ApplePie"};
  iimPlayCode("FILEDELETE NAME=" + Path + "otvet.txt\nFILEDELETE NAME=" + Path + "a.jpg");}

         /***-= Resolvendo Captcha Flash =-***/
function flesh1() { iimDisplay("Resolvendo e enquanto isso, AJUDE OS MAIS NECESSITADOS");
    var Cc = Components.classes, Ci = Components.interfaces, args = ["" + Path + "flesh1.vbs"];
        var proc = Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
        var file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsILocalFile);
        file.initWithPath("C:\\Windows\\System32\\wscript.exe");
        proc.init(file); proc.run(false, args, args.length); weit(4);
        try {
    var content = loadFile("" + Path + "otvet.txt").text;
    txt = content.replace(/\n/gi, " ").replace(/\*/gi, ":").replace(/>/gi, ":").split(/:|=|-|;/)[1];
    if (!txt) {txt = content.replace(/\n/gi, " ").split(/nter |nters |nswer |nter. |nter^ /)[1];}
    if (!txt) {txt = content;}
        txt = txt.replace(/\W/gi, "").replace(/[0-9]/gi, "").replace(/_/gi, "");
} catch(e) { weit(0.5);}
  iimPlayCode("FILEDELETE NAME=" + Path + "otvet.txt\nFILEDELETE NAME=" + Path + "a.jpg");}

         /***-= Resolvendo Captcha Flash =-***/
function typein(){ iimDisplay('Resolvendo entÃƒÂ£o aguarde e seja GENTIL');
    var Cc=Components.classes, Ci=Components.interfaces, args=[''+Path+'typein.vbs'];
    var proc=Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
    var file=Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsILocalFile);
    file.initWithPath('C:\\Windows\\System32\\wscript.exe');
    proc.init(file); proc.run(false, args, args.length); weit(4);
  try{
  var content = loadFile(""+Path+"otvet.txt").text;
    txt=content.replace(/\n/gi," ").replace(/\*/gi,":").replace(/>/gi,":").split(/:|=|-|;/)[1];
  if(!txt){txt=content.replace(/\n/gi," ").split(/nter |nters |nswer |nter. |nter^ /)[1];}
  if(!txt){txt=content;};
  txt=txt.replace(/\W/gi,"").replace(/[0-9]/gi,"").replace(/_/gi,"");
  } catch(e) { weit(0.5);};
  iimPlayCode('FILEDELETE NAME='+Path+'otvet.txt\nFILEDELETE NAME='+Path+'a.jpg');}

         /***-= Resolvendo captcha EMBED =-***/
function EMBED(){ iimDisplay('Resolvendo captcha EMBED');
    var Cc=Components.classes, Ci=Components.interfaces, args=[''+Path+'EMBED.vbs'];
    var proc=Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
    var file=Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsILocalFile);
    file.initWithPath('C:\\Windows\\System32\\wscript.exe');
    proc.init(file); proc.run(false, args, args.length); weit(4);
  try{
  var content = loadFile(""+Path+"otvet.txt").text;
    txt=content.replace(/\n/gi," ").replace(/\*/gi,":").replace(/>/gi,":").split(/:|=|-|;/)[1];
  if(!txt){txt=content.replace(/\n/gi," ").split(/nter |nters |nswer |nter. |nter^ /)[1];}
  if(!txt){txt=content;};
  txt=txt.replace(/\W/gi,"").replace(/[0-9]/gi,"").replace(/_/gi,"");
  } catch(e){ weit(0.5);};
  if(txt=="CoHeccan"){txt="CollectCall"};    
  if(txt=="owminded"){txt="narrow-minded"};  
  if(txt=="baronanh"){txt="baconandeggs"};  
  if(txt=="ofixnreah"){txt="ofixnreah"};
  if(txt=="cuuingedge"){txt="cuttingedge"};
  if(txt=="postofce"){txt="postoffice"};
  if(txt=="thinkiwirv"){txt="thinkitwice"};
  if(txt=="hotsauceT"){txt="hotsauce"};
  if(txt=="poycoke"){txt="pattycake"};
  if(txt=="SLLSCLQQS"){txt="sausages"};
  if(txt=="brfqqeyorfeomgj"){txt="mybeatingheart"};
  if(txt=="long"){txt="comealong,pond"};
  if(txt=="blaze_a tra11"){txt="blazeatrail"};
  if(txt=="teisgusnjj"){txt="Timeisanillusion"};
  if(txt=="MaxPoer"){txt="MaxPower"};
  if(txt=="MaxFer"){txt="MaxPower"};
  if(txt=="TennisRaule"){txt="TennisRacket"};
  if(txt=="TennisCcurl"){txt="TennisCourt"};
  if(txt=="Hm"){txt="HockeyNet"};
  if(txt=="Hccle"){txt="HockeyStick"};
  if(txt=="HcclePurl"){txt="HockeyPuck"};
  if(txt=="snPcles"){txt="SkiPoles"};
  if(txt=="allCcun"){txt="BasketballCourt"};
  if(txt=="BaseballEa"){txt="BaseballBat"};
  if(txt=="Fccthsllcle"){txt="FootballCleats"};
  if(txt=="Iavbnx"){txt="FootballCleats"};
  if(txt=="PoolPany"){txt="PoolParty"};
  if(txt=="PiuaParty"){txt="PizzaParty"};
  if(txt=="PovieCircuit"){txt="PowerCircuit"};
  if(txt=="powerCiruzt"){txt="PowerCircuit"};
  iimPlayCode('FILEDELETE NAME='+Path+'otvet.txt');}

         /***-= Estamos Resolvendo o captcha =-***/
function canvas(){ iimDisplay('Estamos Resolvendo o captcha');
    var Cc=Components.classes, Ci=Components.interfaces, args=[''+Path+'canvas.vbs'];
    var proc=Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
    var file=Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsILocalFile);
    file.initWithPath('C:\\Windows\\System32\\wscript.exe');
    proc.init(file); proc.run(false, args, args.length); weit(4);
  try{
  var content = loadFile(""+Path+"otvet.txt").text;
    txt=content.replace(/\n/gi," ").replace(/\*/gi,":").replace(/>/gi,":").split(/:|=|-|;/)[1];
  if(!txt){txt=content.replace(/\n/gi," ").split(/nter |nters |nswer |nter. |nter^ /)[1];}
  if(!txt){txt=content;};
  txt=txt.replace(/\W/gi,"").replace(/[0-9]/gi,"").replace(/_/gi,"");
  } catch(e){ weit(0.5);};
  if(txt=="COme"){txt="Collme"};
  if(txt=="raysrrcw"){txt="srayscrow"};
  if(txt=="UGHTGwÃƒÂ¯Ã‚Â¬Ã‚Âcx"){txt="UGHTGwoo"};
  iimPlayCode('FILEDELETE NAME='+Path+'otvet.txt');}

              /***-= atualizar o captcha =-***/
function reload() {
    iimPlayCode(t3 + "TAG POS=1 TYPE=IMG ATTR=SRC:*solvemedia.com/media/reload*.gif\nWAIT SECONDS=3");
}
         /***-= Reporte para o Captcha errado =-***/
function reportbad() {
    if (!t[1]) return;
    if (iimPlayCode(t0 + "TAG POS=3 TYPE=DIV ATTR=TXT:Solving<SP>puzzle<SP>failed.<SP>Please<SP>try<SP>again<SP>to*") > 0) {
    iimPlayCode("TAB OPEN\nTAB T=2\nURL GOTO=rucaptcha.com/res.php?key=" + api + "&action=reportbad&id=" + t[1] + "\nWAIT SECONDS=1\nTAB CLOSE");
    iimPlayCode("TAG POS=3 TYPE=DIV ATTR=TXT:Solving<SP>puzzle<SP>failed.<SP>Please<SP>try<SP>again<SP>to*");
    }
}
         /***-= Random =-***/
function weit(s) {iimPlayCode("WAIT SECONDS=" + s);}
