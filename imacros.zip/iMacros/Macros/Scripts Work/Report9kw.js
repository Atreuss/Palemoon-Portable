﻿//=====================//
var pp = 0; 
var prob = 10;
var n = '\n'; 
var randomtimer = 1;
var prio = 20;
var dirData = 'Bitfun';
var keyApi = new Array(); keyApi['9kw'] = 'U7S94YKZP85B8W5LYL';
//=====================//
for (var i=1;i<999999999999999;i++)
{
Bitfun();
}
//=====================//
function Bitfun () {
    if(pp>prob) return;
        var file ='Bitfun.png';
    //if (Number (randomtimer)>=1) weitrandom();

    var Inicio = '';
            Inicio += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
                Inicio += 'TAB T=1' + n;
                    Inicio += 'URL GOTO=bitfun.co/games' + n;
                        Inicio += 'WAIT SECONDS=2' + n;
                    Inicio += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:Claim<SP>now!<SP>Please<SP>wait' + n;
                Inicio += 'WAIT SECONDS=2' + n;
            Inicio += 'TAG POS=1 TYPE=A ATTR=TXT:Switch<SP>to<SP>SolveMedia<SP>captcha' + n;
        Inicio += 'WAIT SECONDS=2' + n;
    iimPlay(Inicio, 60);

    SaveCaptha(file);
    GetCaptcha(keyApi['9kw'], file);

   /* var Claim = ''; 
            Claim += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
                Claim += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ID:ClaimForm ATTR=ID:adcopy_response CONTENT=' + answer + n;
                Claim += 'WAIT SECONDS=2' + n;
            Claim += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:Claim' + n;
        Claim += 'WAIT SECONDS=2' + n;
    iimPlay(Claim, 60);*/

    iimPlay('CODE:SET !TIMEOUT_STEP 1\nTAG POS=1 TYPE=DIV ATTR=CLASS:modal-body&&DATA-BIND:html:<SP>bodyHtml EXTRACT=TXT');
        err = iimGetLastExtract();
            if (err != '' && err != '#EANF#') { 
    Bitfun(pp + 1);return;}

    iimPlay("CODE:SET !TIMEOUT 1\nTAG POS=2 TYPE=H4 ATTR=CLASS:modal-title EXTRACT=TXT"); 
        win=iimGetLastExtract();
    if(win == '#EANF#') {return;}

    if (Number (randomtimer)>=1) weitrandom();
}

function SaveCaptha(file_name) {
    
    var code = '';
            code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
                code += 'TAB T=1' + n;
                    code += 'SET !ENCRYPTION NO' + n;
                        code += 'WAIT SECONDS=0.1' + n;
                    code += 'ONDOWNLOAD FOLDER=C:\\' + dirData + '\\ FILE=' + file_name + ' WAIT=YES' + n;
                code += 'WAIT SECONDS=0.1' + n;
            code += 'TAG POS=1 TYPE=IMG ATTR=ID:adcopy-puzzle-image-image CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
        code += 'WAIT SECONDS=1' + n;
    iimPlay(code, 60)
}

function GetCaptcha(apikey, file, captchaid, result, answer) {

    var captchaid;
    var answer = "";
    
    captchaid = "";
    answer = "";

    if(apikey.match(/^[a-zA-Z0-9]+$/) && apikey.length <= 50 && apikey.length >= 5){}else{alert_message_9kw("API Key \""+apikey+"\" is wrong.");return false;}
    var d = parseFloat(prio); if(d >= 0 && d <= 20){}else{alert_message_9kw("Prio \""+prio+"\" is not in the set range.");return false;}

    var code = '';
        code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
            code += 'TAB OPEN' + n;
                code += 'TAB T=2' + n;
                    code += 'URL GOTO=http://www.9kw.eu/grafik/form.html' + n;
                        code += 'TAG POS=1 TYPE=INPUT ATTR=NAME:apikey CONTENT=' + apikey + n;
                            code += 'TAG POS=1 TYPE=INPUT ATTR=NAME:prio CONTENT=' + prio + n;
                                code += 'TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ACTION:/index.cgi ATTR=NAME:selfsolve CONTENT=NO' + n;
                                    code += 'TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ACTION:/index.cgi ATTR=NAME:confirm CONTENT=NO' + n;
                                code += 'TAG POS=1 TYPE=INPUT:CHECKBOX FORM=ACTION:/index.cgi ATTR=NAME:case-sensitive CONTENT=NO' + n;
                            code += 'TAG POS=1 TYPE=INPUT ATTR=NAME:source CONTENT=imacros' + n;
                        code += 'TAG POS=1 TYPE=INPUT ATTR=NAME:file-upload-01 CONTENT=C:\\' + dirData + '\\' + file + n;
                    code += 'TAG POS=1 TYPE=INPUT ATTR=TYPE:submit' + n;
                code += 'SET !EXTRACT_TEST_POPUP NO' + n;
            code += 'SET !TIMEOUT_STEP 99999' + n;
        code += 'TAG POS=1 TYPE=INPUT ATTR=NAME:captchaid EXTRACT=TXT' + n;
    iimPlay(code)
    answer = iimGetLastExtract();

    if(answer == "#EANF#" || answer == "ERROR NO USER"){
            answer = "";
    }

    var captchaid ='CODE:' + n;
            captchaid +='SET !EXTRACT NULL' + n;
                captchaid +='TAG POS=1 TYPE=INPUT ATTR=NAME:captchaid EXTRACT=TXT' + n;
            captchaid +='SET captchaid {{!EXTRACT}}' + n;
        captchaid +='WAIT SECONDS=1' + n;
    iimPlay(captchaid)
    captchaid = iimGetLastExtract();

    var result ='CODE:'
            result +='SET !EXTRACT NULL' + n;
                result +='SET !EXTRACT_TEST_POPUP NO' + n;
            result +='SET !TIMEOUT_STEP 99999' + n;
                result +='TAG POS=1 TYPE=INPUT ATTR=NAME:result EXTRACT=TXT' + n;
            result +='WAIT SECONDS=2' + n;
        result +='TAB CLOSE' + n;
    iimPlay(result)
    result = iimGetLastExtract();

    if(answer == "#EANF#" || answer == "ERROR NO USER"){
            answer = "";
    }

    var Claim = ''; 
            Claim += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
                Claim +='TAB T=1' + n;
                        Claim += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ID:ClaimForm ATTR=ID:adcopy_response CONTENT=' + result + n;
                Claim += 'WAIT SECONDS=2' + n;
            Claim += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:Claim' + n;
        Claim += 'WAIT SECONDS=2' + n;
    iimPlay(Claim, 60);

    iimPlay('CODE:SET !TIMEOUT_STEP 1\nTAG POS=1 TYPE=DIV ATTR=CLASS:modal-body&&DATA-BIND:html:<SP>bodyHtml EXTRACT=TXT');
        err = iimGetLastExtract();
            if (err != '' && err != '#EANF#') { 
    report();Bitfun(pp + 1);return;}

    iimPlay("CODE:SET !TIMEOUT 1\nTAG POS=2 TYPE=H4 ATTR=CLASS:modal-title EXTRACT=TXT"); 
        win=iimGetLastExtract();
            if(win == '#EANF#') {
    feedback();return;}

    function feedback (pp) {

        var code = '';
            code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
                code += 'TAB T=1' + n;
                    code += 'TAB OPEN' + n;
                        code += 'TAB T=2' + n;
                        code += 'URL GOTO=http://www.9kw.eu/index.cgi?source=imacros&action=usercaptchacorrectback&apikey=' + apikey + '&correct=1&id=' + captchaid + n;
                    code += 'WAIT SECONDS=2' + n;
                code += 'TAB CLOSE' + n;
            code += 'TAB T=1' + n;
        iimPlay(code, 60)
    }

    function report (pp) {
        
        var code = '';
            code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
                code += 'TAB T=1' + n;
                    code += 'TAB OPEN' + n;
                        code += 'TAB T=2' + n;
                        code += 'URL GOTO=http://www.9kw.eu/index.cgi?source=imacros&action=usercaptchacorrectback&apikey=' + apikey + '&correct=2&id=' + captchaid + n;
                    code += 'WAIT SECONDS=2' + n;
                code += 'TAB CLOSE' + n;
            code += 'TAB T=1' + n;
        iimPlay(code, 60)
    }
}

function weitrandom(){
    var randomNumber = Math.floor(Math.random()+300);
    iimDisplay('Esperando ' + randomNumber + ' Segundos');
    iimPlayCode('WAIT SECONDS='+randomNumber);
}