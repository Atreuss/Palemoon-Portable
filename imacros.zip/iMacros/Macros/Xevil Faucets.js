var Cc=Components.classes, Ci=Components.interfaces;
var proc=Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
var file=Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsILocalFile);
var cok=Cc["@mozilla.org/cookiemanager;1"].getService(Ci.nsICookieManager);
var prf=Cc["@mozilla.org/preferences-service;1"].getService(Ci.nsIPrefBranch);
var str=Cc["@mozilla.org/supports-string;1"].createInstance(Ci.nsISupportsString);
var alt=Cc["@mozilla.org/embedcomp/prompt-service;1"].getService(Ci.nsIPromptService);

//=========================================================================================================

var faucetOn = new Array();
var dirData = 'Hotcoin+Bigbtcwin';
var prob = 1;
var n = '\n'; 
var pp = 0; 

faucetOn['log'] = 1440;
faucetOn['hotcoins']=10;
faucetOn['getfreeBTC']=10;
faucetOn['bigbtc']=5;
faucetOn['ethxup']=5;

var btc = '158fRAFW2c6TpHHY9123BFPZEdqWL19aTm';
var login = '';
var senha = '';

//=========================================================================================================

var Tabs = {
    _browser: function () {
        var wm = Components.classes["@mozilla.org/appshell/window-mediator;1"]
            .getService(Components.interfaces.nsIWindowMediator);
        return wm.getMostRecentWindow("navigator:browser").gBrowser;
    }(),
    go: function (tabIndex) {
        this._browser.selectedTab = this._browser.tabContainer.childNodes[tabIndex - 1];
    }
};

var loadFile = function (fileName) {
   var fileDescriptor = imns.FIO.openNode(fileName);
   var text = imns.FIO.readTextFile(fileDescriptor);
   return {
       text: text,
       strings: text.replace(/ /gi, "").split("\r\n")
    };
};

var appendToFile = function (fileName, text) {
   var fileDescriptor = imns.FIO.openNode(fileName);
   imns.FIO.appendTextFile(fileDescriptor, text);
}

function log(feler){
   var timer=getDate();
   txt=feler+'    '+timer; 
   iimPlayCode('SET !EXTRACT '+txt.replace(/ /gi,"<SP>") + ' \nSAVEAS TYPE=EXTRACT  FOLDER=C:\\' + dirData + '\\ FILE=log.txt');
}

function getDate(){var d=new Date(); return d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();}  
   
function weitrandom(){  
    
    var randomNumber = Math.floor(Math.random()*240 + 120); 
    iimDisplay('esperando por ' + randomNumber + ' segundos');
    iimPlayCode('WAIT SECONDS='+randomNumber);  
} 
    
function milisec() {
    return new Date().getTime()
}

function closeAllOthers() {
    var code = '';
    code += 'CODE: \n SET !TIMEOUT_PAGE 600 \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'TAB CLOSEALLOTHERS' + n;
    iimPlay(code, 60)
}

function getTimerSite() {
    var t = new Array();
    var str = '';
    var code = '';
    code += 'CODE: \n SET !TIMEOUT_PAGE 600 \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'SET !DATASOURCE C:\\' + dirData + '\\timer2.csv' + n;
    code += 'SET !DATASOURCE_LINE 1' + n;
    code += 'SET !EXTRACT NULL ' + n;
    code += 'SET !VAR1 {{!COL1}}' + n;
    code += 'ADD !EXTRACT {{!VAR1}}' + n;
    iimPlay(code, 60);
    str = iimGetLastExtract();
    return str.split('|')
}

function updateTimer(t, i, min) {
    var str = '';
    var nowtime = milisec();
    msec = min * 60 * 1000;
    t[i] = nowtime + msec;
    nextsbor[i] = t[i];
    str = t.join('|');
    var code = '';
    code += 'CODE: \n SET !TIMEOUT_PAGE 600 \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'SET !EXTRACT NULL' + n;
    code += 'ADD !EXTRACT ' + str + n;
    code += 'FILEDELETE NAME=C:\\' + dirData + '\\timer2.csv ' + n;
    code += 'SAVEAS TYPE=EXTRACT FOLDER=C:\\' + dirData + '\\ FILE=timer2.csv ' + n;
    iimPlay(code, 60)
}

function updateWaitTimer2() {
    var waitSecond = 999999;
    var t = nextsbor;
    var nowMilisec = milisec();
    var strUpFile = '';
    var strUpFile_light = '';
    timeToCountDown = '';
    var header = '&quot;<link href=\'bootstrap/css/bootstrap.min.css\' rel=\'stylesheet\' media=\'screen\'><link href=\'bootstrap/css/bootstrap-responsive.min.css\' rel=\'stylesheet\' media=\'screen\'><link href=\'vendors/easypiechart/jquery.easy-pie-chart.css\' rel=\'stylesheet\' media=\'screen\'><link href=\'assets/styles.css\' rel=\'stylesheet\' media=\'screen\'>';
    var table = '';
    var i = 0;
    table += '<div class=\'block\'><div class=\'navbar navbar-inner block-header\'><div class=\'muted pull-left\'>Bem Vindo(a)</div></div><div class=\'block-content collapse in\'><div class=\'span12\'><table class=\'table table-condensed\'><thead><tr><th></th><th>Site</th><th>Contador</th><th>Tempo</th></tr></thead><tbody>';
    for (var key in faucetOn) {
        i++;
        if (faucetOn[key] > 0) {
            var countdownSec = parseInt((t[i] - nowMilisec) / 1000);
            if (countdownSec < 3) {
                countdownSec = 3
            }
            if (countdownSec < waitSecond) {
                nextSite = key;
                waitSecond = countdownSec
            }
            table += '<tr><td>' + i + '</td><td>' + key + '</td><td class=\'ttimer\'>' + countdownSec + '</td><td><span class=\'badge badge-info\'>' + faucetOn[key] + '</span></td></tr>'
        } else {
            table += '<tr><td>' + i + '</td><td>' + key + '</td><td>OFF</td><td></td></tr>'
        }
    }
    table += '</tbody></table></div></div></div>';
    var footer = '<script src=\'vendors/jquery-1.9.1.min.js\'></script><script src=\'bootstrap/js/bootstrap.min.js\'></script><script src=\'vendors/easypiechart/jquery.easy-pie-chart.js\'></script><script src=\'js/fn.js\'></script><script>$(timerTable());</script>';
    var dopdata = '<span class=\'badge badge-warning \'>Next: ' + nextSite + '</span><span class=\'badge badge-success ttimer\'> ' + waitSecond + '</span><span class=\'badge badge-info pull-right\'><i class=\'icon-tag\'></i>PAZ</span> ';
    strUpFile += header + dopdata + table + footer + '&quot;';
    var code = '';
    code += 'CODE: \n SET !TIMEOUT_PAGE 600 \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'FILEDELETE NAME=C:\\' + dirData + '\\site_table.html ' + n;
    code += 'SET !EXTRACT NULL' + n;
    code += 'ADD !EXTRACT {{STRFILE}}' + n;
    code += 'SAVEAS TYPE=EXTRACT FOLDER=C:\\' + dirData + ' FILE=site_table.html ' + n;
    code += 'TAB T=1' + n;
    code += 'URL GOTO=file:///C:/' + dirData + '/wait.html' + n;
    code += 'WAIT SECONDS=' + waitSecond + n;
    iimSet("STRFILE", strUpFile);
    iimPlay(code, 60)
}

function getFaucetIndex(){
    
    var t = new Array();
    var i =0;
    for (var key in faucetOn) {
        i++;
        t[i]= key;
    }
    return t
}

function bonus() {

    var code='';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_TAG 60 \n';
    code += 'TAB T=1' + n;
    code += 'TAB CLOSEALLOTHERS' + n;    
    code += 'URL GOTO=http://bigbtc.win/bonus' + n;
    code += 'URL GOTO=javascript:window.scrollBy(0,860)' + n;
    code += 'TAB CLOSEALLOTHERS' + n;
    code += 'WAIT SECONDS=5' + n;
    code += 'TAG POS=1 TYPE=BUTTON FORM=ACTION:* ATTR=ID:clickhere' + n;
    code += 'WAIT SECONDS=5' + n;
    //code += 'TAB CLOSEALLOTHERS' + n;
    code += 'EVENT TYPE=CLICK SELECTOR="#skip_bu2tton>IMG" BUTTON=0'+ n;
    code += 'WAIT SECONDS=2.5' + n;
    //code += 'TAB T=1' + n;
    code += 'TAB CLOSEALLOTHERS' + n;

    iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=IMG ATTR=ID:bee EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') 
    {claimbee();return;}
    //code += 'TAB T=1' + n;
    code += 'TAB CLOSEALLOTHERS' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=A ATTR=TXT:BACK<SP>TO<SP>FAUCET' + n;
    iimPlay(code, 60);

    bigbtc();

    function claimbee(){
	    code += 'EVENT TYPE=CLICK SELECTOR="#skip_bu2tton>IMG" BUTTON=0'+ n;
	    code += 'WAIT SECONDS=1' + n;
	}
}

//===================================================================================================================

function bigbtc(pp) {
    var file ='bigbtc.png';

    var code='';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'URL GOTO=http://bigbtc.win/faucet' + n;
    code += 'WAIT SECONDS=7' + n;
    code += 'URL GOTO=javascript:window.scrollBy(0,860)' + n;
    iimPlay(code, 60);

    iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=H2 ATTR=TXT:LOGIN EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') {login();}

    iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=A ATTR=TXT:CLAIM<SP>*<SP>SATOSHI<SP>BONUS<SP>NOW! EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') {bonus(pp + 1);return;}

    SaveCapthaSolve(file);
    var str = GetRucaptcha(file);
    var cText = str['c_text'];
    var captha = cText.replace(/\s/g, '<SP>');
    iimDisplay(captha);
    if (captha == '') {return}
    if (captha == 'ERROR') {return}
    if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}

    var code='';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:/claim-xckdf ATTR=ID:adcopy_response CONTENT=' + captha + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:PLAY' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'FILEDELETE NAME=C:\\' + dirData + '\\' + file + n;
    iimPlay(code, 60);

    SaveCapthaSolve2(file);
    var str = GetRucaptcha(file);
    var cText = str['c_text'];
    var captha = cText.replace(/\s/g, '<SP>');
    iimDisplay(captha);
    if (captha == '') {return}
    if (captha == 'ERROR') {return}
    if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}

    var code='';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:/claim-xckdf ATTR=NAME:captcha_code CONTENT=' + captha + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ACTION:/claim-xckdf ATTR=ID:claimbtn' + n;
    code += 'FILEDELETE NAME=C:\\' + dirData + '\\' + file + n;
    iimPlay(code, 60);

    iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=DIV ATTR=CLASS:alert<SP>alert-error EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') {bigbtc(pp + 1);return;}

    iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=P ATTR=CLASS:alert<SP>alert-success<SP>pulse EXTRACT=TXT');
    win=iimGetLastExtract();
    if(win == '#EANF#') {return;}
}
//===================================================================================================================

function bonus() {

    var code='';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_TAG 60 \n';
    code += 'TAB T=1' + n;
    code += 'TAB CLOSEALLOTHERS' + n;    
    code += 'URL GOTO=http://bigbtc.win/bonus' + n;
    code += 'URL GOTO=javascript:window.scrollBy(0,860)' + n;
    code += 'TAB CLOSEALLOTHERS' + n;
    code += 'WAIT SECONDS=5' + n;
    code += 'TAG POS=1 TYPE=BUTTON FORM=ACTION:* ATTR=ID:clickhere' + n;
    code += 'WAIT SECONDS=5' + n;
    //code += 'TAB CLOSEALLOTHERS' + n;
    code += 'EVENT TYPE=CLICK SELECTOR="#skip_bu2tton>IMG" BUTTON=0'+ n;
    code += 'WAIT SECONDS=2.5' + n;
    //code += 'TAB T=1' + n;
    code += 'TAB CLOSEALLOTHERS' + n;

    iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=IMG ATTR=ID:bee EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') 
    {claimbee();return;}
    //code += 'TAB T=1' + n;
    code += 'TAB CLOSEALLOTHERS' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=A ATTR=TXT:BACK<SP>TO<SP>FAUCET' + n;
    iimPlay(code, 60);

    bigbtc();

    function claimbee(){
	    code += 'EVENT TYPE=CLICK SELECTOR="#skip_bu2tton>IMG" BUTTON=0'+ n;
	    code += 'WAIT SECONDS=1' + n;
	}
}

function login(pp) {

    var code='';
    code += 'CODE: \n SET !TIMEOUT_PAGE 600 \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:/faucet ATTR=NAME:address CONTENT=' + btc + n;
    code += 'WAIT SECONDS=2' + n;
    iimPlay(code, 60);

    window.document.querySelector('input[type="submit"][class="button"]').click(); weit(2)
    
    iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=DIV ATTR=CLASS:alert<SP>alert-error EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') {login(pp + 1);return;}
}

//===================================================================================================================

function ethxup(pp){
  
	if(pp>prob) return;

	var code='';
	code += 'CODE: \n SET !TIMEOUT_PAGE 600 \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'URL GOTO=http://ethxup.com/claim' + n;
	code += 'WAIT SECONDS=5' + n;
	code += 'TAG POS=3 TYPE=A ATTR=TXT:CLAIM<SP>REWARD' + n;
	iimPlay(code, 60);

	var file ='ethxup.png';
	SaveCapthaSolve(file);
	var str = GetRucaptcha(file);
	var cText = str['c_text'];
	var captha = cText.replace(/\s/g, '<SP>');
	iimDisplay(captha);
	if (captha == '') {return}
	if (captha == 'ERROR') {return}
	if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}

	var code='';
	code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=NAME:* ATTR=ID:adcopy_response CONTENT=' + captha + n;
	code += 'WAIT SECONDS=2' + n;
	code += 'EVENT TYPE=CLICK SELECTOR="#claim>DIV>FORM>DIV>DIV:nth-of-type(3)>BUTTON:nth-of-type(2)" BUTTON=0' + n;
	code += 'WAIT SECONDS=1' + n;
	code += 'FILEDELETE NAME=C:\\' + dirData + '\\' + file + n;
	iimPlay(code, 60);

	iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=DIV ATTR=CLASS:alert<SP>alert-block<SP>alert-danger<SP>fade<SP>in EXTRACT=TXT');
		err = iimGetLastExtract();
	if (err != '' && err != '#EANF#') {
		ethxup(pp + 1);return;
	} else {
		iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=A ATTR=DATA-TARGET:#claim&&DATA-TOGGLE:modal&&TITLE:Claim<SP>Reward&&HREF:&&CLASS:btn<SP>btn-success EXTRACT=TXT');
			err = iimGetLastExtract();
		if (err != '' && err != '#EANF#') {
			ethxup(pp + 1);return;
		}
	}

    iimPlay("CODE:SET !TIMEOUT_TAG 0\nTAG POS=3 TYPE=DIV ATTR=TXT:You've<SP>already<SP>claimed<SP>from<SP>faucet.<SP>You<SP>ca* EXTRACT=TXT");
    win=iimGetLastExtract();
  	if(win == '#EANF#') {return;}
}

//===================================================================================================================

function hotcoins(pp) {

    if(pp>prob) return;

    var code='';
    code += 'CODE: \n SET !TIMEOUT_PAGE 600 \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'URL GOTO=http://hotcoins.cf/faucet' + n;
    code += 'WAIT SECONDS=5' + n;
    iimPlay(code, 60);

    iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=P ATTR=TXT:Enter<SP>your<SP>bitcoin<SP>address<SP>to<SP>start: EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') {loginhotcoin(pp + 1);}

    iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=BUTTON ATTR=TXT:CLAIM<SP>5<SP>SATOSHI<SP>BONUS<SP>NOW EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') {bonushotcoin(pp + 1);}

    if (!window.location.host != "hotcoins.cf/claimbonus2"){
    	iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=BUTTON ATTR=TXT:BACK<SP>TO<SP>FAUCET\nWAIT SECONDS=10');
    	window.scrollBy(0,640);
    }

    var file ='hotcoins.png';
    SaveCapthaSolve(file);
    var str = GetRucaptcha(file);
    var cText = str['c_text'];
    var captha = cText.replace(/\s/g, '<SP>');
    iimDisplay(captha);
    if (captha == '') {return}
    if (captha == 'ERROR') {return}
    if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}

    var code='';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:* ATTR=ID:adcopy_response CONTENT=' + captha + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:PLAY' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'FILEDELETE NAME=C:\\' + dirData + '\\' + file + n;
    iimPlay(code, 60);

    var file ='captcha2.png';
    SaveCapthaSolve2(file);
    var str = GetRucaptcha(file);
    var cText = str['c_text'];
    var captha = cText.replace(/\s/g, '<SP>');
    iimDisplay(captha);
    if (captha == '') {return}
    if (captha == 'ERROR') {return}
    if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}

    var code='';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:/* ATTR=NAME:captcha_code CONTENT=' + captha + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ACTION:/* ATTR=ID:claimbtn' + n;
    code += 'FILEDELETE NAME=C:\\' + dirData + '\\' + file + n;
    iimPlay(code, 60);

    iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=DIV ATTR=CLASS:alert<SP>alert-error EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') {hotcoins();return;}

    iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=DIV ATTR=CLASS:alert<SP>alert-success EXTRACT=TXT');
    win=iimGetLastExtract();
    if(win == '#EANF#') {return;}
}

//===================================================================================================================

function loginhotcoin(pp) {

	window.scrollBy(0,140);

    var code='';
    code += 'CODE: \n SET !TIMEOUT_PAGE 600 \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:* ATTR=NAME:address CONTENT=' + btc + n;
    code += 'WAIT SECONDS=2' + n;   
    iimPlay(code, 60);

    window.document.querySelector('input[type="submit"][class="hidead btn btn-info buttonmargin input-block-level"]').click(); weit(2)
    
    iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=DIV ATTR=CLASS:alert<SP>alert-error EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') {loginhotcoin(pp + 1);}

    var code='';
    code += 'CODE:';
    code += 'WAIT SECONDS=20' + n;  
    code += 'URL GOTO=javascript:window.scrollBy(0,640)' + n;
    iimPlay(code, 60);
}

function bonushotcoin(pp) {

	iimDisplay('Bonus Detectado...');

	var code='';
    code += 'CODE: \n SET !TIMEOUT_PAGE 600 \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:CLAIM<SP>5<SP>SATOSHI<SP>BONUS<SP>NOW' + n;
    code += 'WAIT SECONDS=2' + n;
    code += 'TAG POS=1 TYPE=BUTTON FORM=ACTION:* ATTR=ID:clickhere' + n;
    iimPlay(code, 60);

    if (window.location.host != "kokemoon.com"){
    	iimDisplay('CaptchaShortlink Detectado...');
    	window.scrollBy(0,1320)
    }

	var file ='CaptchaShortlink.png';
    SaveCaptchaShortlink(file);
    var str = GetRucaptcha(file);
    var cText = str['c_text'];
    var captha = cText.replace(/\s/g, '<SP>');
    iimDisplay(captha);
    if (captha == '') {return}
    if (captha == 'ERROR') {return}
    if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}

    var code='';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ID:* ATTR=ID:adcopy_response-captchaShortlink CONTENT=' + captha + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=BUTTON FORM=ID:* ATTR=ID:invisibleCaptchaShortlink' + n;
    code += 'FILEDELETE NAME=C:\\' + dirData + '\\' + file + n;
    iimPlay(code, 60);

    iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=DIV ATTR=ROLE:alert&&CLASS:alert<SP>alert-danger EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') {bonushotcoin(pp + 1);return;}

    if (window.content.document.getElementById('countdown')) {
		iimDisplay('Esperando...');
		iimPlayCode('WAIT SECONDS=20');
		iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=A ATTR=TXT:Get<SP>Link\nWAIT SECONDS=5');
	}
}

//===================================================================================================================


function getfreeBTC(pp) {

	if(pp>prob) return;

	var code='';
	code += 'CODE: \n SET !TIMEOUT_PAGE 600 \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'URL GOTO=http://getfree.co.in' + n;
	code += 'WAIT SECONDS=10' + n;
	iimPlay(code, 60);

	iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=P ATTR=TXT:Enter<SP>your<SP>bitcoin<SP>address<SP>to<SP>start<SP>advent* EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') {logingetfree(pp + 1);}

	var file = 'captcha1.png'
	SaveCapthaSolve(file);
	var str = GetRucaptcha(file);
	var cText = str['c_text'];
	var captha = cText.replace(/\s/g, '<SP>');
	iimDisplay(captha);
	if (captha == '') {return}
	if (captha == 'ERROR') {return}
	if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}

	var code='';
	code += 'CODE: \n SET !TIMEOUT_PAGE 600 \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:/claim ATTR=ID:adcopy_response CONTENT=' + captha + n;
	code += 'WAIT SECONDS=1' + n;
	code += 'FILEDELETE NAME=C:\\' + dirData + '\\' + file + n;
	iimPlay(code, 60);

	var file = 'captcha2.png'
	SaveCapthaSolve2(file);
	var str = GetRucaptcha(file);
	var cText = str['c_text'];
	var captha = cText.replace(/\s/g, '<SP>');
	iimDisplay(captha);
	if (captha == '') {return}
	if (captha == 'ERROR') {return}
	if (captha == 'ERROR_CAPTCHA_UNSOLVABLE') {return}

	var code=''; 
	code += 'CODE: \n SET !TIMEOUT_PAGE 600 \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:/claim ATTR=NAME:captcha_code CONTENT=' + captha + n;
	code += 'WAIT SECONDS=1' + n;
	code += 'FILEDELETE NAME=C:\\' + dirData + '\\' + file + n;
	iimPlay(code, 60);

	var code='';
	code += 'CODE: \n SET !TIMEOUT_PAGE 600 \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'TAG POS=1 TYPE=BUTTON ATTR=TXT:Prove<SP>you<SP>are<SP>human' + n;
	code += 'WAIT SECONDS=1' + n;
	code += 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ACTION:/claim ATTR=ID:claimbtn'+ n;
	code += 'WAIT SECONDS=1' + n;
	iimPlay(code, 60);
  
	iimPlay('CODE:SET !TIMEOUT_TAG 1\nTAG POS=1 TYPE=DIV ATTR=TXT:CAPTCHA<SP>incorrect.<SP>Please<SP>try<SP>again. EXTRACT=TXT');
	err = iimGetLastExtract();
	if (err != '' && err != '#EANF#') {
	getfreeBTC(pp + 1);return;} 

	iimPlay("CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=DIV ATTR=TXT:Congrats!<SP>You<SP>have<SP>claimed<SP>*<SP>satoshis. EXTRACT=TXT"); 
	win=iimGetLastExtract();
	if(win == '#EANF#') {return;}
}

//===================================================================================================================

function logingetfree(pp) {

	var code='';
	code += 'CODE: \n SET !TIMEOUT_PAGE 600 \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !ERRORCONTINUE YES \n SET !TIMEOUT_STEP 0 \n';
	code += 'TAB T=1' + n;
	code += 'TAG POS=1 TYPE=INPUT:TEXT FORM=ACTION:* ATTR=NAME:address CONTENT=' + btc + n;
	code += 'WAIT SECONDS=2' + n;	
	iimPlay(code, 60);

	window.document.querySelector('button[type="submit"][class="hidead btn btn-default input-block-level"]').click(); weit(2)
	
	iimPlay('CODE:SET !TIMEOUT_TAG 0\nTAG POS=1 TYPE=DIV ATTR=CLASS:alert<SP>alert-error EXTRACT=TXT');
    err = iimGetLastExtract();
    if (err != '' && err != '#EANF#') {logingetfree(pp + 1);return;}

    var code='';
	code += 'CODE:';
	code += 'WAIT SECONDS=10' + n;	
	code += 'URL GOTO=javascript:window.scrollBy(0,200)' + n;
	iimPlay(code, 60);
}

//===================================================================================================================

function SaveCaptchaShortlink(file_name) {
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'SET !ENCRYPTION NO' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'ONDOWNLOAD FOLDER=C:\\' + dirData + '\\ FILE=' + file_name + ' WAIT=YES' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=IMG ATTR=ID:adcopy-puzzle-image-image-captchaShortlink CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    iimPlay(code, 60)
}

function SaveCapthaSolve(file_name) {
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'SET !ENCRYPTION NO' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'ONDOWNLOAD FOLDER=C:\\' + dirData + '\\ FILE=' + file_name + ' WAIT=YES' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=IMG ATTR=ID:adcopy-puzzle-image-image CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    iimPlay(code, 60)
}

function SaveCapthaSolve2(file_name) {
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB T=1' + n;
    code += 'SET !ENCRYPTION NO' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'ONDOWNLOAD FOLDER=C:\\' + dirData + '\\ FILE=' + file_name + ' WAIT=YES' + n;
    code += 'WAIT SECONDS=1' + n;
    code += 'TAG POS=1 TYPE=IMG ATTR=alt:"CAPTCHA - click to change" CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    code += 'TAG POS=1 TYPE=IMG ATTR=ID:captcha CONTENT=EVENT:SAVE_ELEMENT_SCREENSHOT' + n;
    iimPlay(code, 60)
}

function GetRucaptcha(file_name) {
    var result = new Array();
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB OPEN' + n;
    code += 'TAB T=2' + n;
    code += 'URL GOTO=http://dindinnanet.com.br/saldo/content/dindin.html' + n;
    code += 'TAG POS=1 TYPE=INPUT:FILE FORM=ACTION:* ATTR=NAME:file CONTENT=C:\\' + dirData + '\\' + file_name + n;
    code += 'TAG POS=1 TYPE=INPUT:SUBMIT FORM=ACTION:* ATTR=*' + n;
    code += 'WAIT SECONDS=0.1' + n;
    code += 'TAG POS=1 TYPE=BODY ATTR=TXT:* EXTRACT=TXT' + n;
    code += 'WAIT SECONDS=0.1' + n;
    code += 'TAB CLOSE' + n;
    iimPlay(code, 120);
    var str = iimGetLastExtract();
    var capthId = str.replace('OK|', '');
    switch (capthId) {
        case'ERROR_NO_SLOT_AVAILABLE':
            var code = '';
            code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
            code += 'TAB T=1' + n;
            code += 'WAIT SECONDS=10' + n;
            return GetRucaptcha(file_name);
            break;
        default:
            result['c_text'] = GetRucaptchaTEXT(capthId, file_name, pp);
            result['c_id'] = capthId
    }
    return result
}

function GetRucaptchaTEXT(capthId, file_name, pp) {
    if(pp > prob) {
    iimDisplay('Captcha Errado - Tentando Novamente');}
    else{
    var result = 'ERROR';
    var code = '';
    code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
    code += 'TAB OPEN' + n;
    code += 'TAB T=2' + n;
    code += 'URL GOTO=http://23.249.176.210/res.php?action=get&id=' + capthId + n;
    code += 'WAIT SECONDS=0.1' + n;
    code += 'TAG POS=1 TYPE=BODY ATTR=TXT:* EXTRACT=TXT' + n;
    code += 'WAIT SECONDS=0.1' + n;
    code += 'TAB CLOSE' + n;
    iimPlay(code, 60);
    var str = iimGetLastExtract();
    var capth = str.replace('OK|', '');
    switch (capth) {
        case'CAPCHA_NOT_READY':
            var code = '';
            code += 'CODE: \n SET !EXTRACT_TEST_POPUP NO \n SET !ERRORIGNORE YES \n SET !TIMEOUT_STEP 0 \n';
            code += 'TAB T=1' + n;
            code += 'WAIT SECONDS=10' + n;
            iimPlay(code, 60);
            result = GetRucaptchaTEXT(capthId, file_name, (pp + 1));
            break;
        case'ERROR_KEY_DOES_NOT_EXIST':
            return result = 'ERROR';
            break;
        case'ERROR_WRONG_ID_FORMAT':
            return result = 'ERROR';
            break;
        case'ERROR_WRONG_CAPTCHA_ID':
            return result = 'ERROR';
            break;
        case'ERROR_CAPTCHA_UNSOLVABLE':
            return result = 'ERROR_CAPTCHA_UNSOLVABLE';
            break;
        default:
            var result = capth
    }
    return result}
}

function runFaucet(facetName){

  switch (facetName) {

  	case 'getfreeBTC':
  		getfreeBTC();
  	break;

    case 'hotcoins':
        hotcoins();
    break;

    case 'bigbtc':
        bigbtc();
    break;

    case 'ethxup':
        ethxup();
    break;

   }
}

var col = 40;
var nextsbor = new Array();
nextsbor = getTimerSite();
while (100 > 0) {

    var msec = milisec();
    var i = 0;

    for (var key in faucetOn) {
        i++;
        if (nextsbor[i]< msec && faucetOn[key] > 0){
            runFaucet(key);
            updateTimer(nextsbor, i, faucetOn[key]);
        }
    }
  closeAllOthers();
  updateWaitTimer2();       
}

function weit(s) {iimPlayCode("WAIT SECONDS=" + s);}